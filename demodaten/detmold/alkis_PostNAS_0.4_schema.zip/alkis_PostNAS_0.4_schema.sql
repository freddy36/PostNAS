--
-- *****************************
--       A  L   K   I   S       
-- *****************************
--
-- Datenbankstruktur PostNAS 0.4
--
-- Stand 02.04.2009
--
-- Versuche: Koordinatensystem ?
--    31467 GK3
--    25832 UTM ***
--
-- Datenbank generiert aus NAS-Daten GeoInfoDok 5.1.1. "Lippe",
-- anschliessend manuell ueberarbeitet.
--
-- Bevor dies Script verarbeitet wird:
--  Datenbank auf Basis template_postgis anlegen.
--  (Tabellen 'spatial_ref_sys' und 'geomety_columns' sollen bereits vorhanden sein)

-- ToDo
--  Tabelle 'ax_flugverkehr' fehlt noch (Kommt in unseren Daten nicht vor)

  SET client_encoding = 'UTF8';
--SET standard_conforming_strings = off;
--SET check_function_bodies = false;
--SET client_min_messages = warning;
--SET escape_string_warning = off;
  SET default_with_oids = false;


-- Tuning:
--  Die Tabelle 'spatial_ref_sys' einer PostGIS-Datenbank auf 
--  die notwendigen Koordinatensysteme reduzieren.
--  Das Loescht > 3000 Eintraege.

--  DELETE FROM spatial_ref_sys
--  WHERE srid NOT 
--  IN (2397, 2398, 2399, 4326,    25830, 25831, 25832, 25833, 25834,  31466, 31467, 31468, 31469);
--  --  Krassowski        lat/lon  UTM                                 GK


-- ----------------------------------------------------------
-- A L K I S  -  L a y e r  -  in alphabetischer Reihenfolge
-- ----------------------------------------------------------


-- A P  D a r s t e l l u n g
-- ----------------------------------------------

CREATE TABLE ap_darstellung (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(8),
	anlass integer,
	art character(37),
	uri character(28),
	signaturnummer integer,
	art_ character(3),
	dientzurdarstellungvon character varying
);

--	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ap_darstellung','wkb_geometry','25832','POINT',2);

ALTER TABLE ONLY ap_darstellung
	ADD CONSTRAINT ap_darstellung_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ap_darstellung_geom_idx ON ap_darstellung USING gist (wkb_geometry);


-- A P   L P O
-- ----------------------------------------------

CREATE TABLE ap_lpo (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character varying[],
	anlass integer,
	art character(5),
	dientzurdarstellungvon character varying  --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'LINESTRING'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ap_lpo','wkb_geometry','25832','LINESTRING',2);

ALTER TABLE ONLY ap_lpo
	ADD CONSTRAINT ap_lpo_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ap_lpo_geom_idx ON ap_lpo USING gist (wkb_geometry);


-- A P   L T O
-- ----------------------------------------------

CREATE TABLE ap_lto (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(8),
	sonstigesmodell character(7),
	anlass integer,
	art character(3),
	dientzurdarstellungvon character varying,
	schriftinhalt character(11),
	fontsperrung integer,
	skalierung integer,
	horizontaleausrichtung character(12),
	vertikaleausrichtung character(5) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'LINESTRING'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ap_lto','wkb_geometry','25832','LINESTRING',2);

ALTER TABLE ONLY ap_lto
	ADD CONSTRAINT ap_lto_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ap_lto_geom_idx ON ap_lto USING gist (wkb_geometry);


-- A P  P P O
-- ----------------------------------------------

CREATE TABLE ap_ppo (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character varying[],
	sonstigesmodell character(7),
	anlass integer,
	art character(11),
	dientzurdarstellungvon character varying,
	drehwinkel double precision,
	"zeigtaufexternes|aa_fachdatenverbindung|art" character(37),
	uri character(28) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POINT'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ap_ppo','wkb_geometry','25832','POINT',2);

ALTER TABLE ONLY ap_ppo
	ADD CONSTRAINT ap_ppo_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ap_ppo_geom_idx ON ap_ppo USING gist (wkb_geometry);

-- Problem mit PostNAS 0.4
-- INSERT INTO "ap_ppo" (wkb_geometry .... ) 
--        VALUES (GeomFromEWKT('SRID=25832;MULTIPOINT (486526....)
--                                         __________
-- CONSTRAINT enforce_geotype_wkb_geometry CHECK (geometrytype(wkb_geometry) = 'POINT':

ALTER TABLE ap_ppo DROP CONSTRAINT enforce_geotype_wkb_geometry;




-- A P   P T O
-- ----------------------------------------------

CREATE TABLE ap_pto (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character varying[],
	anlass integer,
	art character(10),
	dientzurdarstellungvon character varying,
	schriftinhalt character(30),
	fontsperrung integer,
	skalierung double precision,
	horizontaleausrichtung character(12),
	vertikaleausrichtung character(5),
	drehwinkel double precision,
	hat character varying,
	"zeigtaufexternes|aa_fachdatenverbindung|art" character(37),
	uri character(28),
	signaturnummer integer,
	sonstigesmodell character(7)
);

--	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POINT'::text) OR (wkb_geometry IS NULL))),
--	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ap_pto','wkb_geometry','25832','POINT',2);

ALTER TABLE ONLY ap_pto
	ADD CONSTRAINT ap_pto_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ap_pto_geom_idx ON ap_pto USING gist (wkb_geometry);


-- A n s c h r i f t
-- ----------------------------------------------
-- Buchwerk, keine Geometrie?
-- konverter versucht Tabelle noch einmal anzulegen?!

CREATE TABLE ax_anschrift (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	ort_post character(30),
	postleitzahlpostzustellung integer,
	bestimmungsland character(18),
	strasse character(28),
	hausnummer character(6),
	art character(37),
	uri character(28) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_anschrift','wkb_geometry','25832','xxx',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_anschrift', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_anschrift
	ADD CONSTRAINT ax_anschrift_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_anschrift_geom_idx ON ax_anschrift USING gist (wkb_geometry);


-- A u f n a h m e p u n k t
-- ----------------------------------------------

CREATE TABLE ax_aufnahmepunkt (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	anlass integer,
	punktkennung integer,
	land integer,
	stelle integer,
	sonstigeeigenschaft character varying[],
	vermarkung_marke integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('____','wkb_geometry','25832','POINT',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_aufnahmepunkt', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_aufnahmepunkt
	ADD CONSTRAINT ax_aufnahmepunkt_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_aufnahmepunkt_geom_idx ON ax_aufnahmepunkt USING gist (wkb_geometry);


-- B a h n v e r k e h r 
-- ----------------------------------------------

CREATE TABLE ax_bahnverkehr (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	funktion integer,
	unverschluesselt character(27),
	land integer,
	regierungsbezirk integer,
	kreis integer,
	gemeinde integer,
	lage integer,
	bahnkategorie integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_bahnverkehr','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_bahnverkehr
	ADD CONSTRAINT ax_bahnverkehr_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_bahnverkehr_geom_idx ON ax_bahnverkehr USING gist (wkb_geometry);


-- B a h n v e r k e h r s a n l a g e
-- ----------------------------------------------

CREATE TABLE ax_bahnverkehrsanlage (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	bahnhofskategorie integer,
	bahnkategorie integer --,
	--CONSTRAINT ax_bahnverkehrsanlage_pk PRIMARY KEY (ogc_fid),
	--CONSTRAINT enforce_dims_wkb_geometry CHECK (ndims(wkb_geometry) = 2),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (geometrytype(wkb_geometry) = 'POINT'::text OR wkb_geometry IS NULL),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK (srid(wkb_geometry) = 25832)
);

SELECT AddGeometryColumn('ax_bahnverkehrsanlage','wkb_geometry','25832','POINT',2);

ALTER TABLE ONLY ax_bahnverkehrsanlage
	ADD CONSTRAINT ax_bahnverkehrsanlage_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_bahnverkehrsanlage_geom_idx  ON ax_bahnverkehrsanlage USING gist (wkb_geometry);


-- B a u - ,   R a u m -   o d e r   B o d e n o r d n u n g s r e c h t
-- ---------------------------------------------------------------------

CREATE TABLE ax_bauraumoderbodenordnungsrecht (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	anlass integer,
	artderfestlegung integer,
	land integer,
	stelle character(5),
	bezeichnung integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_bauraumoderbodenordnungsrecht','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_bauraumoderbodenordnungsrecht
	ADD CONSTRAINT ax_bauraumoderbodenordnungsrecht_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_bauraumoderbodenordnungsrecht_geom_idx ON ax_bauraumoderbodenordnungsrecht USING gist (wkb_geometry);


-- B a u t e i l
-- ----------------------------------------------

CREATE TABLE ax_bauteil (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	bauart integer,
	lagezurerdoberflaeche integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_bauteil','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_bauteil
	ADD CONSTRAINT ax_bauteil_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_bauteil_geom_idx ON ax_bauteil USING gist (wkb_geometry);


-- B a u w e r k   i m     G e w a e s s e r b e r e i c h
-- --------------------------------------------------------

CREATE TABLE ax_bauwerkimgewaesserbereich (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	bauwerksfunktion integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'LINESTRING'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_bauwerkimgewaesserbereich','wkb_geometry','25832','LINESTRING',2);

-- Es wird (auch) POINT geliefert !
ALTER TABLE ax_bauwerkimgewaesserbereich 
DROP CONSTRAINT enforce_geotype_wkb_geometry;

ALTER TABLE ONLY ax_bauwerkimgewaesserbereich
	ADD CONSTRAINT ax_bauwerkimgewaesserbereich_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_bauwerkimgewaesserbereich_geom_idx ON ax_bauwerkimgewaesserbereich USING gist (wkb_geometry);


-- B a u w e r k   i m  V e r k e h s b e r e i c h
-- ------------------------------------------------

CREATE TABLE ax_bauwerkimverkehrsbereich (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	bauwerksfunktion integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_bauwerkimverkehrsbereich','wkb_geometry','25832','POLYGON',2);
-- POLYGON und LINESTRING
ALTER TABLE ax_bauwerkimverkehrsbereich
DROP CONSTRAINT enforce_geotype_wkb_geometry;

--INSERT INTO geometry_columns 
--       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
--VALUES ('', 'public', 'ax_bauwerkimverkehrsbereich', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_bauwerkimverkehrsbereich
	ADD CONSTRAINT ax_bauwerkimverkehrsbereich_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_bauwerkimverkehrsbereich_geom_idx ON ax_bauwerkimverkehrsbereich USING gist (wkb_geometry);


-- Bauwerk oder Anlage fuer Industrieund Gewerbe
-- ----------------------------------------------

CREATE TABLE ax_bauwerkoderanlagefuerindustrieundgewerbe (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	bauwerksfunktion integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POINT'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_bauwerkoderanlagefuerindustrieundgewerbe','wkb_geometry','25832','POLYGON',2);

-- POLYGON und POINT
ALTER TABLE ax_bauwerkoderanlagefuerindustrieundgewerbe
DROP CONSTRAINT enforce_geotype_wkb_geometry;

ALTER TABLE ONLY ax_bauwerkoderanlagefuerindustrieundgewerbe
	ADD CONSTRAINT ax_bauwerkoderanlagefuerindustrieundgewerbe_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_bauwerkoderanlagefuerindustrieundgewerbe_geom_idx ON ax_bauwerkoderanlagefuerindustrieundgewerbe USING gist (wkb_geometry);


-- Bauwerk oder Anlage fuer Sport, Freizeit und Erholung
-- -----------------------------------------------------

CREATE TABLE ax_bauwerkoderanlagefuersportfreizeitunderholung (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	description integer,
	bauwerksfunktion integer,
	name character(15) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_bauwerkoderanlagefuersportfreizeitunderholung','wkb_geometry','25832','POLYGON',2);
--POLYGON  oder POINT
ALTER TABLE ax_bauwerkoderanlagefuersportfreizeitunderholung
DROP CONSTRAINT enforce_geotype_wkb_geometry;

ALTER TABLE ONLY ax_bauwerkoderanlagefuersportfreizeitunderholung
	ADD CONSTRAINT ax_bauwerkoderanlagefuersportfreizeitunderholung_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_bauwerkoderanlagefuersportfreizeitunderholung_geom_idx ON ax_bauwerkoderanlagefuersportfreizeitunderholung USING gist (wkb_geometry);


-- B e s o n d e r e   F l u r s t u e c k s g r e n z e
-- -----------------------------------------------------

CREATE TABLE ax_besondereflurstuecksgrenze (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(5),
	anlass integer,
	artderflurstuecksgrenze integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'LINESTRING'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_besondereflurstuecksgrenze','wkb_geometry','25832','LINESTRING',2);

ALTER TABLE ONLY ax_besondereflurstuecksgrenze
	ADD CONSTRAINT ax_besondereflurstuecksgrenze_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_besondereflurstuecksgrenze_geom_idx ON ax_besondereflurstuecksgrenze USING gist (wkb_geometry);


-- B e s o n d e r e   G e b a e u d e l i n i e
-- ----------------------------------------------

CREATE TABLE ax_besonderegebaeudelinie (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	beschaffenheit integer,
	anlass integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'LINESTRING'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_besonderegebaeudelinie','wkb_geometry','25832','LINESTRING',2);

ALTER TABLE ONLY ax_besonderegebaeudelinie
	ADD CONSTRAINT ax_besonderegebaeudelinie_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_besonderegebaeudelinie_geom_idx ON ax_besonderegebaeudelinie USING gist (wkb_geometry);


-- B e s o n d e r e r   B a u w e r k s p u n k t
-- -----------------------------------------------

CREATE TABLE ax_besondererbauwerkspunkt (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	punktkennung integer,
	land integer,
	stelle integer,
	sonstigeeigenschaft character(26) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_besondererbauwerkspunkt','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_besondererbauwerkspunkt', 'dummy', 2, 25832, 'POINT');
ALTER TABLE ONLY ax_besondererbauwerkspunkt
	ADD CONSTRAINT ax_besondererbauwerkspunkt_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_besondererbauwerkspunkt_geom_idx ON ax_besondererbauwerkspunkt USING gist (wkb_geometry);


-- B e s o n d e r e r   G e b a e u d e p u n k t
-- -----------------------------------------------

CREATE TABLE ax_besonderergebaeudepunkt (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	punktkennung integer,
	land integer,
	stelle integer,
	sonstigeeigenschaft character(26),
	art character(37),
	uri character(28) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_besonderergebaeudepunkt','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_besonderergebaeudepunkt', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_besonderergebaeudepunkt
	ADD CONSTRAINT ax_besonderergebaeudepunkt_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_besonderergebaeudepunkt_geom_idx ON ax_besonderergebaeudepunkt USING gist (wkb_geometry);


-- B e s o n d e r e r   T o p o g r a f i s c h e r   P u n k t
-- -------------------------------------------------------------

CREATE TABLE ax_besonderertopographischerpunkt (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	punktkennung integer,
	land integer,
	stelle integer,
	sonstigeeigenschaft character(26) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_besonderertopographischerpunkt','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_besonderertopographischerpunkt', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_besonderertopographischerpunkt
	ADD CONSTRAINT ax_besonderertopographischerpunkt_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_besonderertopographischerpunkt_geom_idx ON ax_besonderertopographischerpunkt USING gist (wkb_geometry);


-- B o d e n s c h a e t z u n g
-- ----------------------------------------------

CREATE TABLE ax_bodenschaetzung (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	anlass integer,
	kulturart integer,
	bodenart integer,
	zustandsstufeoderbodenstufe integer,
	entstehungsartoderklimastufewasserverhaeltnisse integer,
	bodenzahlodergruenlandgrundzahl integer,
	ackerzahlodergruenlandzahl integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_bodenschaetzung','wkb_geometry','25832','POLYGON',2);
-- POLYGON und MULTIPOLYGON
ALTER TABLE ONLY ax_bodenschaetzung
	DROP CONSTRAINT enforce_geotype_wkb_geometry;

ALTER TABLE ONLY ax_bodenschaetzung
	ADD CONSTRAINT ax_bodenschaetzung_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_bodenschaetzung_geom_idx ON ax_bodenschaetzung USING gist (wkb_geometry);


-- B o e s c h u n g s k l i f f
-- ----------------------------------------------

CREATE TABLE ax_boeschungkliff (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_boeschungkliff','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_boeschungkliff', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_boeschungkliff
	ADD CONSTRAINT ax_boeschungkliff_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_boeschungkliff_geom_idx ON ax_boeschungkliff USING gist (wkb_geometry);


-- B o e s c h u n g s f l a e c h e
-- ----------------------------------------------

CREATE TABLE ax_boeschungsflaeche (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	istteilvon character varying --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_boeschungsflaeche','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_boeschungsflaeche
	ADD CONSTRAINT ax_boeschungsflaeche_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_boeschungsflaeche_geom_idx ON ax_boeschungsflaeche USING gist (wkb_geometry);


-- B u c h u n g s b l a t t
-- ----------------------------------------------

CREATE TABLE ax_buchungsblatt (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	anlass integer,
	buchungsblattkennzeichen character(13),
	land integer,
	bezirk integer,
	buchungsblattnummermitbuchstabenerweiterung character(7),
	blattart integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_buchungsblatt','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_buchungsblatt', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_buchungsblatt
	ADD CONSTRAINT ax_buchungsblatt_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_buchungsblatt_geom_idx ON ax_buchungsblatt USING gist (wkb_geometry);


-- B u c h u n g s b l a t t / B e z i r k
-- ----------------------------------------------

CREATE TABLE ax_buchungsblattbezirk (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	anlass integer,
	schluesselgesamt integer,
	bezeichnung character(26),
	land integer,
	bezirk integer,
	"gehoertzu|ax_dienststelle_schluessel|land" integer,
	stelle character(4) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_buchungsblattbezirk','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_buchungsblattbezirk', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_buchungsblattbezirk
	ADD CONSTRAINT ax_buchungsblattbezirk_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_buchungsblattbezirk_geom_idx ON ax_buchungsblattbezirk USING gist (wkb_geometry);


-- B u c h u n g s s t e l l e
-- ----------------------------------------------

CREATE TABLE ax_buchungsstelle (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	anlass integer,
	buchungsart integer,
	laufendenummer integer,
	istbestandteilvon character varying,
	art character(37),
	uri character(12),
	zaehler double precision,
	nenner integer,
	nummerimaufteilungsplan character(32),
	beschreibungdessondereigentums character(291),
	an character varying --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_buchungsstelle','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_buchungsstelle', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_buchungsstelle
	ADD CONSTRAINT ax_buchungsstelle_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_buchungsstelle_geom_idx ON ax_buchungsstelle USING gist (wkb_geometry);


-- B u n d e s l a n d
-- ----------------------------------------------

CREATE TABLE ax_bundesland (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	schluesselgesamt integer,
	bezeichnung character(22),
	land integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_bundesland','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_bundesland', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_bundesland
	ADD CONSTRAINT ax_bundesland_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_bundesland_geom_idx ON ax_bundesland USING gist (wkb_geometry);


-- D a m m  /  W a l l  /  D e i c h
-- ----------------------------------------------

CREATE TABLE ax_dammwalldeich (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	art integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'LINESTRING'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_dammwalldeich','wkb_geometry','25832','LINESTRING',2);

ALTER TABLE ONLY ax_dammwalldeich
	ADD CONSTRAINT ax_dammwalldeich_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_dammwalldeich_geom_idx ON ax_dammwalldeich USING gist (wkb_geometry);


-- D i e n s t s t e l l e
-- ----------------------------------------------
-- Schluesseltabelle: Geometrie entbehrlich?

CREATE TABLE ax_dienststelle (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	schluesselgesamt character(7),
	bezeichnung character(21),
	land integer,
	stelle character(5),
	stellenart integer,
	hat character varying --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_dienststelle','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_dienststelle', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_dienststelle
	ADD CONSTRAINT ax_dienststelle_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_dienststelle_geom_idx ON ax_dienststelle USING gist (wkb_geometry);


-- F e l s e n ,  F e l s b l o c k ,   F e l s n a d e l
-- ------------------------------------------------------

CREATE TABLE ax_felsenfelsblockfelsnadel (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	name character(30) --(14),
	--CONSTRAINT ax_felsenfelsblockfelsnadel_pk PRIMARY KEY (ogc_fid),
	--CONSTRAINT enforce_dims_wkb_geometry CHECK (ndims(wkb_geometry) = 2),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (geometrytype(wkb_geometry) = 'POLYGON'::text OR wkb_geometry IS NULL),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK (srid(wkb_geometry) = 25832)
);

SELECT AddGeometryColumn('ax_felsenfelsblockfelsnadel','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_felsenfelsblockfelsnadel
	ADD CONSTRAINT ax_felsenfelsblockfelsnadel_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_felsenfelsblockfelsnadel_geom_idx ON ax_felsenfelsblockfelsnadel USING gist (wkb_geometry);


-- F i r s t l i n i e
-- -----------------------------------------------------

CREATE TABLE ax_firstlinie (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	art character(37),
	uri character(28),
	CONSTRAINT ax_firstlinie_pk PRIMARY KEY (ogc_fid) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK (ndims(wkb_geometry) = 2),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (geometrytype(wkb_geometry) = 'LINESTRING'::text OR wkb_geometry IS NULL),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK (srid(wkb_geometry) = 25832)
);

SELECT AddGeometryColumn('ax_firstlinie','wkb_geometry','25832','LINESTRING',2);

CREATE INDEX ax_firstlinie_geom_idx ON ax_firstlinie USING gist (wkb_geometry);


-- F l a e c h e   b e s o n d e r e r   f u n k t i o n a l e r   P r a e g u n g
-- -------------------------------------------------------------------------------

CREATE TABLE ax_flaechebesondererfunktionalerpraegung (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	funktion integer
);

--	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
--	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ax_flaechebesondererfunktionalerpraegung','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_flaechebesondererfunktionalerpraegung
	ADD CONSTRAINT ax_flaechebesondererfunktionalerpraegung_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_flaechebesondererfunktionalerpraegung_geom_idx ON ax_flaechebesondererfunktionalerpraegung USING gist (wkb_geometry);


-- F l a e c h e n   g e m i s c h t e r   N u t z u n g
-- -----------------------------------------------------

CREATE TABLE ax_flaechegemischternutzung (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	funktion integer,
	zustand integer
);

--	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
--	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ax_flaechegemischternutzung','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_flaechegemischternutzung
	ADD CONSTRAINT ax_flaechegemischternutzung_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_flaechegemischternutzung_geom_idx ON ax_flaechegemischternutzung USING gist (wkb_geometry);


-- F l i e s s g e w a e s s e r
-- ----------------------------------------------

CREATE TABLE ax_fliessgewaesser (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	funktion integer,
	land integer,
	regierungsbezirk integer,
	kreis integer,
	gemeinde integer,
	lage integer,
	unverschluesselt character(13) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_fliessgewaesser','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_fliessgewaesser
	ADD CONSTRAINT ax_fliessgewaesser_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_fliessgewaesser_geom_idx ON ax_fliessgewaesser USING gist (wkb_geometry);


-- F l u r s t u e c k
-- ----------------------------------------------

CREATE TABLE ax_flurstueck (
	ogc_fid 		serial NOT NULL,
	gml_id 			character(16),
	beginnt 		character(20),
	advstandardmodell 	character(4),
	anlass 			integer,
	art 			character varying[],
	name 			character varying[],
	land 			integer,
	gemarkungsnummer 	integer,
	zaehler 		integer,
	flurstueckskennzeichen	character(20),
	amtlicheflaeche		integer,
	flurnummer		integer,
	abweichenderrechtszustand character(5),
	rechtsbehelfsverfahren	character(5),
	zeitpunktderentstehung	character(10),
	"gemeindezugehoerigkeit|ax_gemeindekennzeichen|land"	integer,
	regierungsbezirk	integer,
	kreis	integer,
	gemeinde	integer,
	"zustaendigestelle|ax_dienststelle_schluessel|land"	integer,
	stelle	integer,
	istgebucht		character varying,
	zeigtauf		character varying,
	weistauf		character varying,
	kennungschluessel	character(31),  -- manuell hinzu
	uri			character(28)   -- geaendert 12 auf 28
);

SELECT AddGeometryColumn('ax_flurstueck','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_flurstueck
	ADD CONSTRAINT ax_flurstueck_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_flurstueck_geom_idx ON ax_flurstueck USING gist (wkb_geometry);


-- F r i e d h o f
-- ----------------------------------------------

CREATE TABLE ax_friedhof (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	funktion integer,
	name character(22) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_friedhof','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_friedhof
	ADD CONSTRAINT ax_friedhof_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_friedhof_geom_idx ON ax_friedhof USING gist (wkb_geometry);


-- G e b a e u d e
-- ----------------------------------------------

CREATE TABLE ax_gebaeude (
	ogc_fid			serial NOT NULL,
	gml_id			character(16),
	beginnt			character(20),
	advstandardmodell	character(4),
	sonstigesmodell		character varying[],
	anlass			integer,
	gebaeudefunktion	integer,
	description		integer,
	hat			character varying,
	zeigtauf		character varying,
	name			character(22),
	lagezurerdoberflaeche	integer,
	art			character(37),
	uri			character(28),
	bauweise		integer,
	anzahlderoberirdischengeschosse	integer,
	grundflaeche		integer,
	"qualitaetsangaben|ax_dqmitdatenerhebung|herkunft|li_lineage|pro" character(8),
	individualname		character(7),
	role			character(16),
	zustand			integer
);

--  CONSTRAINT enforce_dims_wkb_geometry CHECK (ndims(wkb_geometry) = 2),
--  CONSTRAINT enforce_geotype_wkb_geometry CHECK (geometrytype(wkb_geometry) = 'POLYGON'::text OR wkb_geometry IS NULL),
--  CONSTRAINT enforce_srid_wkb_geometry CHECK (srid(wkb_geometry) = 25832)

SELECT AddGeometryColumn('ax_gebaeude','wkb_geometry','25832','POLYGON',2);
-- POLYGON und MULTIPOLYGON
-- Problem: PostNAS 0.3 erzeugt POLYGON und MULTIPOLYGON-Eintraege
-- L�sung:  Die CONSTRAINT/CHECK voruebergehend ausschalten.
ALTER TABLE ax_gebaeude DROP CONSTRAINT enforce_geotype_wkb_geometry;
-- Jetzt luegt aber die Metatabelle 'geometry_columns'!

CREATE INDEX ax_gebaeude_geom_idx ON ax_gebaeude USING gist (wkb_geometry);

ALTER TABLE ONLY ax_gebaeude
	ADD CONSTRAINT ax_gebaeude_pk PRIMARY KEY (ogc_fid);


-- W�e oft kommt welcher Typ vor
CREATE VIEW gebauede_geometrie_arten AS
  SELECT geometrytype(wkb_geometry) AS geotyp,
         COUNT(ogc_fid)             AS anzahl
    FROM ax_gebaeude
GROUP BY geometrytype(wkb_geometry);
-- Ergebnis: nur 3 mal MULTIPOLYGON in einer Gemeinde, Rest POLYGON

-- Welche sind das?
CREATE VIEW gebauede_geometrie_multipolygone AS
  SELECT ogc_fid, 
         astext(wkb_geometry) AS geometrie
    FROM ax_gebaeude
   WHERE geometrytype(wkb_geometry) = 'MULTIPOLYGON';

-- GeometryFromText('MULTIPOLYGON((( AUSSEN ), ( INNEN1 ), ( INNEN2 )))', srid)
-- GeometryFromText('MULTIPOLYGON((( AUSSEN1 )),(( AUSSEN2)))', srid)



-- G e h o e l z
-- ----------------------------------------------

CREATE TABLE ax_gehoelz (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(5),
	anlass integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_gehoelz','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_gehoelz
	ADD CONSTRAINT ax_gehoelz_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_gehoelz_geom_idx ON ax_gehoelz USING gist (wkb_geometry);


-- G e m a r k u n g
-- ----------------------------------------------
-- Schluesseltabelle: Geometrie entbehrlich?

CREATE TABLE ax_gemarkung (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	schluesselgesamt integer,
	bezeichnung character(23),
	land integer,
	gemarkungsnummer integer,
	"istamtsbezirkvon|ax_dienststelle_schluessel|land" integer,
	stelle integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_gemarkung','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_gemarkung', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_gemarkung
	ADD CONSTRAINT ax_gemarkung_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_gemarkung_geom_idx ON ax_gemarkung USING gist (wkb_geometry);


-- G e m a r k u n g s t e i l   /   F l u r
-- ----------------------------------------------
-- Schluesseltabelle: Geometrie entbehrlich?

CREATE TABLE ax_gemarkungsteilflur (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	schluesselgesamt integer,
	bezeichnung integer,
	land integer,
	gemarkung integer,
	gemarkungsteilflur integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_gemarkungsteilflur','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_gemarkungsteilflur', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_gemarkungsteilflur
	ADD CONSTRAINT ax_gemarkungsteilflur_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_gemarkungsteilflur_geom_idx ON ax_gemarkungsteilflur USING gist (wkb_geometry);


-- G e m e i n d e
-- ----------------------------------------------

CREATE TABLE ax_gemeinde (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	schluesselgesamt integer,
	bezeichnung character(25),
	land integer,
	regierungsbezirk integer,
	kreis integer,
	gemeinde integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_gemeinde','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_gemeinde', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_gemeinde
	ADD CONSTRAINT ax_gemeinde_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_gemeinde_geom_idx ON ax_gemeinde USING gist (wkb_geometry);


-- Georeferenzierte  G e b � u d e a d r e s s e
-- ----------------------------------------------

-- DELETE FROM ax_georeferenziertegebaeudeadresse;
-- DROP TABLE  ax_georeferenziertegebaeudeadresse CASCADE;

CREATE TABLE ax_georeferenziertegebaeudeadresse (
	ogc_fid			serial NOT NULL,
	gml_id			character(16),
	beginnt			character(20),	-- Inhalt z.B. "2008-06-10T15:19:17Z"
						-- ISO:waere   "2008-06-10 15:19:17-00"
--	beginnt			timestamp,	-- wird nicht geladen, bleibt leer
	advstandardmodell	character(4),
	anlass			integer,
	qualitaetsangaben	integer,	-- zb: "1000" (= Massstab)
	--			--		-- Gemeindeschluessel, bestehend aus:
	land			integer,	-- 05 = NRW
	regierungsbezirk	integer,	--   7
	kreis			integer,	--    66
	gemeinde		integer,	--      020
	ortsteil		integer,	--         0
	--			--		-- --
	strassenschluessel	integer,	-- max.  5 Stellen
	hausnummer		integer,	-- meist 3 Stellen
	postleitzahl		integer,	-- ueblich sind char(5) mit fuehrenden Nullen
	ortsnamepost		character(40),	-- (4),  generierte Laenge, Name wird abgeschnitten
	zusatzortsname		character(30),	-- (7),  erscheint zu knapp
	strassenname		character(50),	-- (23), generierte Laenge, Name wird abgeschnitten
	hatauch			character varying,
	adressierungszusatz	character(1),	-- Hausnummernzusatz-Buchstabe
	art			character(37),	-- "urn:adv:fachdatenverbindung:AA_Antrag"
	uri			character(57)	-- "urn:adv:oid:DENW17APZ00000AN;urn:adv:oid:DENW17APZ00000XU"
);

--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POINT'::text) OR (wkb_geometry IS NULL))),
--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ax_georeferenziertegebaeudeadresse','wkb_geometry','25832','POINT',2);

ALTER TABLE ONLY ax_georeferenziertegebaeudeadresse
	ADD CONSTRAINT ax_georeferenziertegebaeudeadresse_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_georeferenziertegebaeudeadresse_geom_idx ON ax_georeferenziertegebaeudeadresse USING gist (wkb_geometry);


-- G e w a e s s e r m e r k m a l
-- ----------------------------------------------

CREATE TABLE ax_gewaessermerkmal (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	art integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POINT'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_gewaessermerkmal','wkb_geometry','25832','POINT',2);

ALTER TABLE ONLY ax_gewaessermerkmal
	ADD CONSTRAINT ax_gewaessermerkmal_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_gewaessermerkmal_geom_idx ON ax_gewaessermerkmal USING gist (wkb_geometry);


-- G l e i s
-- ----------------------------------------------

CREATE TABLE ax_gleis (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	bahnkategorie integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'LINESTRING'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_gleis','wkb_geometry','25832','LINESTRING',2);

ALTER TABLE ONLY ax_gleis
	ADD CONSTRAINT ax_gleis_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_gleis_geom_idx ON ax_gleis USING gist (wkb_geometry);


-- G r e n z p u n k t
-- ----------------------------------------------

CREATE TABLE ax_grenzpunkt (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(5),
	anlass integer,
	punktkennung integer,
	land integer,
	stelle integer,
	abmarkung_marke integer,
	sonstigeeigenschaft character varying[],
	art character(37),
	uri character(28) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_grenzpunkt','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_grenzpunkt', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_grenzpunkt
	ADD CONSTRAINT ax_grenzpunkt_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_grenzpunkt_geom_idx ON ax_grenzpunkt USING gist (wkb_geometry);


-- H a l d e
-- ----------------------------------------------
CREATE TABLE ax_halde
(
	ogc_fid serial NOT NULL,
	-- wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	lagergut integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK (ndims(wkb_geometry) = 2),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (geometrytype(wkb_geometry) = 'POLYGON'::text OR wkb_geometry IS NULL),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK (srid(wkb_geometry) = 25832)
)
;

SELECT AddGeometryColumn('ax_halde','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_halde
	ADD CONSTRAINT ax_halde_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_halde_geom_idx ON ax_halde USING gist (wkb_geometry);



-- H e i d e
-- ----------------------------------------------


CREATE TABLE ax_heide
(
  ogc_fid serial NOT NULL,
  --wkb_geometry geometry,
  gml_id character(16),
  beginnt character(20),
  advstandardmodell character(4),
  sonstigesmodell character(5),
  anlass integer,
  CONSTRAINT ax_heide_pk PRIMARY KEY (ogc_fid) --,
  --CONSTRAINT enforce_dims_wkb_geometry CHECK (ndims(wkb_geometry) = 2),
  --CONSTRAINT enforce_geotype_wkb_geometry CHECK (geometrytype(wkb_geometry) = 'POLYGON'::text OR wkb_geometry IS NULL),
  --CONSTRAINT enforce_srid_wkb_geometry CHECK (srid(wkb_geometry) = 25832)
);

SELECT AddGeometryColumn('ax_heide','wkb_geometry','25832','POLYGON',2);

CREATE INDEX ax_heide_geom_idx ON ax_heide USING gist (wkb_geometry);




-- Historisches Bauwerk oder historische Einrichtung
-- -------------------------------------------------

CREATE TABLE ax_historischesbauwerkoderhistorischeeinrichtung (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	archaeologischertyp integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POINT'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_historischesbauwerkoderhistorischeeinrichtung','wkb_geometry','25832','POLYGON',2);
-- POLYGON und POINT
ALTER TABLE  ax_historischesbauwerkoderhistorischeeinrichtung
	DROP CONSTRAINT enforce_geotype_wkb_geometry;

ALTER TABLE ONLY ax_historischesbauwerkoderhistorischeeinrichtung
	ADD CONSTRAINT ax_historischesbauwerkoderhistorischeeinrichtung_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_historischesbauwerkoderhistorischeeinrichtung_geom_idx ON ax_historischesbauwerkoderhistorischeeinrichtung USING gist (wkb_geometry);


-- I n d u s t r i e -   u n d   G e w e r b e f l a e c h e
-- ----------------------------------------------------------

CREATE TABLE ax_industrieundgewerbeflaeche (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	funktion integer,
	zustand integer
);

--	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
--	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ax_industrieundgewerbeflaeche','wkb_geometry','25832','POLYGON',2);
-- POLYGON und POINT
ALTER TABLE ax_industrieundgewerbeflaeche
	DROP CONSTRAINT enforce_geotype_wkb_geometry;

ALTER TABLE ONLY ax_industrieundgewerbeflaeche
	ADD CONSTRAINT ax_industrieundgewerbeflaeche_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_industrieundgewerbeflaeche_geom_idx ON ax_industrieundgewerbeflaeche USING gist (wkb_geometry);


-- k l e i n r a e u m i g e r   L a n d s c h a f t s t e i l
-- -----------------------------------------------------------

CREATE TABLE ax_kleinraeumigerlandschaftsteil (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	landschaftstyp integer,
	name character(14) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POINT'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_kleinraeumigerlandschaftsteil','wkb_geometry','25832','POINT',2);

ALTER TABLE ONLY ax_kleinraeumigerlandschaftsteil
	ADD CONSTRAINT ax_kleinraeumigerlandschaftsteil_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_kleinraeumigerlandschaftsteil_geom_idx ON ax_kleinraeumigerlandschaftsteil USING gist (wkb_geometry);


-- K o m m u n a l e s   G e b i e t
-- ----------------------------------------------

CREATE TABLE ax_kommunalesgebiet (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	anlass integer,
	schluesselgesamt integer,
	land integer,
	regierungsbezirk integer,
	kreis integer,
	gemeinde integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_kommunalesgebiet','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_kommunalesgebiet
	ADD CONSTRAINT ax_kommunalesgebiet_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_kommunalesgebiet_geom_idx ON ax_kommunalesgebiet USING gist (wkb_geometry);


-- K r e i s r e g i o n
-- ----------------------------------------------

CREATE TABLE ax_kreisregion (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	schluesselgesamt integer,
	bezeichnung character(10),
	land integer,
	regierungsbezirk integer,
	kreis integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_kreisregion','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_kreisregion', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_kreisregion
	ADD CONSTRAINT ax_kreisregion_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_kreisregion_geom_idx ON ax_kreisregion USING gist (wkb_geometry);


-- L a g e b e z e i c h n u n g s e i n t r a g
-- ----------------------------------------------

CREATE TABLE ax_lagebezeichnungkatalogeintrag (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	schluesselgesamt character(13),
	bezeichnung character(28),
	land integer,
	regierungsbezirk integer,
	kreis integer,
	gemeinde integer,
	lage character(5) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_lagebezeichnungkatalogeintrag','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_lagebezeichnungkatalogeintrag', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_lagebezeichnungkatalogeintrag
	ADD CONSTRAINT ax_lagebezeichnungkatalogeintrag_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_lagebezeichnungkatalogeintrag_geom_idx ON ax_lagebezeichnungkatalogeintrag USING gist (wkb_geometry);


-- L a g e b e z e i c h n u n g   m i t  H a u s n u m m e r
-- ----------------------------------------------------------

CREATE TABLE ax_lagebezeichnungmithausnummer (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(5),
	anlass integer,
	land integer,
	regierungsbezirk integer,
	kreis integer,
	gemeinde integer,
	lage integer,
	hausnummer character(5) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_lagebezeichnungmithausnummer','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_lagebezeichnungmithausnummer', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_lagebezeichnungmithausnummer
	ADD CONSTRAINT ax_lagebezeichnungmithausnummer_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_lagebezeichnungmithausnummer_geom_idx ON ax_lagebezeichnungmithausnummer USING gist (wkb_geometry);


-- L a g e b e z e i c h n u n g   m i t  P s e u d o n u m m e r
-- --------------------------------------------------------------

CREATE TABLE ax_lagebezeichnungmitpseudonummer (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	land integer,
	regierungsbezirk integer,
	kreis integer,
	gemeinde integer,
	lage integer,
	pseudonummer character(5),
	laufendenummer character(2) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_lagebezeichnungmitpseudonummer','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_lagebezeichnungmitpseudonummer', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_lagebezeichnungmitpseudonummer
	ADD CONSTRAINT ax_lagebezeichnungmitpseudonummer_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_lagebezeichnungmitpseudonummer_geom_idx ON ax_lagebezeichnungmitpseudonummer USING gist (wkb_geometry);


-- L a g e b e z e i c h n u n g   o h n e   H a u s n u m m e r
-- -------------------------------------------------------------

CREATE TABLE ax_lagebezeichnungohnehausnummer (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(5),
	anlass integer,
	land integer,
	regierungsbezirk integer,
	kreis integer,
	gemeinde integer,
	lage integer,
	unverschluesselt character(40) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_lagebezeichnungohnehausnummer','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_lagebezeichnungohnehausnummer', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_lagebezeichnungohnehausnummer
	ADD CONSTRAINT ax_lagebezeichnungohnehausnummer_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_lagebezeichnungohnehausnummer_geom_idx ON ax_lagebezeichnungohnehausnummer USING gist (wkb_geometry);


-- L a n d w i r t s c h a f t
-- ----------------------------------------------

CREATE TABLE ax_landwirtschaft (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(5),
	anlass integer,
	vegetationsmerkmal integer
);

--	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
--	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ax_landwirtschaft','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_landwirtschaft
	ADD CONSTRAINT ax_landwirtschaft_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_landwirtschaft_geom_idx ON ax_landwirtschaft USING gist (wkb_geometry);


-- L e i t u n g
-- ----------------------------------------------

CREATE TABLE ax_leitung (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	bauwerksfunktion integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'LINESTRING'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_leitung','wkb_geometry','25832','LINESTRING',2);

ALTER TABLE ONLY ax_leitung
	ADD CONSTRAINT ax_leitung_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_leitung_geom_idx ON ax_leitung USING gist (wkb_geometry);


-- M u s t e r -,  L a n d e s m u s t e r -   u n d   V e r g l e i c h s s t u e c k
-- -----------------------------------------------------------------------------------

CREATE TABLE ax_musterlandesmusterundvergleichsstueck (
  ogc_fid serial NOT NULL,
  --wkb_geometry geometry,
  gml_id character(16),
  beginnt character(20),
  advstandardmodell character(4),
  anlass integer,
  merkmal integer,
  kulturart integer,
  bodenart integer,
  zustandsstufeoderbodenstufe integer,
  entstehungsartoderklimastufewasserverhaeltnisse integer,
  bodenzahlodergruenlandgrundzahl integer,
  ackerzahlodergruenlandzahl integer,
  CONSTRAINT ax_musterlandesmusterundvergleichsstueck_pk PRIMARY KEY (ogc_fid) --,
  --CONSTRAINT enforce_dims_wkb_geometry CHECK (ndims(wkb_geometry) = 2),
  --CONSTRAINT enforce_geotype_wkb_geometry CHECK (geometrytype(wkb_geometry) = 'POLYGON'::text OR wkb_geometry IS NULL),
  --CONSTRAINT enforce_srid_wkb_geometry CHECK (srid(wkb_geometry) = 25832)
);

SELECT AddGeometryColumn('ax_musterlandesmusterundvergleichsstueck','wkb_geometry','25832','POLYGON',2);

CREATE INDEX ax_musterlandesmusterundvergleichsstueck_geom_idx
  ON ax_musterlandesmusterundvergleichsstueck USING gist (wkb_geometry);


-- N a m e n s n u m m e r
-- ----------------------------------------------
-- Buchwerk. Kein Geometrie ??

CREATE TABLE ax_namensnummer (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	anlass integer,
	laufendenummernachdin1421 character(16),
	eigentuemerart integer,
	istbestandteilvon character varying,
	benennt character varying,
	zaehler double precision,
	nenner integer,
	art character(37),
	uri character(28),
	artderrechtsgemeinschaft integer,
	beschriebderrechtsgemeinschaft character(61) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_namensnummer','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_namensnummer', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_namensnummer
	ADD CONSTRAINT ax_namensnummer_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_namensnummer_geom_idx ON ax_namensnummer USING gist (wkb_geometry);


-- N  a t u r -,  U m w e l t -   o d e r   B o d e n s c h u t z r e c h t
-- ------------------------------------------------------------------------


CREATE TABLE ax_naturumweltoderbodenschutzrecht (
  ogc_fid serial NOT NULL,
  --wkb_geometry geometry,
  gml_id character(16),
  beginnt character(20),
  advstandardmodell character(4),
  sonstigesmodell character(6),
  anlass integer,
  artderfestlegung integer,
  CONSTRAINT ax_naturumweltoderbodenschutzrecht_pk PRIMARY KEY (ogc_fid) --,
  --CONSTRAINT enforce_dims_wkb_geometry CHECK (ndims(wkb_geometry) = 2),
  --CONSTRAINT enforce_geotype_wkb_geometry CHECK (geometrytype(wkb_geometry) = 'POLYGON'::text OR wkb_geometry IS NULL),
  --CONSTRAINT enforce_srid_wkb_geometry CHECK (srid(wkb_geometry) = 25832)
);

SELECT AddGeometryColumn('ax_naturumweltoderbodenschutzrecht','wkb_geometry','25832','POLYGON',2);

CREATE INDEX ax_naturumweltoderbodenschutzrecht_geom_idx
  ON ax_naturumweltoderbodenschutzrecht USING gist (wkb_geometry);


-- P e r s o n
-- ----------------------------------------------
-- Buchwerk. Keine Geometrie ??
-- Der Konverter versucht, die Tabelle noch einmal anzulegen!!

CREATE TABLE ax_person (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	nachnameoderfirma character(90),  --(89),
	anrede integer,
	vorname character(40),            --(25),
	geburtsname character(50),        --(14),
	hat character varying,
	geburtsdatum character(10),       -- Datumsformat?
	namensbestandteil character(15),
	akademischergrad character(8),
	art character(37),
	uri character(28)  --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_person','wkb_geometry','25832','POINT',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_person', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_person
	ADD CONSTRAINT ax_person_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_person_geom_idx ON ax_person USING gist (wkb_geometry);


-- P l a t z
-- ----------------------------------------------

CREATE TABLE ax_platz (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	funktion integer,
	land integer,
	regierungsbezirk integer,
	kreis integer,
	gemeinde integer,
	lage integer,
	unverschluesselt character(16)
);

--	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
--	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ax_platz','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_platz
	ADD CONSTRAINT ax_platz_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_platz_geom_idx ON ax_platz USING gist (wkb_geometry);


-- P u n k t o r t   AG
-- ----------------------------------------------

CREATE TABLE ax_punktortag (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	art character varying[],
	name character(9),
	istteilvon character varying,
	kartendarstellung character(4),
	koordinatenstatus integer,
	hinweise character(11),
	description integer,
	"qualitaetsangaben|ax_dqpunktort|herkunft|li_lineage|processstep" character varying[],
	datetime character varying[],
	individualname character(7),
	role character(16),
	genauigkeitsstufe integer,
	uri character(28)
);

--	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POINT'::text) OR (wkb_geometry IS NULL))),
--	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ax_punktortag','wkb_geometry','25832','POINT',2);

ALTER TABLE ONLY ax_punktortag
	ADD CONSTRAINT ax_punktortag_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_punktortag_geom_idx ON ax_punktortag USING gist (wkb_geometry);


-- P u n k t o r t   A U
-- ----------------------------------------------

CREATE TABLE ax_punktortau (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	art character(61),
	name character(9),
	istteilvon character varying,
	kartendarstellung character(5),
	koordinatenstatus integer,
	hinweise character(11),
	description integer,
	"qualitaetsangaben|ax_dqpunktort|herkunft|li_lineage|processstep" character varying[],
	datetime character varying[],
	individualname character(7),
	role character(16),
	genauigkeitsstufe integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POINT'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_punktortau','wkb_geometry','25832','POINT',2);

ALTER TABLE ONLY ax_punktortau
	ADD CONSTRAINT ax_punktortau_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_punktortau_geom_idx ON ax_punktortau USING gist (wkb_geometry);


-- P u n k t o r t   TA
-- ----------------------------------------------

CREATE TABLE ax_punktortta (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(5),
	anlass integer,
	istteilvon character varying,
	kartendarstellung character(4),
	description integer,
	art character(61),
	name character(9),
	koordinatenstatus integer,
	hinweise character(11),
	"qualitaetsangaben|ax_dqpunktort|herkunft|li_lineage|processstep" character varying[],
	datetime character varying[],
	individualname character(7),
	role character(16),
	genauigkeitsstufe integer
);

--	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POINT'::text) OR (wkb_geometry IS NULL))),
--	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ax_punktortta','wkb_geometry','25832','POINT',2);

ALTER TABLE ONLY ax_punktortta
	ADD CONSTRAINT ax_punktortta_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_punktortta_geom_idx ON ax_punktortta USING gist (wkb_geometry);



-- R e g i e r u n g s b e z i r k
-- ----------------------------------------------

CREATE TABLE ax_regierungsbezirk (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	schluesselgesamt integer,
	bezeichnung character(11),
	land integer,
	regierungsbezirk integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_regierungsbezirk','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_regierungsbezirk', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_regierungsbezirk
	ADD CONSTRAINT ax_regierungsbezirk_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_regierungsbezirk_geom_idx ON ax_regierungsbezirk USING gist (wkb_geometry);


-- S c h u t z g e b i e t   n a c h   W a s s s e r r e c h t
-- -----------------------------------------------------------

CREATE TABLE ax_schutzgebietnachwasserrecht (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	artderfestlegung integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_schutzgebietnachwasserrecht','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_schutzgebietnachwasserrecht', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_schutzgebietnachwasserrecht
	ADD CONSTRAINT ax_schutzgebietnachwasserrecht_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_schutzgebietnachwasserrecht_geom_idx ON ax_schutzgebietnachwasserrecht USING gist (wkb_geometry);


-- S c h u t z z o n e
-- ----------------------------------------------

CREATE TABLE ax_schutzzone (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	istteilvon character varying,
	zone integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_schutzzone','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_schutzzone
	ADD CONSTRAINT ax_schutzzone_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_schutzzone_geom_idx ON ax_schutzzone USING gist (wkb_geometry);


-- s o n s t i g e r   V e r m e s s u n g s p u n k t
-- ---------------------------------------------------

CREATE TABLE ax_sonstigervermessungspunkt (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(6),
	anlass integer,
	vermarkung_marke integer,
	punktkennung integer,
	land integer,
	stelle integer,
	sonstigeeigenschaft character varying[] --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

--SELECT AddGeometryColumn('ax_sonstigervermessungspunkt','wkb_geometry','25832','___',2);
INSERT INTO geometry_columns 
       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
VALUES ('', 'public', 'ax_sonstigervermessungspunkt', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_sonstigervermessungspunkt
	ADD CONSTRAINT ax_sonstigervermessungspunkt_pk PRIMARY KEY (ogc_fid);

--CREATE INDEX ax_sonstigervermessungspunkt_geom_idx ON ax_sonstigervermessungspunkt USING gist (wkb_geometry);


-- sonstiges Bauwerk oder sonstige Einrichtung
-- ----------------------------------------------

CREATE TABLE ax_sonstigesbauwerkodersonstigeeinrichtung (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	description integer,
	bauwerksfunktion integer,
	gehoertzu character varying --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_sonstigesbauwerkodersonstigeeinrichtung','wkb_geometry','25832','POLYGON',2);
-- POLYGON  und LINESTRING
ALTER TABLE ax_sonstigesbauwerkodersonstigeeinrichtung
DROP CONSTRAINT enforce_geotype_wkb_geometry;

--INSERT INTO geometry_columns 
--       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
--VALUES ('', 'public', 'ax_sonstigesbauwerkodersonstigeeinrichtung', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_sonstigesbauwerkodersonstigeeinrichtung
	ADD CONSTRAINT ax_sonstigesbauwerkodersonstigeeinrichtung_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_sonstigesbauwerkodersonstigeeinrichtung_geom_idx ON ax_sonstigesbauwerkodersonstigeeinrichtung USING gist (wkb_geometry);


-- S p o r t - ,   F r e i z e i t -   u n d   E r h o h l u n g s f l � c h e
-- ---------------------------------------------------------------------------

CREATE TABLE ax_sportfreizeitunderholungsflaeche (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	funktion integer,
	zustand integer,
	name character(10)
);

--	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
--	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ax_sportfreizeitunderholungsflaeche','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_sportfreizeitunderholungsflaeche
	ADD CONSTRAINT ax_sportfreizeitunderholungsflaeche_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_sportfreizeitunderholungsflaeche_geom_idx ON ax_sportfreizeitunderholungsflaeche USING gist (wkb_geometry);


-- s t e h e n d e s   G e w a e s s e r
-- ----------------------------------------------

CREATE TABLE ax_stehendesgewaesser (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	funktion integer,
	land integer,
	regierungsbezirk integer,
	kreis integer,
	gemeinde integer,
	lage integer,
	unverschluesselt character(13) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_stehendesgewaesser','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_stehendesgewaesser
	ADD CONSTRAINT ax_stehendesgewaesser_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_stehendesgewaesser_geom_idx ON ax_stehendesgewaesser USING gist (wkb_geometry);


-- S t r a s s e n v e r k e h r
-- ----------------------------------------------

CREATE TABLE ax_strassenverkehr (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	land integer,
	regierungsbezirk integer,
	kreis integer,
	gemeinde integer,
	lage integer,
	funktion integer,
	unverschluesselt character(27),
	zweitname character(41)
);

--	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
--	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ax_strassenverkehr','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_strassenverkehr
	ADD CONSTRAINT ax_strassenverkehr_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_strassenverkehr_geom_idx ON ax_strassenverkehr USING gist (wkb_geometry);


-- S t r a s s e n v e r k e h r s a n l a g e
-- ----------------------------------------------

CREATE TABLE ax_strassenverkehrsanlage (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	art integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'LINESTRING'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_strassenverkehrsanlage','wkb_geometry','25832','POLYGON',2);
-- LINESTRING und POLYGON
ALTER TABLE ax_strassenverkehrsanlage
	DROP CONSTRAINT enforce_geotype_wkb_geometry;

ALTER TABLE ONLY ax_strassenverkehrsanlage
	ADD CONSTRAINT ax_strassenverkehrsanlage_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_strassenverkehrsanlage_geom_idx ON ax_strassenverkehrsanlage USING gist (wkb_geometry);


-- S u m p f
-- ----------------------------------------------


CREATE TABLE ax_sumpf (
  ogc_fid serial NOT NULL,
  --wkb_geometry geometry,
  gml_id character(16),
  beginnt character(20),
  advstandardmodell character(4),
  sonstigesmodell character(5),
  anlass integer,
  CONSTRAINT ax_sumpf_pk PRIMARY KEY (ogc_fid) --,
  --CONSTRAINT enforce_dims_wkb_geometry CHECK (ndims(wkb_geometry) = 2),
  --CONSTRAINT enforce_geotype_wkb_geometry CHECK (geometrytype(wkb_geometry) = 'POLYGON'::text OR wkb_geometry IS NULL),
  --CONSTRAINT enforce_srid_wkb_geometry CHECK (srid(wkb_geometry) = 25832)
);

SELECT AddGeometryColumn('ax_sumpf','wkb_geometry','25832','POLYGON',2);

CREATE INDEX ax_sumpf_geom_idx ON ax_sumpf USING gist (wkb_geometry);


-- T a g e b a u  /  G r u b e  /  S t e i n b r u c h
-- ---------------------------------------------------

CREATE TABLE ax_tagebaugrubesteinbruch (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	abbaugut integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_tagebaugrubesteinbruch','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_tagebaugrubesteinbruch
	ADD CONSTRAINT ax_tagebaugrubesteinbruch_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_tagebaugrubesteinbruch_geom_idx ON ax_tagebaugrubesteinbruch USING gist (wkb_geometry);


-- T r a n s p o r t a n l a g e
-- ---------------------------------------------------

CREATE TABLE ax_transportanlage (
  ogc_fid serial NOT NULL,
  --wkb_geometry geometry,
  gml_id character(16),
  beginnt character(20),
  advstandardmodell character(4),
  sonstigesmodell character varying[],
  anlass integer,
  bauwerksfunktion integer --,
  CONSTRAINT ax_transportanlage_pk PRIMARY KEY (ogc_fid),
  --CONSTRAINT enforce_dims_wkb_geometry CHECK (ndims(wkb_geometry) = 2),
  --CONSTRAINT enforce_geotype_wkb_geometry CHECK (geometrytype(wkb_geometry) = 'LINESTRING'::text OR wkb_geometry IS NULL),
  --CONSTRAINT enforce_srid_wkb_geometry CHECK (srid(wkb_geometry) = 25832)
);

SELECT AddGeometryColumn('ax_transportanlage','wkb_geometry','25832','LINESTRING',2);

CREATE INDEX ax_transportanlage_geom_idx ON ax_transportanlage USING gist (wkb_geometry);


-- U n l a n d  /  V e g e t a t i o n s f l a e c h e
-- ---------------------------------------------------

CREATE TABLE ax_unlandvegetationsloseflaeche (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(5),
	anlass integer,
	funktion integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_unlandvegetationsloseflaeche','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_unlandvegetationsloseflaeche
	ADD CONSTRAINT ax_unlandvegetationsloseflaeche_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_unlandvegetationsloseflaeche_geom_idx ON ax_unlandvegetationsloseflaeche USING gist (wkb_geometry);


-- u n t e r g e o r d n e t e s   G e w a e s s e r
-- -------------------------------------------------

CREATE TABLE ax_untergeordnetesgewaesser (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	funktion integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'LINESTRING'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_untergeordnetesgewaesser','wkb_geometry','25832','LINESTRING',2);
-- LINESTRING und POLYGON
ALTER TABLE ax_untergeordnetesgewaesser
	DROP CONSTRAINT enforce_geotype_wkb_geometry;

ALTER TABLE ONLY ax_untergeordnetesgewaesser
	ADD CONSTRAINT ax_untergeordnetesgewaesser_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_untergeordnetesgewaesser_geom_idx ON ax_untergeordnetesgewaesser USING gist (wkb_geometry);


-- V e g a t a t i o n s m e r k m a l
-- ----------------------------------------------

CREATE TABLE ax_vegetationsmerkmal (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id			character(16),
	beginnt			character(20),
	advstandardmodell	character(4),
	sonstigesmodell		character(5),
	anlass			integer,
	bewuchs			integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_vegetationsmerkmal','wkb_geometry','25832','POLYGON',2);

-- ??? <GeometryType>3</GeometryType>
ALTER TABLE ONLY ax_vegetationsmerkmal
	DROP CONSTRAINT enforce_geotype_wkb_geometry;

--INSERT INTO geometry_columns 
--       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
--VALUES ('', 'public', 'ax_vegetationsmerkmal', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_vegetationsmerkmal
	ADD CONSTRAINT ax_vegetationsmerkmal_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_vegetationsmerkmal_geom_idx ON ax_vegetationsmerkmal USING gist (wkb_geometry);


-- V o r r a t s b e h a e l t e r  /  S p e i c h e r b a u w e r k
-- -----------------------------------------------------------------

CREATE TABLE ax_vorratsbehaelterspeicherbauwerk (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	speicherinhalt integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_vorratsbehaelterspeicherbauwerk','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_vorratsbehaelterspeicherbauwerk
	ADD CONSTRAINT ax_vorratsbehaelterspeicherbauwerk_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_vorratsbehaelterspeicherbauwerk_geom_idx ON ax_vorratsbehaelterspeicherbauwerk USING gist (wkb_geometry);


-- W a l d 
-- ----------------------------------------------

CREATE TABLE ax_wald (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character(5),
	anlass integer,
	vegetationsmerkmal integer
);

--	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
--	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ax_wald','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_wald
	ADD CONSTRAINT ax_wald_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_wald_geom_idx ON ax_wald USING gist (wkb_geometry);


-- W e g 
-- ----------------------------------------------

CREATE TABLE ax_weg (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	funktion integer,
	land integer,
	regierungsbezirk integer,
	kreis integer,
	gemeinde integer,
	lage integer,
	unverschluesselt character(40) --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);

SELECT AddGeometryColumn('ax_weg','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_weg
	ADD CONSTRAINT ax_weg_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_weg_geom_idx ON ax_weg USING gist (wkb_geometry);


-- W e g  /  P f a d  /  S t e i g
-- ----------------------------------------------

CREATE TABLE ax_wegpfadsteig (
	ogc_fid serial NOT NULL,
	--wkb_geometry geometry,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	art integer --,
	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


SELECT AddGeometryColumn('ax_wegpfadsteig','wkb_geometry','25832','LINESTRING',2);

-- LINESTRING und POLYGON
ALTER TABLE ax_wegpfadsteig 
	DROP CONSTRAINT enforce_geotype_wkb_geometry;

--INSERT INTO geometry_columns 
--       (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, type)
--VALUES ('', 'public', 'ax_wegpfadsteig', 'dummy', 2, 25832, 'POINT');

ALTER TABLE ONLY ax_wegpfadsteig
	ADD CONSTRAINT ax_wegpfadsteig_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_wegpfadsteig_geom_idx ON ax_wegpfadsteig USING gist (wkb_geometry);


-- W o h n b a u f l a e c h e
-- ----------------------------------------------

CREATE TABLE ax_wohnbauflaeche (
	ogc_fid serial NOT NULL,
	gml_id character(16),
	beginnt character(20),
	advstandardmodell character(4),
	sonstigesmodell character varying[],
	anlass integer,
	artderbebauung integer,
	zustand integer,
	art character(37),
	uri character(28)
);

--	--CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
--	--CONSTRAINT enforce_geotype_wkb_geometry CHECK (((geometrytype(wkb_geometry) = 'POLYGON'::text) OR (wkb_geometry IS NULL))),
--	--CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))

SELECT AddGeometryColumn('ax_wohnbauflaeche','wkb_geometry','25832','POLYGON',2);

ALTER TABLE ONLY ax_wohnbauflaeche
	ADD CONSTRAINT ax_wohnbauflaeche_pk PRIMARY KEY (ogc_fid);

CREATE INDEX ax_wohnbauflaeche_geom_idx ON ax_wohnbauflaeche USING gist (wkb_geometry);


--
--                         the Happy END
--
