delete from ax_tatsaechlichenutzung;

--Objektartengruppe Siedlung
----------------------------
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, artderbebauung, zustand) SELECT gml_id, wkb_geometry, 41001 as objektartengruppe, name, artderbebauung, zustand FROM ax_wohnbauflaeche;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, zustand, foerdergut, lagergut, primaerenergie) SELECT gml_id, wkb_geometry, 41002 as objektartengruppe, name, zustand, foerdergut, lagergut, primaerenergie FROM ax_industrieundgewerbeflaeche;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, zustand, lagergut) SELECT gml_id, wkb_geometry, 41003 as objektartengruppe, name, zustand, lagergut FROM ax_halde;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, bezeichnung, zustand, abbaugut) SELECT gml_id, wkb_geometry, 41004 as objektartengruppe, name, bezeichnung, zustand, abbaugut FROM ax_bergbaubetrieb;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, zustand, abbaugut) SELECT gml_id, wkb_geometry, 41005 as objektartengruppe, name, zustand, abbaugut FROM ax_tagebaugrubesteinbruch;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, artderbebauung, zustand, funktion) SELECT gml_id, wkb_geometry, 41006 as objektartengruppe, name, artderbebauung, zustand, funktion FROM ax_flaechegemischternutzung;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, artderbebauung, zustand, funktion) SELECT gml_id, wkb_geometry, 41007 as objektartengruppe, name, artderbebauung, zustand, funktion FROM ax_flaechebesondererfunktionalerpraegung;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, zustand, funktion) SELECT gml_id, wkb_geometry, 41008 as objektartengruppe, name, zustand, funktion FROM ax_sportfreizeitunderholungsflaeche;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, zustand, funktion) SELECT gml_id, wkb_geometry, 41009 as objektartengruppe, name, zustand, funktion FROM ax_friedhof;

--Objektartengruppe Verkehr
---------------------------
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, zustand, funktion, zweitname, lage, bezlage) SELECT gml_id, wkb_geometry, 42001 as objektartengruppe, zustand, funktion, zweitname, case when lage is null then null else lpad(trim(both ' ' from lage),5,'0') end as lage, unverschluesselt FROM ax_strassenverkehr;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, bezeichnung, funktion, lage, bezlage) SELECT gml_id, wkb_geometry, 42006 as objektartengruppe, bezeichnung, funktion, case when lage is null then null else lpad(trim(both ' ' from lage),5,'0') end as lage, unverschluesselt FROM ax_weg;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, zweitname, funktion, lage, bezlage) SELECT gml_id, wkb_geometry, 42009 as objektartengruppe, zweitname, funktion, case when lage is null then null else lpad(trim(both ' ' from lage),5,'0') end as lage, unverschluesselt FROM ax_platz;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, zweitname, funktion, bahnkategorie, bezeichnung, nummerderbahnstrecke, zustand) SELECT gml_id, wkb_geometry, 42010 as objektartengruppe, zweitname, funktion, bahnkategorie, bezeichnung, nummerderbahnstrecke, zustand FROM ax_bahnverkehr;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, funktion, art, bezeichnung, zustand, nutzung, lage, bezlage) SELECT gml_id, wkb_geometry, 42015 as objektartengruppe, funktion, art, bezeichnung, zustand, nutzung, case when lage is null then null else lpad(trim(both ' ' from lage),5,'0') end as lage, unverschluesselt FROM ax_flugverkehr;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, funktion, zustand, lage, bezlage) SELECT gml_id, wkb_geometry, 42016 as objektartengruppe, funktion, zustand, case when lage is null then null else lpad(trim(both ' ' from lage),5,'0') end as lage, unverschluesselt FROM ax_schiffsverkehr;

--Objektartengruppe Vegetation
------------------------------
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, vegetationsmerkmal) SELECT gml_id, wkb_geometry, 43001 as objektartengruppe, name, vegetationsmerkmal FROM ax_landwirtschaft;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, vegetationsmerkmal) SELECT gml_id, wkb_geometry, 43002 as objektartengruppe, name, vegetationsmerkmal FROM ax_wald;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, vegetationsmerkmal, funktion) SELECT gml_id, wkb_geometry, 43003 as objektartengruppe, name, vegetationsmerkmal,funktion FROM ax_gehoelz;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name) SELECT gml_id, wkb_geometry, 43004 as objektartengruppe, name FROM ax_heide;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name) SELECT gml_id, wkb_geometry, 43005 as objektartengruppe, name FROM ax_moor;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name) SELECT gml_id, wkb_geometry, 43006 as objektartengruppe, name FROM ax_sumpf;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, oberflaechenmaterial, funktion) SELECT gml_id, wkb_geometry, 43007 as objektartengruppe, name, oberflaechenmaterial, funktion FROM ax_unlandvegetationsloseflaeche;

--Objektartengruppe Gew�sser
------------------------------
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, funktion, zustand, lage, bezlage) SELECT gml_id, wkb_geometry, 44001 as objektartengruppe, funktion, zustand, case when lage is null then null else lpad(trim(both ' ' from lage),5,'0') end as lage, unverschluesselt FROM ax_fliessgewaesser;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, funktion, nutzung, lage, bezlage) SELECT gml_id, wkb_geometry, 44005 as objektartengruppe, funktion, nutzung, case when lage is null then null else lpad(trim(both ' ' from lage),5,'0') end as lage, unverschluesselt FROM ax_hafenbecken;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, funktion, gewaesserkennziffer, hydrologischesmerkmal, lage, bezlage) SELECT gml_id, wkb_geometry, 44006 as objektartengruppe, funktion, gewaesserkennziffer, hydrologischesmerkmal, case when lage is null then null else lpad(trim(both ' ' from lage),5,'0') end as lage, unverschluesselt FROM ax_stehendesgewaesser;
insert into ax_tatsaechlichenutzung (gml_id, wkb_geometry, objektartengruppe, name, funktion, bezeichnung, tidemerkmal) SELECT gml_id, wkb_geometry, 44007 as objektartengruppe, name, funktion, bezeichnung, tidemerkmal FROM ax_meer;

--Texte aus den Schl�sseltabellen f�llen
----------------------------------------
update ax_tatsaechlichenutzung set bezobjektartengruppe = (select objektartengruppe from v_nutzungen_objektartengruppen where id = ax_tatsaechlichenutzung.objektartengruppe) where ax_tatsaechlichenutzung.objektartengruppe > 0;
update ax_tatsaechlichenutzung set bezartderbebauung = (select artderbebauung from v_nutzungen_artderbebauung where id = ax_tatsaechlichenutzung.artderbebauung) where ax_tatsaechlichenutzung.artderbebauung > 0;
update ax_tatsaechlichenutzung set bezzustand = (select zustand from v_nutzungen_zustand where id = ax_tatsaechlichenutzung.zustand) where ax_tatsaechlichenutzung.zustand > 0;
update ax_tatsaechlichenutzung set bezlagergut = (select lagergut from v_nutzungen_lagergut where id = ax_tatsaechlichenutzung.lagergut) where ax_tatsaechlichenutzung.lagergut > 0;
update ax_tatsaechlichenutzung set bezfoerdergut = (select foerdergut from v_nutzungen_foerdergut where id = ax_tatsaechlichenutzung.foerdergut) where ax_tatsaechlichenutzung.foerdergut > 0;
update ax_tatsaechlichenutzung set bezprimaerenergie = (select primaerenergie from v_nutzungen_primaerenergie where id = ax_tatsaechlichenutzung.primaerenergie) where ax_tatsaechlichenutzung.primaerenergie > 0;
update ax_tatsaechlichenutzung set bezabbaugut = (select abbaugut from v_nutzungen_abbaugut where id = ax_tatsaechlichenutzung.abbaugut) where ax_tatsaechlichenutzung.abbaugut > 0;
update ax_tatsaechlichenutzung set bezfunktion = (select funktion from v_nutzungen_funktion where id = ax_tatsaechlichenutzung.funktion and v_nutzungen_funktion.idobjektartengruppe = ax_tatsaechlichenutzung.objektartengruppe) where ax_tatsaechlichenutzung.funktion > 0;
update ax_tatsaechlichenutzung set bezbahnkategorie = (select bahnkategorie from v_nutzungen_bahnkategorie where id = ax_tatsaechlichenutzung.bahnkategorie) where ax_tatsaechlichenutzung.bahnkategorie > 0;
update ax_tatsaechlichenutzung set bezart = (select art from v_nutzungen_art where id = ax_tatsaechlichenutzung.art) where ax_tatsaechlichenutzung.art > 0;
update ax_tatsaechlichenutzung set beznutzung = (select nutzung from v_nutzungen_nutzung where id = ax_tatsaechlichenutzung.nutzung) where ax_tatsaechlichenutzung.nutzung > 0;
update ax_tatsaechlichenutzung set bezvegetationsmerkmal = (select vegetationsmerkmal from v_nutzungen_vegetationsmerkmal where v_nutzungen_vegetationsmerkmal.id = ax_tatsaechlichenutzung.vegetationsmerkmal and v_nutzungen_vegetationsmerkmal.idobjektartengruppe = ax_tatsaechlichenutzung.objektartengruppe) where ax_tatsaechlichenutzung.vegetationsmerkmal > 0;
update ax_tatsaechlichenutzung set bezoberflaechenmaterial = (select oberflaechenmaterial from v_nutzungen_oberflaechenmaterial where id = ax_tatsaechlichenutzung.oberflaechenmaterial) where ax_tatsaechlichenutzung.oberflaechenmaterial > 0;
update ax_tatsaechlichenutzung set bezhydrologischesmerkmal = (select hydrologischesmerkmal from v_nutzungen_hydrologischesmerkmal where id = ax_tatsaechlichenutzung.hydrologischesmerkmal) where ax_tatsaechlichenutzung.hydrologischesmerkmal > 0;
update ax_tatsaechlichenutzung set beztidemerkmal = (select tidemerkmal from v_nutzungen_tidemerkmal where id = ax_tatsaechlichenutzung.tidemerkmal) where ax_tatsaechlichenutzung.tidemerkmal > 0;
update ax_tatsaechlichenutzung set bezlage = (select bezeichnung as bezlage from ax_lagebezeichnungkatalogeintrag where lage = ax_tatsaechlichenutzung.lage) where not ax_tatsaechlichenutzung.lage is null;
