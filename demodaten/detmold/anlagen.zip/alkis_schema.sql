--
-- PostgreSQL database dump
--

-- Started on 2009-05-13 08:16:07

SET client_encoding = 'WIN1252';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- TOC entry 931 (class 0 OID 0)
-- Name: geometry; Type: SHELL TYPE; Schema: public; Owner: postgres
--

CREATE TYPE geometry;


--
-- TOC entry 22 (class 1255 OID 7505449)
-- Dependencies: 3
-- Name: st_geometry_analyze(internal); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_analyze(internal) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_analyze'
    LANGUAGE c STRICT;


ALTER FUNCTION public.st_geometry_analyze(internal) OWNER TO postgres;

--
-- TOC entry 23 (class 1255 OID 7505450)
-- Dependencies: 3 931
-- Name: st_geometry_in(cstring); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_in(cstring) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_in(cstring) OWNER TO postgres;

--
-- TOC entry 24 (class 1255 OID 7505451)
-- Dependencies: 3 931
-- Name: st_geometry_out(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_out(geometry) RETURNS cstring
    AS '$libdir/liblwgeom', 'LWGEOM_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_out(geometry) OWNER TO postgres;

--
-- TOC entry 25 (class 1255 OID 7505452)
-- Dependencies: 3 931
-- Name: st_geometry_recv(internal); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_recv(internal) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_recv'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_recv(internal) OWNER TO postgres;

--
-- TOC entry 26 (class 1255 OID 7505453)
-- Dependencies: 3 931
-- Name: st_geometry_send(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_send(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_send'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_send(geometry) OWNER TO postgres;

--
-- TOC entry 930 (class 1247 OID 7505448)
-- Dependencies: 25 26 24 22 23 3
-- Name: geometry; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE geometry (
    INTERNALLENGTH = variable,
    INPUT = st_geometry_in,
    OUTPUT = st_geometry_out,
    RECEIVE = st_geometry_recv,
    SEND = st_geometry_send,
    ANALYZE = st_geometry_analyze,
    DELIMITER = ':',
    ALIGNMENT = int4,
    STORAGE = main
);


ALTER TYPE public.geometry OWNER TO postgres;

--
-- TOC entry 27 (class 1255 OID 7505455)
-- Dependencies: 3 930
-- Name: ndims(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION ndims(geometry) RETURNS smallint
    AS '$libdir/liblwgeom', 'LWGEOM_ndims'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.ndims(geometry) OWNER TO postgres;

--
-- TOC entry 28 (class 1255 OID 7505456)
-- Dependencies: 930 3
-- Name: srid(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION srid(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_getSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.srid(geometry) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 2689 (class 1259 OID 7505457)
-- Dependencies: 3215 3216 930 3
-- Name: ap_darstellung; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ap_darstellung (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(8),
    anlass integer,
    art character(37),
    uri character(28),
    signaturnummer integer,
    art_ character(3),
    dientzurdarstellungvon character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ap_darstellung OWNER TO postgres;

--
-- TOC entry 2690 (class 1259 OID 7505466)
-- Dependencies: 3218 3219 3 930
-- Name: ap_lpo; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ap_lpo (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character varying[],
    anlass integer,
    art character(5),
    dientzurdarstellungvon character varying,
    "zeigtaufexternes|aa_fachdatenverbindung|art" character(37),
    uri character(28),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ap_lpo OWNER TO postgres;

--
-- TOC entry 2691 (class 1259 OID 7505474)
-- Dependencies: 3221 3222 930 3
-- Name: ap_lto; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ap_lto (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character varying[],
    sonstigesmodell character(7),
    anlass integer,
    art character(15),
    dientzurdarstellungvon character varying,
    schriftinhalt character varying,
    fontsperrung integer,
    skalierung integer,
    horizontaleausrichtung character(12),
    vertikaleausrichtung character(5),
    "zeigtaufexternes|aa_fachdatenverbindung|art" character(37),
    uri character(28),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ap_lto OWNER TO postgres;

--
-- TOC entry 2692 (class 1259 OID 7505482)
-- Dependencies: 3224 3225 3 930
-- Name: ap_ppo; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ap_ppo (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character varying[],
    anlass integer,
    art character(37),
    uri character(28),
    art_ character(11),
    dientzurdarstellungvon character varying,
    drehwinkel double precision,
    sonstigesmodell character(7),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ap_ppo OWNER TO postgres;

--
-- TOC entry 2693 (class 1259 OID 7505490)
-- Dependencies: 3227 3228 930 3
-- Name: ap_pto; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ap_pto (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character varying[],
    anlass integer,
    art character(37),
    uri character(57),
    art_ character(15),
    dientzurdarstellungvon character varying,
    fontsperrung integer,
    skalierung double precision,
    horizontaleausrichtung character(12),
    vertikaleausrichtung character(5),
    drehwinkel double precision,
    schriftinhalt character varying,
    hat character varying,
    sonstigesmodell character(7),
    signaturnummer integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ap_pto OWNER TO postgres;

--
-- TOC entry 2694 (class 1259 OID 7505498)
-- Dependencies: 3230 3231 3 930
-- Name: ax_anschrift; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_anschrift (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    ort_post character(26),
    postleitzahlpostzustellung integer,
    bestimmungsland character(18),
    strasse character(29),
    hausnummer character(9),
    art character(37),
    uri character(28),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_anschrift OWNER TO postgres;

--
-- TOC entry 2695 (class 1259 OID 7505506)
-- Dependencies: 3233 3234 3 930
-- Name: ax_aufnahmepunkt; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_aufnahmepunkt (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    anlass integer,
    punktkennung integer,
    land integer,
    stelle integer,
    sonstigeeigenschaft character varying[],
    vermarkung_marke integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_aufnahmepunkt OWNER TO postgres;

--
-- TOC entry 2696 (class 1259 OID 7505514)
-- Dependencies: 3236 3237 3238 3239 3240 930 3
-- Name: ax_bahnverkehr; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_bahnverkehr (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    bahnkategorie integer DEFAULT 0,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    lage character(5),
    funktion integer DEFAULT 0,
    bezeichnung character varying,
    nummerderbahnstrecke character varying,
    zweitname character varying,
    zustand integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_bahnverkehr OWNER TO postgres;

--
-- TOC entry 2697 (class 1259 OID 7505522)
-- Dependencies: 3242 3243 930 3
-- Name: ax_bauraumoderbodenordnungsrecht; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_bauraumoderbodenordnungsrecht (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    artderfestlegung integer,
    bezeichnung character(13),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_bauraumoderbodenordnungsrecht OWNER TO postgres;

--
-- TOC entry 2698 (class 1259 OID 7505530)
-- Dependencies: 3245 3246 3 930
-- Name: ax_bauteil; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_bauteil (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    art character(37),
    uri character(28),
    bauart integer,
    lagezurerdoberflaeche integer,
    anzahlderoberirdischengeschosse integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_bauteil OWNER TO postgres;

--
-- TOC entry 2699 (class 1259 OID 7505538)
-- Dependencies: 3248 3249 3 930
-- Name: ax_bauwerkimgewaesserbereich; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_bauwerkimgewaesserbereich (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    bauwerksfunktion integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_bauwerkimgewaesserbereich OWNER TO postgres;

--
-- TOC entry 2700 (class 1259 OID 7505546)
-- Dependencies: 3251 3252 930 3
-- Name: ax_bauwerkimverkehrsbereich; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_bauwerkimverkehrsbereich (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    bauwerksfunktion integer,
    description integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_bauwerkimverkehrsbereich OWNER TO postgres;

--
-- TOC entry 2701 (class 1259 OID 7505554)
-- Dependencies: 3254 3255 930 3
-- Name: ax_bauwerkoderanlagefuerindustrieundgewerbe; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_bauwerkoderanlagefuerindustrieundgewerbe (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    bauwerksfunktion integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_bauwerkoderanlagefuerindustrieundgewerbe OWNER TO postgres;

--
-- TOC entry 2702 (class 1259 OID 7505562)
-- Dependencies: 3257 3258 3 930
-- Name: ax_bauwerkoderanlagefuersportfreizeitunderholung; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_bauwerkoderanlagefuersportfreizeitunderholung (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    description integer,
    bauwerksfunktion integer,
    name character varying,
    sportart integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_bauwerkoderanlagefuersportfreizeitunderholung OWNER TO postgres;

--
-- TOC entry 2903 (class 1259 OID 15116067)
-- Dependencies: 3540 3541 3542 930 3
-- Name: ax_bergbaubetrieb; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_bergbaubetrieb (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    abbaugut integer,
    name character varying,
    bezeichnung character varying,
    zustand integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_bergbaubetrieb OWNER TO postgres;

--
-- TOC entry 2703 (class 1259 OID 7505570)
-- Dependencies: 3260 3261 930 3
-- Name: ax_besondereflurstuecksgrenze; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_besondereflurstuecksgrenze (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(5),
    anlass integer,
    art character(37),
    uri character(28),
    artderflurstuecksgrenze integer[],
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_besondereflurstuecksgrenze OWNER TO postgres;

--
-- TOC entry 2704 (class 1259 OID 7505578)
-- Dependencies: 3263 3264 930 3
-- Name: ax_besonderegebaeudelinie; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_besonderegebaeudelinie (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    beschaffenheit integer,
    anlass integer,
    art character(37),
    uri character(28),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_besonderegebaeudelinie OWNER TO postgres;

--
-- TOC entry 2705 (class 1259 OID 7505586)
-- Dependencies: 3266 3267 930 3
-- Name: ax_besondererbauwerkspunkt; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_besondererbauwerkspunkt (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    punktkennung integer,
    land integer,
    stelle integer,
    sonstigeeigenschaft character(26),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_besondererbauwerkspunkt OWNER TO postgres;

--
-- TOC entry 2706 (class 1259 OID 7505594)
-- Dependencies: 3269 3270 930 3
-- Name: ax_besonderergebaeudepunkt; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_besonderergebaeudepunkt (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    punktkennung integer,
    land integer,
    stelle integer,
    sonstigeeigenschaft character(26),
    art character(37),
    uri character(28),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_besonderergebaeudepunkt OWNER TO postgres;

--
-- TOC entry 2707 (class 1259 OID 7505602)
-- Dependencies: 3272 3273 930 3
-- Name: ax_besonderertopographischerpunkt; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_besonderertopographischerpunkt (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    punktkennung integer,
    land integer,
    stelle integer,
    sonstigeeigenschaft character(26),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_besonderertopographischerpunkt OWNER TO postgres;

--
-- TOC entry 2708 (class 1259 OID 7505610)
-- Dependencies: 3275 3276 3 930
-- Name: ax_bodenschaetzung; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_bodenschaetzung (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    anlass integer,
    kulturart integer,
    bodenart integer,
    zustandsstufeoderbodenstufe integer,
    entstehungsartoderklimastufewasserverhaeltnisse integer[],
    bodenzahlodergruenlandgrundzahl integer,
    ackerzahlodergruenlandzahl integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_bodenschaetzung OWNER TO postgres;

--
-- TOC entry 2709 (class 1259 OID 7505618)
-- Dependencies: 3278 3279 930 3
-- Name: ax_boeschungkliff; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_boeschungkliff (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_boeschungkliff OWNER TO postgres;

--
-- TOC entry 2710 (class 1259 OID 7505626)
-- Dependencies: 3281 3282 3 930
-- Name: ax_boeschungsflaeche; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_boeschungsflaeche (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    istteilvon character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_boeschungsflaeche OWNER TO postgres;

--
-- TOC entry 2711 (class 1259 OID 7505634)
-- Dependencies: 3284 3285 3 930
-- Name: ax_buchungsblatt; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_buchungsblatt (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    anlass integer,
    buchungsblattkennzeichen integer,
    land integer,
    bezirk integer,
    buchungsblattnummermitbuchstabenerweiterung integer,
    blattart integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_buchungsblatt OWNER TO postgres;

--
-- TOC entry 2712 (class 1259 OID 7505642)
-- Dependencies: 3287 3288 3 930
-- Name: ax_buchungsblattbezirk; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_buchungsblattbezirk (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    anlass integer,
    schluesselgesamt integer,
    bezeichnung character(26),
    land integer,
    bezirk integer,
    "gehoertzu|ax_dienststelle_schluessel|land" integer,
    stelle character(4),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_buchungsblattbezirk OWNER TO postgres;

--
-- TOC entry 2713 (class 1259 OID 7505650)
-- Dependencies: 3290 3291 930 3
-- Name: ax_buchungsstelle; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_buchungsstelle (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    anlass integer,
    buchungsart integer,
    laufendenummer integer,
    istbestandteilvon character varying,
    art character(37),
    uri character(28),
    zaehler double precision,
    nenner integer,
    nummerimaufteilungsplan character(14),
    beschreibungdessondereigentums character(203),
    an character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_buchungsstelle OWNER TO postgres;

--
-- TOC entry 2714 (class 1259 OID 7505658)
-- Dependencies: 3293 3294 3 930
-- Name: ax_bundesland; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_bundesland (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    schluesselgesamt integer,
    bezeichnung character(22),
    land integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_bundesland OWNER TO postgres;

--
-- TOC entry 2715 (class 1259 OID 7505666)
-- Dependencies: 3296 3297 930 3
-- Name: ax_dammwalldeich; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_dammwalldeich (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    art integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_dammwalldeich OWNER TO postgres;

--
-- TOC entry 2716 (class 1259 OID 7505674)
-- Dependencies: 3299 3300 3 930
-- Name: ax_dienststelle; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_dienststelle (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    schluesselgesamt character(7),
    bezeichnung character(21),
    land integer,
    stelle character(5),
    stellenart integer,
    hat character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_dienststelle OWNER TO postgres;

--
-- TOC entry 2717 (class 1259 OID 7505682)
-- Dependencies: 3302 3303 930 3
-- Name: ax_felsenfelsblockfelsnadel; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_felsenfelsblockfelsnadel (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_felsenfelsblockfelsnadel OWNER TO postgres;

--
-- TOC entry 2718 (class 1259 OID 7505690)
-- Dependencies: 3305 3306 3 930
-- Name: ax_firstlinie; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_firstlinie (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    art character(37),
    uri character(28),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_firstlinie OWNER TO postgres;

--
-- TOC entry 2719 (class 1259 OID 7505698)
-- Dependencies: 3308 3309 3310 3311 3312 3 930
-- Name: ax_flaechebesondererfunktionalerpraegung; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_flaechebesondererfunktionalerpraegung (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    funktion integer DEFAULT 0,
    name character varying,
    artderbebauung integer DEFAULT 0,
    zustand integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_flaechebesondererfunktionalerpraegung OWNER TO postgres;

--
-- TOC entry 2720 (class 1259 OID 7505706)
-- Dependencies: 3314 3315 3316 3317 3318 3 930
-- Name: ax_flaechegemischternutzung; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_flaechegemischternutzung (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    zustand integer DEFAULT 0,
    funktion integer DEFAULT 0,
    art character(37),
    uri character(28),
    name character varying,
    artderbebauung integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_flaechegemischternutzung OWNER TO postgres;

--
-- TOC entry 2721 (class 1259 OID 7505714)
-- Dependencies: 3320 3321 3322 3323 930 3
-- Name: ax_fliessgewaesser; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_fliessgewaesser (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    funktion integer DEFAULT 0,
    unverschluesselt character(13),
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    lage character(5),
    zustand integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_fliessgewaesser OWNER TO postgres;

--
-- TOC entry 2722 (class 1259 OID 7505722)
-- Dependencies: 3325 3326 3327 3328 3329 3330 3 930
-- Name: ax_flugverkehr; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_flugverkehr (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    funktion integer DEFAULT 0,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    art integer DEFAULT 0,
    unverschluesselt character varying,
    bezeichnung character varying,
    nutzung integer DEFAULT 0,
    zustand integer DEFAULT 0,
    lage character(5),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_flugverkehr OWNER TO postgres;

--
-- TOC entry 2723 (class 1259 OID 7505730)
-- Dependencies: 3332 3333 930 3
-- Name: ax_flugverkehrsanlage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_flugverkehrsanlage (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    art integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_flugverkehrsanlage OWNER TO postgres;

--
-- TOC entry 2724 (class 1259 OID 7505738)
-- Dependencies: 3335 3336 930 3
-- Name: ax_flurstueck; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_flurstueck (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    anlass integer,
    art character varying[],
    name character varying[],
    land integer,
    gemarkungsnummer integer,
    zaehler integer,
    flurstueckskennzeichen character(20),
    amtlicheflaeche integer,
    flurnummer integer,
    abweichenderrechtszustand character(5),
    rechtsbehelfsverfahren character(5),
    zeitpunktderentstehung character(10),
    "gemeindezugehoerigkeit|ax_gemeindekennzeichen|land" integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    "zustaendigestelle|ax_dienststelle_schluessel|land" integer,
    stelle integer,
    istgebucht character varying,
    weistauf character varying,
    zeigtauf character varying,
    kennungschluessel character(31),
    uri character(28),
    flstnrtext character varying,
    alkflstkennz character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_flurstueck OWNER TO postgres;

--
-- TOC entry 2725 (class 1259 OID 7505746)
-- Dependencies: 3338 3339 3340 3341 3 930
-- Name: ax_friedhof; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_friedhof (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    funktion integer DEFAULT 0,
    name character varying,
    zustand integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_friedhof OWNER TO postgres;

--
-- TOC entry 2726 (class 1259 OID 7505754)
-- Dependencies: 3343 3344 3 930
-- Name: ax_gebaeude; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_gebaeude (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    gebaeudefunktion integer,
    description integer,
    hat character varying,
    zeigtauf character varying,
    art character varying,
    uri character varying,
    name character varying[],
    bauweise integer,
    "qualitaetsangaben|ax_dqmitdatenerhebung|herkunft|li_lineage|pro" character(8),
    individualname character varying,
    role character(16),
    anzahlderoberirdischengeschosse integer,
    zustand integer,
    lagezurerdoberflaeche integer,
    qualitaetsangaben integer,
    dachform integer,
    grundflaeche integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_gebaeude OWNER TO postgres;

--
-- TOC entry 2727 (class 1259 OID 7505762)
-- Dependencies: 3346 3347 3348 3349 930 3
-- Name: ax_gehoelz; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_gehoelz (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(5),
    anlass integer,
    vegetationsmerkmal integer DEFAULT 0,
    name character varying,
    funktion integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_gehoelz OWNER TO postgres;

--
-- TOC entry 2728 (class 1259 OID 7505770)
-- Dependencies: 3351 3352 930 3
-- Name: ax_gemarkung; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_gemarkung (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    schluesselgesamt integer,
    bezeichnung character(23),
    land integer,
    gemarkungsnummer integer,
    "istamtsbezirkvon|ax_dienststelle_schluessel|land" integer,
    stelle integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_gemarkung OWNER TO postgres;

--
-- TOC entry 2729 (class 1259 OID 7505778)
-- Dependencies: 3354 3355 930 3
-- Name: ax_gemarkungsteilflur; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_gemarkungsteilflur (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    schluesselgesamt integer,
    bezeichnung integer,
    land integer,
    gemarkung integer,
    gemarkungsteilflur integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_gemarkungsteilflur OWNER TO postgres;

--
-- TOC entry 2730 (class 1259 OID 7505786)
-- Dependencies: 3357 3358 930 3
-- Name: ax_gemeinde; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_gemeinde (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    schluesselgesamt integer,
    bezeichnung character(25),
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_gemeinde OWNER TO postgres;

--
-- TOC entry 2731 (class 1259 OID 7505794)
-- Dependencies: 3360 3361 3 930
-- Name: ax_georeferenziertegebaeudeadresse; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_georeferenziertegebaeudeadresse (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    anlass integer,
    qualitaetsangaben integer,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    ortsteil integer,
    strassenschluessel integer,
    hausnummer character(4),
    postleitzahl integer,
    ortsnamepost character(7),
    strassenname character(22),
    hatauch character varying,
    adressierungszusatz character(1),
    art character(37),
    uri character(28),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_georeferenziertegebaeudeadresse OWNER TO postgres;

--
-- TOC entry 2732 (class 1259 OID 7505802)
-- Dependencies: 3363 3364 3 930
-- Name: ax_gewaessermerkmal; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_gewaessermerkmal (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    art integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_gewaessermerkmal OWNER TO postgres;

--
-- TOC entry 2733 (class 1259 OID 7505810)
-- Dependencies: 3366 3367 3 930
-- Name: ax_gleis; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_gleis (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    bahnkategorie integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_gleis OWNER TO postgres;

--
-- TOC entry 2734 (class 1259 OID 7505818)
-- Dependencies: 3369 3370 930 3
-- Name: ax_grenzpunkt; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_grenzpunkt (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(5),
    anlass integer,
    punktkennung integer,
    land integer,
    stelle integer,
    abmarkung_marke integer,
    sonstigeeigenschaft character varying[],
    art character(37),
    uri character(28),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_grenzpunkt OWNER TO postgres;

--
-- TOC entry 2915 (class 1259 OID 15183969)
-- Dependencies: 3552 3553 3554 3555 3 930
-- Name: ax_hafenbecken; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_hafenbecken (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    funktion integer DEFAULT 0,
    unverschluesselt character(13),
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    lage character(5),
    nutzung integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_hafenbecken OWNER TO postgres;

--
-- TOC entry 2735 (class 1259 OID 7505826)
-- Dependencies: 3372 3373 3374 3375 3 930
-- Name: ax_halde; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_halde (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    lagergut integer DEFAULT 0,
    name character varying,
    zustand integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_halde OWNER TO postgres;

--
-- TOC entry 2736 (class 1259 OID 7505834)
-- Dependencies: 3377 3378 3 930
-- Name: ax_heide; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_heide (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(5),
    anlass integer,
    name character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_heide OWNER TO postgres;

--
-- TOC entry 2737 (class 1259 OID 7505842)
-- Dependencies: 3380 3381 930 3
-- Name: ax_historischesbauwerkoderhistorischeeinrichtung; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_historischesbauwerkoderhistorischeeinrichtung (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    archaeologischertyp integer,
    name character(15),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_historischesbauwerkoderhistorischeeinrichtung OWNER TO postgres;

--
-- TOC entry 2738 (class 1259 OID 7505850)
-- Dependencies: 3383 3384 3385 3386 3387 3388 3389 3 930
-- Name: ax_industrieundgewerbeflaeche; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_industrieundgewerbeflaeche (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    funktion integer DEFAULT 0,
    art character(37),
    uri character(28),
    zustand integer DEFAULT 0,
    name character varying,
    foerdergut integer DEFAULT 0,
    lagergut integer DEFAULT 0,
    primaerenergie integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_industrieundgewerbeflaeche OWNER TO postgres;

--
-- TOC entry 2739 (class 1259 OID 7505858)
-- Dependencies: 3391 3392 3 930
-- Name: ax_klassifizierungnachwasserrecht; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_klassifizierungnachwasserrecht (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    anlass integer,
    artderfestlegung integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_klassifizierungnachwasserrecht OWNER TO postgres;

--
-- TOC entry 2740 (class 1259 OID 7505866)
-- Dependencies: 3394 3395 3 930
-- Name: ax_kleinraeumigerlandschaftsteil; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_kleinraeumigerlandschaftsteil (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    landschaftstyp integer,
    name character(11),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_kleinraeumigerlandschaftsteil OWNER TO postgres;

--
-- TOC entry 2741 (class 1259 OID 7505874)
-- Dependencies: 3397 3398 930 3
-- Name: ax_kommunalesgebiet; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_kommunalesgebiet (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    anlass integer,
    schluesselgesamt integer,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_kommunalesgebiet OWNER TO postgres;

--
-- TOC entry 2742 (class 1259 OID 7505882)
-- Dependencies: 3400 3401 930 3
-- Name: ax_kreisregion; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_kreisregion (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    schluesselgesamt integer,
    bezeichnung character(10),
    land integer,
    regierungsbezirk integer,
    kreis integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_kreisregion OWNER TO postgres;

--
-- TOC entry 2743 (class 1259 OID 7505890)
-- Dependencies: 3403 3404 930 3
-- Name: ax_lagebezeichnungkatalogeintrag; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_lagebezeichnungkatalogeintrag (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    schluesselgesamt character(13),
    bezeichnung character varying,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    lage character(5),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_lagebezeichnungkatalogeintrag OWNER TO postgres;

--
-- TOC entry 2744 (class 1259 OID 7505898)
-- Dependencies: 3406 3407 930 3
-- Name: ax_lagebezeichnungmithausnummer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_lagebezeichnungmithausnummer (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(5),
    anlass integer,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    lage integer,
    hausnummer character varying,
    art character(37),
    uri character(28),
    gehoertzu character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_lagebezeichnungmithausnummer OWNER TO postgres;

--
-- TOC entry 2745 (class 1259 OID 7505906)
-- Dependencies: 3409 3410 930 3
-- Name: ax_lagebezeichnungmitpseudonummer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_lagebezeichnungmitpseudonummer (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    lage integer,
    pseudonummer character varying,
    laufendenummer character(2),
    art character(37),
    uri character(28),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_lagebezeichnungmitpseudonummer OWNER TO postgres;

--
-- TOC entry 2746 (class 1259 OID 7505914)
-- Dependencies: 3412 3413 3 930
-- Name: ax_lagebezeichnungohnehausnummer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_lagebezeichnungohnehausnummer (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(5),
    anlass integer,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    lage integer,
    unverschluesselt character(45),
    gehoertzu character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_lagebezeichnungohnehausnummer OWNER TO postgres;

--
-- TOC entry 2747 (class 1259 OID 7505922)
-- Dependencies: 3415 3416 3417 930 3
-- Name: ax_landwirtschaft; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_landwirtschaft (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(5),
    anlass integer,
    vegetationsmerkmal integer DEFAULT 0,
    name integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_landwirtschaft OWNER TO postgres;

--
-- TOC entry 2748 (class 1259 OID 7505930)
-- Dependencies: 3419 3420 3 930
-- Name: ax_leitung; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_leitung (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    bauwerksfunktion integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_leitung OWNER TO postgres;

--
-- TOC entry 2919 (class 1259 OID 15184169)
-- Dependencies: 3557 3558 3559 3560 930 3
-- Name: ax_meer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_meer (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    funktion integer DEFAULT 0,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    lage integer,
    name character varying,
    bezeichnung character varying,
    tidemerkmal integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_meer OWNER TO postgres;

--
-- TOC entry 2912 (class 1259 OID 15183623)
-- Dependencies: 3549 3550 3 930
-- Name: ax_moor; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_moor (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(5),
    anlass integer,
    name character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_moor OWNER TO postgres;

--
-- TOC entry 2749 (class 1259 OID 7505938)
-- Dependencies: 3422 3423 930 3
-- Name: ax_musterlandesmusterundvergleichsstueck; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_musterlandesmusterundvergleichsstueck (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    anlass integer,
    merkmal integer,
    kulturart integer,
    bodenart integer,
    zustandsstufeoderbodenstufe integer,
    entstehungsartoderklimastufewasserverhaeltnisse integer,
    bodenzahlodergruenlandgrundzahl integer,
    ackerzahlodergruenlandzahl integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_musterlandesmusterundvergleichsstueck OWNER TO postgres;

--
-- TOC entry 2750 (class 1259 OID 7505946)
-- Dependencies: 3425 3426 930 3
-- Name: ax_namensnummer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_namensnummer (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    anlass integer,
    laufendenummernachdin1421 character(16),
    zaehler integer,
    nenner integer,
    eigentuemerart integer,
    istbestandteilvon character varying,
    benennt character varying,
    artderrechtsgemeinschaft integer,
    beschriebderrechtsgemeinschaft character(113),
    art character(37),
    uri character(28),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_namensnummer OWNER TO postgres;

--
-- TOC entry 2751 (class 1259 OID 7505954)
-- Dependencies: 3428 3429 930 3
-- Name: ax_naturumweltoderbodenschutzrecht; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_naturumweltoderbodenschutzrecht (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    artderfestlegung integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_naturumweltoderbodenschutzrecht OWNER TO postgres;

--
-- TOC entry 2752 (class 1259 OID 7505962)
-- Dependencies: 3431 3432 3 930
-- Name: ax_person; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_person (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    nachnameoderfirma character(91),
    anrede integer,
    vorname character(29),
    geburtsname character(16),
    geburtsdatum character(10),
    hat character varying,
    art character(37),
    uri character(28),
    akademischergrad character(13),
    namensbestandteil character(7),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_person OWNER TO postgres;

--
-- TOC entry 2753 (class 1259 OID 7505970)
-- Dependencies: 3434 3435 3436 930 3
-- Name: ax_platz; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_platz (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    funktion integer DEFAULT 0,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    unverschluesselt character(13),
    zweitname character varying,
    lage character(5),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_platz OWNER TO postgres;

--
-- TOC entry 2754 (class 1259 OID 7505978)
-- Dependencies: 3438 3439 930 3
-- Name: ax_punktortag; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_punktortag (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    art character varying[],
    name character(9),
    uri character(28),
    istteilvon character varying,
    kartendarstellung character(4),
    koordinatenstatus integer,
    hinweise character(11),
    description integer,
    "qualitaetsangaben|ax_dqpunktort|herkunft|li_lineage|processstep" character varying[],
    datetime character varying[],
    individualname character(7),
    role character(16),
    genauigkeitsstufe integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_punktortag OWNER TO postgres;

--
-- TOC entry 2755 (class 1259 OID 7505986)
-- Dependencies: 3441 3442 3 930
-- Name: ax_punktortau; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_punktortau (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    istteilvon character varying,
    kartendarstellung character(5),
    koordinatenstatus integer,
    hinweise character(11),
    description integer,
    "qualitaetsangaben|ax_dqpunktort|herkunft|li_lineage|processstep" character varying[],
    datetime character varying[],
    individualname character(7),
    role character(16),
    art character varying[],
    name character(9),
    genauigkeitsstufe integer,
    uri character(28),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_punktortau OWNER TO postgres;

--
-- TOC entry 2756 (class 1259 OID 7505994)
-- Dependencies: 3444 3445 3 930
-- Name: ax_punktortta; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_punktortta (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(5),
    anlass integer,
    art character varying[],
    name character(9),
    istteilvon character varying,
    kartendarstellung character(4),
    koordinatenstatus integer,
    hinweise character(11),
    description integer,
    "qualitaetsangaben|ax_dqpunktort|herkunft|li_lineage|processstep" character varying[],
    datetime character varying[],
    individualname character(7),
    role character(16),
    genauigkeitsstufe integer,
    uri character(28),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_punktortta OWNER TO postgres;

--
-- TOC entry 2757 (class 1259 OID 7506002)
-- Dependencies: 3447 3448 3 930
-- Name: ax_regierungsbezirk; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_regierungsbezirk (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    schluesselgesamt integer,
    bezeichnung character(11),
    land integer,
    regierungsbezirk integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_regierungsbezirk OWNER TO postgres;

--
-- TOC entry 2909 (class 1259 OID 15182519)
-- Dependencies: 3544 3545 3546 3547 3 930
-- Name: ax_schiffsverkehr; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_schiffsverkehr (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    funktion integer DEFAULT 0,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    unverschluesselt character varying,
    zustand integer DEFAULT 0,
    lage character(5),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_schiffsverkehr OWNER TO postgres;

--
-- TOC entry 2758 (class 1259 OID 7506010)
-- Dependencies: 3450 3451 3 930
-- Name: ax_schutzgebietnachwasserrecht; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_schutzgebietnachwasserrecht (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    artderfestlegung integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_schutzgebietnachwasserrecht OWNER TO postgres;

--
-- TOC entry 2759 (class 1259 OID 7506018)
-- Dependencies: 3453 3454 3 930
-- Name: ax_schutzzone; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_schutzzone (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    istteilvon character varying,
    zone integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_schutzzone OWNER TO postgres;

--
-- TOC entry 2760 (class 1259 OID 7506026)
-- Dependencies: 3456 3457 930 3
-- Name: ax_sonstigervermessungspunkt; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_sonstigervermessungspunkt (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(6),
    anlass integer,
    punktkennung integer,
    land integer,
    stelle integer,
    sonstigeeigenschaft character varying[],
    vermarkung_marke integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_sonstigervermessungspunkt OWNER TO postgres;

--
-- TOC entry 2761 (class 1259 OID 7506034)
-- Dependencies: 3459 3460 3 930
-- Name: ax_sonstigesbauwerkodersonstigeeinrichtung; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_sonstigesbauwerkodersonstigeeinrichtung (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    bauwerksfunktion integer,
    gehoertzu character varying,
    description integer,
    art character(37),
    uri character(28),
    gehoertzubauwerk character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_sonstigesbauwerkodersonstigeeinrichtung OWNER TO postgres;

--
-- TOC entry 2762 (class 1259 OID 7506042)
-- Dependencies: 3462 3463 3464 3465 930 3
-- Name: ax_sportfreizeitunderholungsflaeche; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_sportfreizeitunderholungsflaeche (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    funktion integer DEFAULT 0,
    name character varying,
    zustand integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_sportfreizeitunderholungsflaeche OWNER TO postgres;

--
-- TOC entry 2763 (class 1259 OID 7506050)
-- Dependencies: 3467 3468 3469 3470 930 3
-- Name: ax_stehendesgewaesser; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_stehendesgewaesser (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    funktion integer DEFAULT 0,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    unverschluesselt character varying,
    gewaesserkennziffer character varying,
    hydrologischesmerkmal integer DEFAULT 0,
    lage character(5),
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_stehendesgewaesser OWNER TO postgres;

--
-- TOC entry 2764 (class 1259 OID 7506058)
-- Dependencies: 3472 3473 3474 3475 930 3
-- Name: ax_strassenverkehr; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_strassenverkehr (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    lage character(5),
    funktion integer DEFAULT 0,
    unverschluesselt character(16),
    art character(37),
    uri character(57),
    zweitname character varying,
    zustand integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_strassenverkehr OWNER TO postgres;

--
-- TOC entry 2765 (class 1259 OID 7506066)
-- Dependencies: 3477 3478 3 930
-- Name: ax_strassenverkehrsanlage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_strassenverkehrsanlage (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    art integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_strassenverkehrsanlage OWNER TO postgres;

--
-- TOC entry 2766 (class 1259 OID 7506074)
-- Dependencies: 3480 3481 3 930
-- Name: ax_sumpf; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_sumpf (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(5),
    anlass integer,
    name character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_sumpf OWNER TO postgres;

--
-- TOC entry 2767 (class 1259 OID 7506082)
-- Dependencies: 3483 3484 3485 3486 930 3
-- Name: ax_tagebaugrubesteinbruch; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_tagebaugrubesteinbruch (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    abbaugut integer DEFAULT 0,
    name character varying,
    zustand integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_tagebaugrubesteinbruch OWNER TO postgres;

--
-- TOC entry 2901 (class 1259 OID 15115588)
-- Dependencies: 3525 3526 3527 3528 3529 3530 3531 3532 3533 3534 3535 3536 3537 3538 930 3
-- Name: ax_tatsaechlichenutzung; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_tatsaechlichenutzung (
    id integer NOT NULL,
    gml_id character varying,
    wkb_geometry geometry,
    objektartengruppe integer,
    bezobjektartengruppe character varying,
    name character varying,
    artderbebauung integer DEFAULT 0,
    bezartderbebauung character varying,
    zustand integer DEFAULT 0,
    bezzustand character varying,
    funktion integer DEFAULT 0,
    bezfunktion character varying,
    foerdergut integer DEFAULT 0,
    bezfoerdergut character varying,
    lagergut integer DEFAULT 0,
    bezlagergut character varying,
    primaerenergie integer DEFAULT 0,
    bezprimaerenergie character varying,
    bezeichnung character varying,
    abbaugut integer DEFAULT 0,
    bezabbaugut character varying,
    zweitname character varying,
    bahnkategorie integer DEFAULT 0,
    bezbahnkategorie character varying,
    nummerderbahnstrecke character varying,
    art integer DEFAULT 0,
    bezart character varying,
    nutzung integer DEFAULT 0,
    beznutzung character varying,
    vegetationsmerkmal integer DEFAULT 0,
    bezvegetationsmerkmal character varying,
    oberflaechenmaterial integer DEFAULT 0,
    bezoberflaechenmaterial character varying,
    gewaesserkennziffer character varying,
    hydrologischesmerkmal integer DEFAULT 0,
    bezhydrologischesmerkmal character varying,
    tidemerkmal integer DEFAULT 0,
    beztidemerkmal character varying,
    bezlage character varying,
    lage character(5)
);


ALTER TABLE public.ax_tatsaechlichenutzung OWNER TO postgres;

--
-- TOC entry 2768 (class 1259 OID 7506090)
-- Dependencies: 3488 3489 3 930
-- Name: ax_transportanlage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_transportanlage (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    bauwerksfunktion integer,
    produkt integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_transportanlage OWNER TO postgres;

--
-- TOC entry 2769 (class 1259 OID 7506098)
-- Dependencies: 3491 3492 3 930
-- Name: ax_turm; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_turm (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    description integer,
    bauwerksfunktion integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_turm OWNER TO postgres;

--
-- TOC entry 2770 (class 1259 OID 7506106)
-- Dependencies: 3494 3495 3496 3497 3 930
-- Name: ax_unlandvegetationsloseflaeche; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_unlandvegetationsloseflaeche (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(5),
    anlass integer,
    funktion integer DEFAULT 0,
    name character varying,
    oberflaechenmaterial integer DEFAULT 0,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_unlandvegetationsloseflaeche OWNER TO postgres;

--
-- TOC entry 2771 (class 1259 OID 7506114)
-- Dependencies: 3499 3500 930 3
-- Name: ax_untergeordnetesgewaesser; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_untergeordnetesgewaesser (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    funktion integer,
    hydrologischesmerkmal integer,
    lagezurerdoberflaeche integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_untergeordnetesgewaesser OWNER TO postgres;

--
-- TOC entry 2772 (class 1259 OID 7506122)
-- Dependencies: 3502 3503 930 3
-- Name: ax_vegetationsmerkmal; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_vegetationsmerkmal (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(5),
    anlass integer,
    bewuchs integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_vegetationsmerkmal OWNER TO postgres;

--
-- TOC entry 2773 (class 1259 OID 7506130)
-- Dependencies: 3505 3506 3 930
-- Name: ax_vorratsbehaelterspeicherbauwerk; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_vorratsbehaelterspeicherbauwerk (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    speicherinhalt integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_vorratsbehaelterspeicherbauwerk OWNER TO postgres;

--
-- TOC entry 2774 (class 1259 OID 7506138)
-- Dependencies: 3508 3509 3510 930 3
-- Name: ax_wald; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_wald (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character(5),
    anlass integer,
    vegetationsmerkmal integer DEFAULT 0,
    name character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_wald OWNER TO postgres;

--
-- TOC entry 2775 (class 1259 OID 7506146)
-- Dependencies: 3512 3513 3514 3 930
-- Name: ax_weg; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_weg (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    funktion integer DEFAULT 0,
    land integer,
    regierungsbezirk integer,
    kreis integer,
    gemeinde integer,
    lage character(5),
    art character(37),
    uri character(28),
    unverschluesselt character(45),
    bezeichnung character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_weg OWNER TO postgres;

--
-- TOC entry 2776 (class 1259 OID 7506154)
-- Dependencies: 3516 3517 3 930
-- Name: ax_wegpfadsteig; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_wegpfadsteig (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    art integer,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_wegpfadsteig OWNER TO postgres;

--
-- TOC entry 2777 (class 1259 OID 7506162)
-- Dependencies: 3519 3520 3521 3522 3 930
-- Name: ax_wohnbauflaeche; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ax_wohnbauflaeche (
    ogc_fid integer NOT NULL,
    wkb_geometry geometry,
    gml_id character(16),
    beginnt character(20),
    advstandardmodell character(4),
    sonstigesmodell character varying[],
    anlass integer,
    art character(37),
    uri character(57),
    artderbebauung integer DEFAULT 0,
    zustand integer DEFAULT 0,
    name character varying,
    CONSTRAINT enforce_dims_wkb_geometry CHECK ((ndims(wkb_geometry) = 2)),
    CONSTRAINT enforce_srid_wkb_geometry CHECK ((srid(wkb_geometry) = 25832))
);


ALTER TABLE public.ax_wohnbauflaeche OWNER TO postgres;

--
-- TOC entry 1222 (class 0 OID 0)
-- Name: box2d; Type: SHELL TYPE; Schema: public; Owner: postgres
--

CREATE TYPE box2d;


--
-- TOC entry 30 (class 1255 OID 7506171)
-- Dependencies: 3 1222
-- Name: st_box2d_in(cstring); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box2d_in(cstring) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_in(cstring) OWNER TO postgres;

--
-- TOC entry 31 (class 1255 OID 7506172)
-- Dependencies: 3 1222
-- Name: st_box2d_out(box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box2d_out(box2d) RETURNS cstring
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_out(box2d) OWNER TO postgres;

--
-- TOC entry 1221 (class 1247 OID 7506170)
-- Dependencies: 31 30 3
-- Name: box2d; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE box2d (
    INTERNALLENGTH = 16,
    INPUT = st_box2d_in,
    OUTPUT = st_box2d_out,
    ALIGNMENT = int4,
    STORAGE = plain
);


ALTER TYPE public.box2d OWNER TO postgres;

--
-- TOC entry 1226 (class 0 OID 0)
-- Name: box3d; Type: SHELL TYPE; Schema: public; Owner: postgres
--

CREATE TYPE box3d;


--
-- TOC entry 32 (class 1255 OID 7506175)
-- Dependencies: 3 1226
-- Name: st_box3d_in(cstring); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box3d_in(cstring) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box3d_in(cstring) OWNER TO postgres;

--
-- TOC entry 33 (class 1255 OID 7506176)
-- Dependencies: 3 1226
-- Name: st_box3d_out(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box3d_out(box3d) RETURNS cstring
    AS '$libdir/liblwgeom', 'BOX3D_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box3d_out(box3d) OWNER TO postgres;

--
-- TOC entry 1225 (class 1247 OID 7506174)
-- Dependencies: 3 33 32
-- Name: box3d; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE box3d (
    INTERNALLENGTH = 48,
    INPUT = st_box3d_in,
    OUTPUT = st_box3d_out,
    ALIGNMENT = double,
    STORAGE = plain
);


ALTER TYPE public.box3d OWNER TO postgres;

--
-- TOC entry 1230 (class 0 OID 0)
-- Name: chip; Type: SHELL TYPE; Schema: public; Owner: postgres
--

CREATE TYPE chip;


--
-- TOC entry 34 (class 1255 OID 7506179)
-- Dependencies: 3 1230
-- Name: st_chip_in(cstring); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_chip_in(cstring) RETURNS chip
    AS '$libdir/liblwgeom', 'CHIP_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_chip_in(cstring) OWNER TO postgres;

--
-- TOC entry 35 (class 1255 OID 7506180)
-- Dependencies: 3 1230
-- Name: st_chip_out(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_chip_out(chip) RETURNS cstring
    AS '$libdir/liblwgeom', 'CHIP_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_chip_out(chip) OWNER TO postgres;

--
-- TOC entry 1229 (class 1247 OID 7506178)
-- Dependencies: 34 35 3
-- Name: chip; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE chip (
    INTERNALLENGTH = variable,
    INPUT = st_chip_in,
    OUTPUT = st_chip_out,
    ALIGNMENT = double,
    STORAGE = extended
);


ALTER TYPE public.chip OWNER TO postgres;

SET default_with_oids = true;

--
-- TOC entry 2778 (class 1259 OID 7506182)
-- Dependencies: 3
-- Name: geometry_columns; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE geometry_columns (
    f_table_catalog character varying(256) NOT NULL,
    f_table_schema character varying(256) NOT NULL,
    f_table_name character varying(256) NOT NULL,
    f_geometry_column character varying(256) NOT NULL,
    coord_dimension integer NOT NULL,
    srid integer NOT NULL,
    type character varying(30) NOT NULL
);


ALTER TABLE public.geometry_columns OWNER TO postgres;

--
-- TOC entry 1235 (class 1247 OID 7506187)
-- Dependencies: 3 2779
-- Name: geometry_dump; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE geometry_dump AS (
	path integer[],
	geom geometry
);


ALTER TYPE public.geometry_dump OWNER TO postgres;

--
-- TOC entry 1238 (class 0 OID 0)
-- Name: histogram2d; Type: SHELL TYPE; Schema: public; Owner: postgres
--

CREATE TYPE histogram2d;


--
-- TOC entry 36 (class 1255 OID 7506189)
-- Dependencies: 3 1238
-- Name: st_histogram2d_in(cstring); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_histogram2d_in(cstring) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'lwhistogram2d_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_histogram2d_in(cstring) OWNER TO postgres;

--
-- TOC entry 37 (class 1255 OID 7506190)
-- Dependencies: 3 1238
-- Name: st_histogram2d_out(histogram2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_histogram2d_out(histogram2d) RETURNS cstring
    AS '$libdir/liblwgeom', 'lwhistogram2d_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_histogram2d_out(histogram2d) OWNER TO postgres;

--
-- TOC entry 1237 (class 1247 OID 7506188)
-- Dependencies: 3 37 36
-- Name: histogram2d; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE histogram2d (
    INTERNALLENGTH = variable,
    INPUT = st_histogram2d_in,
    OUTPUT = st_histogram2d_out,
    ALIGNMENT = double,
    STORAGE = main
);


ALTER TYPE public.histogram2d OWNER TO postgres;

SET default_with_oids = false;

--
-- TOC entry 2892 (class 1259 OID 14984758)
-- Dependencies: 3
-- Name: ref_beziehungen; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ref_beziehungen (
    id integer NOT NULL,
    tabelle character varying,
    referenz character varying,
    tab_gml_id character varying,
    ref_gml_id character varying
);


ALTER TABLE public.ref_beziehungen OWNER TO postgres;

--
-- TOC entry 2878 (class 1259 OID 8598942)
-- Dependencies: 3006 3 930
-- Name: s_allgemeine_texte; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW s_allgemeine_texte AS
    SELECT ap_pto.ogc_fid, ap_pto.wkb_geometry, ap_pto.gml_id, ap_pto.art, ((ap_pto.drehwinkel * (180)::double precision) / (3.14)::double precision) AS drehwinkel, ap_pto.schriftinhalt, ap_pto.horizontaleausrichtung, ap_pto.vertikaleausrichtung FROM ap_pto WHERE (((((NOT (ap_pto.art = 'ZAE_NEN'::bpchar)) AND (NOT (ap_pto.art = 'HNR'::bpchar))) AND (NOT (ap_pto.art = 'BWF'::bpchar))) AND (NOT (ap_pto.art = 'Friedhof'::bpchar))) AND (ap_pto.schriftinhalt IS NOT NULL));


ALTER TABLE public.s_allgemeine_texte OWNER TO postgres;

--
-- TOC entry 2875 (class 1259 OID 7768333)
-- Dependencies: 3004 930 3
-- Name: s_aufnahmepunkte; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW s_aufnahmepunkte AS
    SELECT ax_punktortau.ogc_fid, ax_punktortau.wkb_geometry, ax_aufnahmepunkt.vermarkung_marke FROM (ax_punktortau JOIN ax_aufnahmepunkt ON (((ax_punktortau.istteilvon)::bpchar = ax_aufnahmepunkt.gml_id)));


ALTER TABLE public.s_aufnahmepunkte OWNER TO postgres;

--
-- TOC entry 29 (class 1255 OID 7505465)
-- Dependencies: 3 930
-- Name: geometrytype(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometrytype(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_getTYPE'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometrytype(geometry) OWNER TO postgres;

--
-- TOC entry 2780 (class 1259 OID 7506196)
-- Dependencies: 2998 930 3
-- Name: s_ausgestaltung_f_gebaeude; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW s_ausgestaltung_f_gebaeude AS
    SELECT ax_sonstigesbauwerkodersonstigeeinrichtung.ogc_fid, ax_sonstigesbauwerkodersonstigeeinrichtung.wkb_geometry, ax_sonstigesbauwerkodersonstigeeinrichtung.gml_id, ax_sonstigesbauwerkodersonstigeeinrichtung.bauwerksfunktion, ax_sonstigesbauwerkodersonstigeeinrichtung.gehoertzu FROM (ax_sonstigesbauwerkodersonstigeeinrichtung JOIN ax_gebaeude ON (((ax_sonstigesbauwerkodersonstigeeinrichtung.gehoertzu)::bpchar = ax_gebaeude.gml_id))) WHERE (geometrytype(ax_sonstigesbauwerkodersonstigeeinrichtung.wkb_geometry) = 'POLYGON'::text);


ALTER TABLE public.s_ausgestaltung_f_gebaeude OWNER TO postgres;

--
-- TOC entry 2781 (class 1259 OID 7506201)
-- Dependencies: 2999 3 930
-- Name: s_ausgestaltung_l_gebaeude; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW s_ausgestaltung_l_gebaeude AS
    SELECT ax_sonstigesbauwerkodersonstigeeinrichtung.ogc_fid, ax_sonstigesbauwerkodersonstigeeinrichtung.wkb_geometry, ax_sonstigesbauwerkodersonstigeeinrichtung.gml_id, ax_sonstigesbauwerkodersonstigeeinrichtung.bauwerksfunktion, ax_sonstigesbauwerkodersonstigeeinrichtung.gehoertzu FROM (ax_sonstigesbauwerkodersonstigeeinrichtung JOIN ax_gebaeude ON (((ax_sonstigesbauwerkodersonstigeeinrichtung.gehoertzu)::bpchar = ax_gebaeude.gml_id))) WHERE (geometrytype(ax_sonstigesbauwerkodersonstigeeinrichtung.wkb_geometry) = 'LINESTRING'::text);


ALTER TABLE public.s_ausgestaltung_l_gebaeude OWNER TO postgres;

--
-- TOC entry 2782 (class 1259 OID 7506206)
-- Dependencies: 3000 3 930
-- Name: s_besondereflurstuecksgrenze; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW s_besondereflurstuecksgrenze AS
    (((SELECT ax_besondereflurstuecksgrenze.ogc_fid, ax_besondereflurstuecksgrenze.wkb_geometry, ax_besondereflurstuecksgrenze.gml_id, ax_besondereflurstuecksgrenze.artderflurstuecksgrenze[1] AS artderflurstuecksgrenze FROM ax_besondereflurstuecksgrenze WHERE (NOT (ax_besondereflurstuecksgrenze.artderflurstuecksgrenze[1] IS NULL)) UNION SELECT ax_besondereflurstuecksgrenze.ogc_fid, ax_besondereflurstuecksgrenze.wkb_geometry, ax_besondereflurstuecksgrenze.gml_id, ax_besondereflurstuecksgrenze.artderflurstuecksgrenze[2] AS artderflurstuecksgrenze FROM ax_besondereflurstuecksgrenze WHERE (NOT (ax_besondereflurstuecksgrenze.artderflurstuecksgrenze[2] IS NULL))) UNION SELECT ax_besondereflurstuecksgrenze.ogc_fid, ax_besondereflurstuecksgrenze.wkb_geometry, ax_besondereflurstuecksgrenze.gml_id, ax_besondereflurstuecksgrenze.artderflurstuecksgrenze[3] AS artderflurstuecksgrenze FROM ax_besondereflurstuecksgrenze WHERE (NOT (ax_besondereflurstuecksgrenze.artderflurstuecksgrenze[3] IS NULL))) UNION SELECT ax_besondereflurstuecksgrenze.ogc_fid, ax_besondereflurstuecksgrenze.wkb_geometry, ax_besondereflurstuecksgrenze.gml_id, ax_besondereflurstuecksgrenze.artderflurstuecksgrenze[4] AS artderflurstuecksgrenze FROM ax_besondereflurstuecksgrenze WHERE (NOT (ax_besondereflurstuecksgrenze.artderflurstuecksgrenze[4] IS NULL))) UNION SELECT ax_besondereflurstuecksgrenze.ogc_fid, ax_besondereflurstuecksgrenze.wkb_geometry, ax_besondereflurstuecksgrenze.gml_id, ax_besondereflurstuecksgrenze.artderflurstuecksgrenze[5] AS artderflurstuecksgrenze FROM ax_besondereflurstuecksgrenze WHERE (NOT (ax_besondereflurstuecksgrenze.artderflurstuecksgrenze[5] IS NULL)) ORDER BY 4;


ALTER TABLE public.s_besondereflurstuecksgrenze OWNER TO postgres;

--
-- TOC entry 2881 (class 1259 OID 12616546)
-- Dependencies: 3009 930 3
-- Name: s_flurstuecksnummer_flurstueck; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW s_flurstuecksnummer_flurstueck AS
    SELECT ap_pto.ogc_fid, ap_pto.wkb_geometry, ap_pto.gml_id, ap_pto.art, ap_pto.dientzurdarstellungvon, ax_flurstueck.flurstueckskennzeichen, ax_flurstueck.flstnrtext AS zaehler, ((7)::double precision * ap_pto.skalierung) AS skalierung FROM (ap_pto JOIN ax_flurstueck ON (((ap_pto.dientzurdarstellungvon)::bpchar = ax_flurstueck.gml_id))) WHERE (ap_pto.art = 'ZAE_NEN'::bpchar);


ALTER TABLE public.s_flurstuecksnummer_flurstueck OWNER TO postgres;

--
-- TOC entry 2874 (class 1259 OID 7768319)
-- Dependencies: 3003 930 3
-- Name: s_grenzpunkte; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW s_grenzpunkte AS
    SELECT ax_punktortta.ogc_fid, ax_punktortta.wkb_geometry, ax_grenzpunkt.abmarkung_marke FROM (ax_punktortta JOIN ax_grenzpunkt ON (((ax_punktortta.istteilvon)::bpchar = ax_grenzpunkt.gml_id)));


ALTER TABLE public.s_grenzpunkte OWNER TO postgres;

--
-- TOC entry 2880 (class 1259 OID 8914259)
-- Dependencies: 3008 3 930
-- Name: s_hausnummer_gebaeude; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW s_hausnummer_gebaeude AS
    SELECT ap_pto.ogc_fid, ap_pto.wkb_geometry, ap_pto.gml_id, ((ap_pto.drehwinkel * (180)::double precision) / (3.14)::double precision) AS drehwinkel, ap_pto.dientzurdarstellungvon, ax_lagebezeichnungmithausnummer.hausnummer FROM (ap_pto JOIN ax_lagebezeichnungmithausnummer ON (((ap_pto.dientzurdarstellungvon)::bpchar = ax_lagebezeichnungmithausnummer.gml_id))) WHERE (ap_pto.art = 'HNR'::bpchar);


ALTER TABLE public.s_hausnummer_gebaeude OWNER TO postgres;

--
-- TOC entry 2879 (class 1259 OID 8662147)
-- Dependencies: 3007 930 3
-- Name: s_nutzungen; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW s_nutzungen AS
    (((((((((((((((((((SELECT ax_wohnbauflaeche.gml_id, ax_wohnbauflaeche.wkb_geometry, (100000 + ax_wohnbauflaeche.artderbebauung) AS funktion FROM ax_wohnbauflaeche UNION SELECT ax_flaechegemischternutzung.gml_id, ax_flaechegemischternutzung.wkb_geometry, (110000 + ax_flaechegemischternutzung.funktion) AS funktion FROM ax_flaechegemischternutzung) UNION SELECT ax_flaechebesondererfunktionalerpraegung.gml_id, ax_flaechebesondererfunktionalerpraegung.wkb_geometry, (120000 + ax_flaechebesondererfunktionalerpraegung.funktion) AS funktion FROM ax_flaechebesondererfunktionalerpraegung) UNION SELECT ax_industrieundgewerbeflaeche.gml_id, ax_industrieundgewerbeflaeche.wkb_geometry, (130000 + ax_industrieundgewerbeflaeche.funktion) AS funktion FROM ax_industrieundgewerbeflaeche) UNION SELECT ax_sportfreizeitunderholungsflaeche.gml_id, ax_sportfreizeitunderholungsflaeche.wkb_geometry, (140000 + ax_sportfreizeitunderholungsflaeche.funktion) AS funktion FROM ax_sportfreizeitunderholungsflaeche) UNION SELECT ax_friedhof.gml_id, ax_friedhof.wkb_geometry, (150000 + ax_friedhof.funktion) AS funktion FROM ax_friedhof) UNION SELECT ax_halde.gml_id, ax_halde.wkb_geometry, (160000 + ax_halde.lagergut) AS funktion FROM ax_halde) UNION SELECT ax_landwirtschaft.gml_id, ax_landwirtschaft.wkb_geometry, (170000 + ax_landwirtschaft.vegetationsmerkmal) AS funktion FROM ax_landwirtschaft) UNION SELECT ax_wald.gml_id, ax_wald.wkb_geometry, (180000 + ax_wald.vegetationsmerkmal) AS funktion FROM ax_wald) UNION SELECT ax_gehoelz.gml_id, ax_gehoelz.wkb_geometry, (190000 + ax_gehoelz.vegetationsmerkmal) AS funktion FROM ax_gehoelz) UNION SELECT ax_heide.gml_id, ax_heide.wkb_geometry, 200000 AS funktion FROM ax_heide) UNION SELECT ax_sumpf.gml_id, ax_sumpf.wkb_geometry, 210000 AS funktion FROM ax_sumpf) UNION SELECT ax_unlandvegetationsloseflaeche.gml_id, ax_unlandvegetationsloseflaeche.wkb_geometry, (220000 + ax_unlandvegetationsloseflaeche.funktion) AS funktion FROM ax_unlandvegetationsloseflaeche) UNION SELECT ax_tagebaugrubesteinbruch.gml_id, ax_tagebaugrubesteinbruch.wkb_geometry, (230000 + ax_tagebaugrubesteinbruch.abbaugut) AS funktion FROM ax_tagebaugrubesteinbruch) UNION SELECT ax_fliessgewaesser.gml_id, ax_fliessgewaesser.wkb_geometry, (240000 + ax_fliessgewaesser.funktion) AS funktion FROM ax_fliessgewaesser) UNION SELECT ax_stehendesgewaesser.gml_id, ax_stehendesgewaesser.wkb_geometry, (250000 + ax_stehendesgewaesser.funktion) AS funktion FROM ax_stehendesgewaesser) UNION SELECT ax_strassenverkehr.gml_id, ax_strassenverkehr.wkb_geometry, (260000 + ax_strassenverkehr.funktion) AS funktion FROM ax_strassenverkehr) UNION SELECT ax_platz.gml_id, ax_platz.wkb_geometry, (270000 + ax_platz.funktion) AS funktion FROM ax_platz) UNION SELECT ax_weg.gml_id, ax_weg.wkb_geometry, (280000 + ax_weg.funktion) AS funktion FROM ax_weg) UNION SELECT ax_flugverkehr.gml_id, ax_flugverkehr.wkb_geometry, (290000 + ax_flugverkehr.funktion) AS funktion FROM ax_flugverkehr) UNION SELECT ax_bahnverkehr.gml_id, ax_bahnverkehr.wkb_geometry, (300000 + ax_bahnverkehr.funktion) AS funktion FROM ax_bahnverkehr;


ALTER TABLE public.s_nutzungen OWNER TO postgres;

--
-- TOC entry 2876 (class 1259 OID 7768697)
-- Dependencies: 3005 3 930
-- Name: s_sonstigervermessungspunkt; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW s_sonstigervermessungspunkt AS
    SELECT ax_punktortag.ogc_fid, ax_punktortag.wkb_geometry, ax_sonstigervermessungspunkt.vermarkung_marke FROM (ax_punktortag JOIN ax_sonstigervermessungspunkt ON (((ax_punktortag.istteilvon)::bpchar = ax_sonstigervermessungspunkt.gml_id)));


ALTER TABLE public.s_sonstigervermessungspunkt OWNER TO postgres;

--
-- TOC entry 2783 (class 1259 OID 7506220)
-- Dependencies: 3001 3 930
-- Name: s_zugehoerigkeitshaken_flurstueck; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW s_zugehoerigkeitshaken_flurstueck AS
    SELECT ap_ppo.ogc_fid, ap_ppo.wkb_geometry, ap_ppo.gml_id, ap_ppo.art, (((ap_ppo.drehwinkel * (180)::double precision) / (3.14)::double precision) + ((90)::numeric)::double precision) AS drehwinkel, ap_ppo.dientzurdarstellungvon, ax_flurstueck.flurstueckskennzeichen FROM (ap_ppo JOIN ax_flurstueck ON (((ap_ppo.dientzurdarstellungvon)::bpchar = ax_flurstueck.gml_id))) WHERE (ap_ppo.art = 'Haken'::bpchar);


ALTER TABLE public.s_zugehoerigkeitshaken_flurstueck OWNER TO postgres;

--
-- TOC entry 2784 (class 1259 OID 7506225)
-- Dependencies: 3002 930 3
-- Name: s_zuordungspfeil_flurstueck; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW s_zuordungspfeil_flurstueck AS
    SELECT ap_lpo.ogc_fid, ap_lpo.wkb_geometry, ap_lpo.gml_id, ap_lpo.art, ap_lpo.dientzurdarstellungvon, ax_flurstueck.flurstueckskennzeichen FROM (ap_lpo JOIN ax_flurstueck ON (((ap_lpo.dientzurdarstellungvon)::bpchar = ax_flurstueck.gml_id)));


ALTER TABLE public.s_zuordungspfeil_flurstueck OWNER TO postgres;

--
-- TOC entry 2877 (class 1259 OID 8598509)
-- Dependencies: 3
-- Name: spatial_ref_sys; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE spatial_ref_sys (
    srid integer NOT NULL,
    auth_name character varying(256),
    auth_srid integer,
    srtext character varying(2048),
    proj4text character varying(2048)
);


ALTER TABLE public.spatial_ref_sys OWNER TO postgres;

--
-- TOC entry 1256 (class 0 OID 0)
-- Name: spheroid; Type: SHELL TYPE; Schema: public; Owner: postgres
--

CREATE TYPE spheroid;


--
-- TOC entry 38 (class 1255 OID 7506237)
-- Dependencies: 3 1256
-- Name: st_spheroid_in(cstring); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_spheroid_in(cstring) RETURNS spheroid
    AS '$libdir/liblwgeom', 'ellipsoid_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_spheroid_in(cstring) OWNER TO postgres;

--
-- TOC entry 39 (class 1255 OID 7506238)
-- Dependencies: 3 1256
-- Name: st_spheroid_out(spheroid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_spheroid_out(spheroid) RETURNS cstring
    AS '$libdir/liblwgeom', 'ellipsoid_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_spheroid_out(spheroid) OWNER TO postgres;

--
-- TOC entry 1255 (class 1247 OID 7506236)
-- Dependencies: 38 39 3
-- Name: spheroid; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE spheroid (
    INTERNALLENGTH = 65,
    INPUT = st_spheroid_in,
    OUTPUT = st_spheroid_out,
    ALIGNMENT = double,
    STORAGE = plain
);


ALTER TYPE public.spheroid OWNER TO postgres;

--
-- TOC entry 2890 (class 1259 OID 14668063)
-- Dependencies: 3
-- Name: v_anrede; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_anrede (
    id integer NOT NULL,
    anrede character varying
);


ALTER TABLE public.v_anrede OWNER TO postgres;

--
-- TOC entry 2889 (class 1259 OID 14668025)
-- Dependencies: 3
-- Name: v_artderrechtsgemeinschaft; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_artderrechtsgemeinschaft (
    id integer NOT NULL,
    artderrechtsgemeinschaft character varying
);


ALTER TABLE public.v_artderrechtsgemeinschaft OWNER TO postgres;

--
-- TOC entry 2887 (class 1259 OID 14606087)
-- Dependencies: 3
-- Name: v_blattart; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_blattart (
    id integer NOT NULL,
    blattart character varying
);


ALTER TABLE public.v_blattart OWNER TO postgres;

--
-- TOC entry 2886 (class 1259 OID 14605360)
-- Dependencies: 3
-- Name: v_buchungsart; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_buchungsart (
    id integer NOT NULL,
    buchungsart character varying
);


ALTER TABLE public.v_buchungsart OWNER TO postgres;

--
-- TOC entry 2888 (class 1259 OID 14668014)
-- Dependencies: 3
-- Name: v_eigentuemerart; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_eigentuemerart (
    id integer NOT NULL,
    eigentuemerart character varying
);


ALTER TABLE public.v_eigentuemerart OWNER TO postgres;

--
-- TOC entry 2904 (class 1259 OID 15116080)
-- Dependencies: 3
-- Name: v_nutzungen_abbaugut; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_abbaugut (
    id integer NOT NULL,
    abbaugut character varying
);


ALTER TABLE public.v_nutzungen_abbaugut OWNER TO postgres;

--
-- TOC entry 2906 (class 1259 OID 15182369)
-- Dependencies: 3
-- Name: v_nutzungen_art; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_art (
    id integer NOT NULL,
    art character varying
);


ALTER TABLE public.v_nutzungen_art OWNER TO postgres;

--
-- TOC entry 2894 (class 1259 OID 15114612)
-- Dependencies: 3
-- Name: v_nutzungen_artderbebauung; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_artderbebauung (
    id integer NOT NULL,
    artderbebauung character varying
);


ALTER TABLE public.v_nutzungen_artderbebauung OWNER TO postgres;

--
-- TOC entry 2905 (class 1259 OID 15181665)
-- Dependencies: 3
-- Name: v_nutzungen_bahnkategorie; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_bahnkategorie (
    id integer NOT NULL,
    bahnkategorie character varying
);


ALTER TABLE public.v_nutzungen_bahnkategorie OWNER TO postgres;

--
-- TOC entry 2897 (class 1259 OID 15114962)
-- Dependencies: 3
-- Name: v_nutzungen_foerdergut; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_foerdergut (
    id integer NOT NULL,
    foerdergut character varying
);


ALTER TABLE public.v_nutzungen_foerdergut OWNER TO postgres;

--
-- TOC entry 2896 (class 1259 OID 15114746)
-- Dependencies: 3
-- Name: v_nutzungen_funktion; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_funktion (
    id integer NOT NULL,
    funktion character varying,
    idobjektartengruppe integer NOT NULL
);


ALTER TABLE public.v_nutzungen_funktion OWNER TO postgres;

--
-- TOC entry 2916 (class 1259 OID 15184082)
-- Dependencies: 3
-- Name: v_nutzungen_hydrologischesmerkmal; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_hydrologischesmerkmal (
    id integer NOT NULL,
    hydrologischesmerkmal character varying
);


ALTER TABLE public.v_nutzungen_hydrologischesmerkmal OWNER TO postgres;

--
-- TOC entry 2898 (class 1259 OID 15115050)
-- Dependencies: 3
-- Name: v_nutzungen_lagergut; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_lagergut (
    id integer NOT NULL,
    lagergut character varying
);


ALTER TABLE public.v_nutzungen_lagergut OWNER TO postgres;

--
-- TOC entry 2907 (class 1259 OID 15182389)
-- Dependencies: 3
-- Name: v_nutzungen_nutzung; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_nutzung (
    id integer NOT NULL,
    nutzung character varying
);


ALTER TABLE public.v_nutzungen_nutzung OWNER TO postgres;

--
-- TOC entry 2913 (class 1259 OID 15183670)
-- Dependencies: 3
-- Name: v_nutzungen_oberflaechenmaterial; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_oberflaechenmaterial (
    id integer NOT NULL,
    oberflaechenmaterial character varying
);


ALTER TABLE public.v_nutzungen_oberflaechenmaterial OWNER TO postgres;

--
-- TOC entry 2893 (class 1259 OID 15114241)
-- Dependencies: 3
-- Name: v_nutzungen_objektartengruppen; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_objektartengruppen (
    id integer NOT NULL,
    objektartengruppe character varying
);


ALTER TABLE public.v_nutzungen_objektartengruppen OWNER TO postgres;

--
-- TOC entry 2899 (class 1259 OID 15115132)
-- Dependencies: 3
-- Name: v_nutzungen_primaerenergie; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_primaerenergie (
    id integer NOT NULL,
    primaerenergie character varying
);


ALTER TABLE public.v_nutzungen_primaerenergie OWNER TO postgres;

--
-- TOC entry 2917 (class 1259 OID 15184159)
-- Dependencies: 3
-- Name: v_nutzungen_tidemerkmal; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_tidemerkmal (
    id integer NOT NULL,
    tidemerkmal character varying
);


ALTER TABLE public.v_nutzungen_tidemerkmal OWNER TO postgres;

--
-- TOC entry 2910 (class 1259 OID 15182566)
-- Dependencies: 3
-- Name: v_nutzungen_vegetationsmerkmal; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_vegetationsmerkmal (
    id integer NOT NULL,
    vegetationsmerkmal character varying,
    idobjektartengruppe integer NOT NULL
);


ALTER TABLE public.v_nutzungen_vegetationsmerkmal OWNER TO postgres;

--
-- TOC entry 2895 (class 1259 OID 15114667)
-- Dependencies: 3
-- Name: v_nutzungen_zustand; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE v_nutzungen_zustand (
    id integer NOT NULL,
    zustand character varying
);


ALTER TABLE public.v_nutzungen_zustand OWNER TO postgres;


--
-- TOC entry 40 (class 1255 OID 7506240)
-- Dependencies: 3 930
-- Name: _st_asgeojson(integer, geometry, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _st_asgeojson(integer, geometry, integer, integer) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asGeoJson'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_asgeojson(integer, geometry, integer, integer) OWNER TO postgres;

--
-- TOC entry 41 (class 1255 OID 7506241)
-- Dependencies: 3 930
-- Name: _st_asgml(integer, geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _st_asgml(integer, geometry, integer) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asGML'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_asgml(integer, geometry, integer) OWNER TO postgres;

--
-- TOC entry 42 (class 1255 OID 7506242)
-- Dependencies: 3 930
-- Name: _st_askml(integer, geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _st_askml(integer, geometry, integer) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asKML'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_askml(integer, geometry, integer) OWNER TO postgres;

--
-- TOC entry 43 (class 1255 OID 7506243)
-- Dependencies: 930 3 930
-- Name: _st_contains(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _st_contains(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'contains'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_contains(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 44 (class 1255 OID 7506244)
-- Dependencies: 930 3 930
-- Name: _st_coveredby(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _st_coveredby(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'coveredby'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_coveredby(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 45 (class 1255 OID 7506245)
-- Dependencies: 930 3 930
-- Name: _st_covers(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _st_covers(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'covers'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_covers(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 46 (class 1255 OID 7506246)
-- Dependencies: 930 3 930
-- Name: _st_crosses(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _st_crosses(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'crosses'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_crosses(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 47 (class 1255 OID 7506247)
-- Dependencies: 930 3 930
-- Name: _st_dwithin(geometry, geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _st_dwithin(geometry, geometry, double precision) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_dwithin'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_dwithin(geometry, geometry, double precision) OWNER TO postgres;

--
-- TOC entry 48 (class 1255 OID 7506248)
-- Dependencies: 930 3 930
-- Name: _st_intersects(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _st_intersects(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'intersects'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_intersects(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 49 (class 1255 OID 7506249)
-- Dependencies: 930 3 930
-- Name: _st_overlaps(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _st_overlaps(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'overlaps'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_overlaps(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 50 (class 1255 OID 7506250)
-- Dependencies: 930 930 3
-- Name: _st_touches(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _st_touches(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'touches'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_touches(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 51 (class 1255 OID 7506251)
-- Dependencies: 930 930 3
-- Name: _st_within(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _st_within(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'within'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_within(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 52 (class 1255 OID 7506252)
-- Dependencies: 3 1478
-- Name: addauth(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION addauth(text) RETURNS boolean
    AS $_$
DECLARE
	lockid alias for $1;
	okay boolean;
	myrec record;
BEGIN
	-- check to see if table exists
	--  if not, CREATE TEMP TABLE mylock (transid xid, lockcode text)
	okay := 'f';
	FOR myrec IN SELECT * FROM pg_class WHERE relname = 'temp_lock_have_table' LOOP
		okay := 't';
	END LOOP; 
	IF (okay <> 't') THEN 
		CREATE TEMP TABLE temp_lock_have_table (transid xid, lockcode text);
			-- this will only work from pgsql7.4 up
			-- ON COMMIT DELETE ROWS;
	END IF;

	--  INSERT INTO mylock VALUES ( $1)
--	EXECUTE 'INSERT INTO temp_lock_have_table VALUES ( '||
--		quote_literal(getTransactionID()) || ',' ||
--		quote_literal(lockid) ||')';

	INSERT INTO temp_lock_have_table VALUES (getTransactionID(), lockid);

	RETURN true::boolean;
END;
$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.addauth(text) OWNER TO postgres;

--
-- TOC entry 53 (class 1255 OID 7506253)
-- Dependencies: 930 930 3
-- Name: addbbox(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION addbbox(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_addBBOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.addbbox(geometry) OWNER TO postgres;

--
-- TOC entry 54 (class 1255 OID 7506254)
-- Dependencies: 3 1478
-- Name: addgeometrycolumn(character varying, character varying, character varying, character varying, integer, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION addgeometrycolumn(character varying, character varying, character varying, character varying, integer, character varying, integer) RETURNS text
    AS $_$
DECLARE
	catalog_name alias for $1;
	schema_name alias for $2;
	table_name alias for $3;
	column_name alias for $4;
	new_srid alias for $5;
	new_type alias for $6;
	new_dim alias for $7;
	sr varchar;

	rec RECORD;
	schema_ok bool;
	real_schema name;


BEGIN

	IF ( not ( (new_type ='GEOMETRY') or
		   (new_type ='GEOMETRYCOLLECTION') or
		   (new_type ='POINT') or 
		   (new_type ='MULTIPOINT') or
		   (new_type ='POLYGON') or
		   (new_type ='MULTIPOLYGON') or
		   (new_type ='LINESTRING') or
		   (new_type ='MULTILINESTRING') or
		   (new_type ='GEOMETRYCOLLECTIONM') or
		   (new_type ='POINTM') or 
		   (new_type ='MULTIPOINTM') or
		   (new_type ='POLYGONM') or
		   (new_type ='MULTIPOLYGONM') or
		   (new_type ='LINESTRINGM') or
		   (new_type ='MULTILINESTRINGM') or
                   (new_type = 'CIRCULARSTRING') or
                   (new_type = 'CIRCULARSTRINGM') or
                   (new_type = 'COMPOUNDCURVE') or
                   (new_type = 'COMPOUNDCURVEM') or
                   (new_type = 'CURVEPOLYGON') or
                   (new_type = 'CURVEPOLYGONM') or
                   (new_type = 'MULTICURVE') or
                   (new_type = 'MULTICURVEM') or
                   (new_type = 'MULTISURFACE') or
                   (new_type = 'MULTISURFACEM')) )
	THEN
		RAISE EXCEPTION 'Invalid type name - valid ones are: 
			GEOMETRY, GEOMETRYCOLLECTION, POINT, 
			MULTIPOINT, POLYGON, MULTIPOLYGON, 
			LINESTRING, MULTILINESTRING,
                        CIRCULARSTRING, COMPOUNDCURVE,
                        CURVEPOLYGON, MULTICURVE, MULTISURFACE,
			GEOMETRYCOLLECTIONM, POINTM, 
			MULTIPOINTM, POLYGONM, MULTIPOLYGONM, 
			LINESTRINGM, MULTILINESTRINGM 
                        CIRCULARSTRINGM, COMPOUNDCURVEM,
                        CURVEPOLYGONM, MULTICURVEM or MULTISURFACEM';
		return 'fail';
	END IF;

	IF ( (new_dim >4) or (new_dim <0) ) THEN
		RAISE EXCEPTION 'invalid dimension';
		return 'fail';
	END IF;

	IF ( (new_type LIKE '%M') and (new_dim!=3) ) THEN

		RAISE EXCEPTION 'TypeM needs 3 dimensions';
		return 'fail';
	END IF;


	IF ( schema_name != '' ) THEN
		schema_ok = 'f';
		FOR rec IN SELECT nspname FROM pg_namespace WHERE text(nspname) = schema_name LOOP
			schema_ok := 't';
		END LOOP;

		if ( schema_ok <> 't' ) THEN
			RAISE NOTICE 'Invalid schema name - using current_schema()';
			SELECT current_schema() into real_schema;
		ELSE
			real_schema = schema_name;
		END IF;

	ELSE
		SELECT current_schema() into real_schema;
	END IF;


	IF ( new_srid != -1 ) THEN
		SELECT SRID INTO sr FROM SPATIAL_REF_SYS WHERE SRID = new_srid;
		IF NOT FOUND THEN
			RAISE EXCEPTION 'AddGeometryColumns() - invalid SRID';
		END IF;
	END IF;


	-- Add geometry column

	EXECUTE 'ALTER TABLE ' ||

		quote_ident(real_schema) || '.' || quote_ident(table_name)



		|| ' ADD COLUMN ' || quote_ident(column_name) || 
		' geometry ';


	-- Delete stale record in geometry_column (if any)

	EXECUTE 'DELETE FROM geometry_columns WHERE
		f_table_catalog = ' || quote_literal('') || 
		' AND f_table_schema = ' ||

		quote_literal(real_schema) || 



		' AND f_table_name = ' || quote_literal(table_name) ||
		' AND f_geometry_column = ' || quote_literal(column_name);


	-- Add record in geometry_column 

	EXECUTE 'INSERT INTO geometry_columns VALUES (' ||
		quote_literal('') || ',' ||

		quote_literal(real_schema) || ',' ||



		quote_literal(table_name) || ',' ||
		quote_literal(column_name) || ',' ||
		new_dim::text || ',' || new_srid::text || ',' ||
		quote_literal(new_type) || ')';

	-- Add table checks

	EXECUTE 'ALTER TABLE ' || 

		quote_ident(real_schema) || '.' || quote_ident(table_name)



		|| ' ADD CONSTRAINT ' 
		|| quote_ident('enforce_srid_' || column_name)
		|| ' CHECK (SRID(' || quote_ident(column_name) ||
		') = ' || new_srid::text || ')' ;

	EXECUTE 'ALTER TABLE ' || 

		quote_ident(real_schema) || '.' || quote_ident(table_name)



		|| ' ADD CONSTRAINT '
		|| quote_ident('enforce_dims_' || column_name)
		|| ' CHECK (ndims(' || quote_ident(column_name) ||
		') = ' || new_dim::text || ')' ;

	IF (not(new_type = 'GEOMETRY')) THEN
		EXECUTE 'ALTER TABLE ' || 

		quote_ident(real_schema) || '.' || quote_ident(table_name)



		|| ' ADD CONSTRAINT '
		|| quote_ident('enforce_geotype_' || column_name)
		|| ' CHECK (geometrytype(' ||
		quote_ident(column_name) || ')=' ||
		quote_literal(new_type) || ' OR (' ||
		quote_ident(column_name) || ') is null)';
	END IF;

	return 

		real_schema || '.' || 

		table_name || '.' || column_name ||
		' SRID:' || new_srid::text ||
		' TYPE:' || new_type || 
		' DIMS:' || new_dim::text || chr(10) || ' '; 
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.addgeometrycolumn(character varying, character varying, character varying, character varying, integer, character varying, integer) OWNER TO postgres;

--
-- TOC entry 55 (class 1255 OID 7506255)
-- Dependencies: 1478 3
-- Name: addgeometrycolumn(character varying, character varying, character varying, integer, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION addgeometrycolumn(character varying, character varying, character varying, integer, character varying, integer) RETURNS text
    AS $_$
DECLARE
	ret  text;
BEGIN
	SELECT AddGeometryColumn('',$1,$2,$3,$4,$5,$6) into ret;
	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STABLE STRICT;


ALTER FUNCTION public.addgeometrycolumn(character varying, character varying, character varying, integer, character varying, integer) OWNER TO postgres;

--
-- TOC entry 56 (class 1255 OID 7506256)
-- Dependencies: 3 1478
-- Name: addgeometrycolumn(character varying, character varying, integer, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION addgeometrycolumn(character varying, character varying, integer, character varying, integer) RETURNS text
    AS $_$
DECLARE
	ret  text;
BEGIN
	SELECT AddGeometryColumn('','',$1,$2,$3,$4,$5) into ret;
	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.addgeometrycolumn(character varying, character varying, integer, character varying, integer) OWNER TO postgres;

--
-- TOC entry 57 (class 1255 OID 7506257)
-- Dependencies: 930 3 930 930
-- Name: addpoint(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION addpoint(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_addpoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.addpoint(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 58 (class 1255 OID 7506258)
-- Dependencies: 930 3 930 930
-- Name: addpoint(geometry, geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION addpoint(geometry, geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_addpoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.addpoint(geometry, geometry, integer) OWNER TO postgres;

--
-- TOC entry 59 (class 1255 OID 7506259)
-- Dependencies: 930 3 930
-- Name: affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_affine'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 60 (class 1255 OID 7506260)
-- Dependencies: 3 930 930
-- Name: affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  $2, $3, 0,  $4, $5, 0,  0, 0, 1,  $6, $7, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 61 (class 1255 OID 7506261)
-- Dependencies: 3 930
-- Name: area(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION area(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_area_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.area(geometry) OWNER TO postgres;

--
-- TOC entry 62 (class 1255 OID 7506262)
-- Dependencies: 3 930
-- Name: area2d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION area2d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_area_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.area2d(geometry) OWNER TO postgres;

--
-- TOC entry 63 (class 1255 OID 7506263)
-- Dependencies: 3 930
-- Name: asbinary(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION asbinary(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_asBinary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.asbinary(geometry) OWNER TO postgres;

--
-- TOC entry 64 (class 1255 OID 7506264)
-- Dependencies: 930 3
-- Name: asbinary(geometry, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION asbinary(geometry, text) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_asBinary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.asbinary(geometry, text) OWNER TO postgres;

--
-- TOC entry 65 (class 1255 OID 7506265)
-- Dependencies: 930 3
-- Name: asewkb(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION asewkb(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'WKBFromLWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.asewkb(geometry) OWNER TO postgres;

--
-- TOC entry 66 (class 1255 OID 7506266)
-- Dependencies: 930 3
-- Name: asewkb(geometry, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION asewkb(geometry, text) RETURNS bytea
    AS '$libdir/liblwgeom', 'WKBFromLWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.asewkb(geometry, text) OWNER TO postgres;

--
-- TOC entry 67 (class 1255 OID 7506267)
-- Dependencies: 3 930
-- Name: asewkt(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION asewkt(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asEWKT'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.asewkt(geometry) OWNER TO postgres;

--
-- TOC entry 68 (class 1255 OID 7506268)
-- Dependencies: 3 930
-- Name: asgml(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION asgml(geometry, integer) RETURNS text
    AS $_$SELECT _ST_AsGML(2, $1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.asgml(geometry, integer) OWNER TO postgres;

--
-- TOC entry 69 (class 1255 OID 7506269)
-- Dependencies: 930 3
-- Name: asgml(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION asgml(geometry) RETURNS text
    AS $_$SELECT _ST_AsGML(2, $1, 15)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.asgml(geometry) OWNER TO postgres;

--
-- TOC entry 70 (class 1255 OID 7506270)
-- Dependencies: 930 3
-- Name: ashexewkb(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION ashexewkb(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asHEXEWKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.ashexewkb(geometry) OWNER TO postgres;

--
-- TOC entry 71 (class 1255 OID 7506271)
-- Dependencies: 3 930
-- Name: ashexewkb(geometry, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION ashexewkb(geometry, text) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asHEXEWKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.ashexewkb(geometry, text) OWNER TO postgres;

--
-- TOC entry 72 (class 1255 OID 7506272)
-- Dependencies: 930 3
-- Name: askml(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION askml(geometry, integer) RETURNS text
    AS $_$SELECT _ST_AsKML(2, transform($1,4326), $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.askml(geometry, integer) OWNER TO postgres;

--
-- TOC entry 73 (class 1255 OID 7506273)
-- Dependencies: 930 3
-- Name: askml(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION askml(geometry) RETURNS text
    AS $_$SELECT _ST_AsKML(2, transform($1,4326), 15)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.askml(geometry) OWNER TO postgres;

--
-- TOC entry 74 (class 1255 OID 7506274)
-- Dependencies: 3 930
-- Name: askml(integer, geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION askml(integer, geometry, integer) RETURNS text
    AS $_$SELECT _ST_AsKML($1, transform($2,4326), $3)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.askml(integer, geometry, integer) OWNER TO postgres;

--
-- TOC entry 75 (class 1255 OID 7506275)
-- Dependencies: 3 930
-- Name: assvg(geometry, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION assvg(geometry, integer, integer) RETURNS text
    AS '$libdir/liblwgeom', 'assvg_geometry'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.assvg(geometry, integer, integer) OWNER TO postgres;

--
-- TOC entry 76 (class 1255 OID 7506276)
-- Dependencies: 3 930
-- Name: assvg(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION assvg(geometry, integer) RETURNS text
    AS '$libdir/liblwgeom', 'assvg_geometry'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.assvg(geometry, integer) OWNER TO postgres;

--
-- TOC entry 77 (class 1255 OID 7506277)
-- Dependencies: 930 3
-- Name: assvg(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION assvg(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'assvg_geometry'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.assvg(geometry) OWNER TO postgres;

--
-- TOC entry 78 (class 1255 OID 7506278)
-- Dependencies: 930 3
-- Name: astext(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION astext(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asText'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.astext(geometry) OWNER TO postgres;

--
-- TOC entry 79 (class 1255 OID 7506279)
-- Dependencies: 3 930 930
-- Name: azimuth(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION azimuth(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_azimuth'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.azimuth(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 80 (class 1255 OID 7506280)
-- Dependencies: 930 3 1478
-- Name: bdmpolyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION bdmpolyfromtext(text, integer) RETURNS geometry
    AS $_$
DECLARE
	geomtext alias for $1;
	srid alias for $2;
	mline geometry;
	geom geometry;
BEGIN
	mline := MultiLineStringFromText(geomtext, srid);

	IF mline IS NULL
	THEN
		RAISE EXCEPTION 'Input is not a MultiLinestring';
	END IF;

	geom := multi(BuildArea(mline));

	RETURN geom;
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.bdmpolyfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 81 (class 1255 OID 7506281)
-- Dependencies: 3 930 1478
-- Name: bdpolyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION bdpolyfromtext(text, integer) RETURNS geometry
    AS $_$
DECLARE
	geomtext alias for $1;
	srid alias for $2;
	mline geometry;
	geom geometry;
BEGIN
	mline := MultiLineStringFromText(geomtext, srid);

	IF mline IS NULL
	THEN
		RAISE EXCEPTION 'Input is not a MultiLinestring';
	END IF;

	geom := BuildArea(mline);

	IF GeometryType(geom) != 'POLYGON'
	THEN
		RAISE EXCEPTION 'Input returns more then a single polygon, try using BdMPolyFromText instead';
	END IF;

	RETURN geom;
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.bdpolyfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 82 (class 1255 OID 7506282)
-- Dependencies: 3 930 930
-- Name: boundary(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION boundary(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'boundary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.boundary(geometry) OWNER TO postgres;

--
-- TOC entry 83 (class 1255 OID 7506283)
-- Dependencies: 930 3
-- Name: box(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box(geometry) RETURNS box
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box(geometry) OWNER TO postgres;

--
-- TOC entry 84 (class 1255 OID 7506284)
-- Dependencies: 1225 3
-- Name: box(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box(box3d) RETURNS box
    AS '$libdir/liblwgeom', 'BOX3D_to_BOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box(box3d) OWNER TO postgres;

--
-- TOC entry 85 (class 1255 OID 7506285)
-- Dependencies: 3 930 1221
-- Name: box2d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box2d(geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX2DFLOAT4'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d(geometry) OWNER TO postgres;

--
-- TOC entry 86 (class 1255 OID 7506286)
-- Dependencies: 1221 1225 3
-- Name: box2d(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box2d(box3d) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX3D_to_BOX2DFLOAT4'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d(box3d) OWNER TO postgres;

--
-- TOC entry 87 (class 1255 OID 7506287)
-- Dependencies: 1221 1221 3
-- Name: box2d_contain(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box2d_contain(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_contain'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_contain(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 88 (class 1255 OID 7506288)
-- Dependencies: 3 1221 1221
-- Name: box2d_contained(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box2d_contained(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_contained'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_contained(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 89 (class 1255 OID 7506289)
-- Dependencies: 1221 3
-- Name: box2d_in(cstring); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box2d_in(cstring) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_in(cstring) OWNER TO postgres;

--
-- TOC entry 90 (class 1255 OID 7506290)
-- Dependencies: 1221 1221 3
-- Name: box2d_intersects(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box2d_intersects(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_intersects'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_intersects(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 91 (class 1255 OID 7506291)
-- Dependencies: 3 1221 1221
-- Name: box2d_left(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box2d_left(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_left'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_left(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 92 (class 1255 OID 7506292)
-- Dependencies: 3 1221
-- Name: box2d_out(box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box2d_out(box2d) RETURNS cstring
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_out(box2d) OWNER TO postgres;

--
-- TOC entry 93 (class 1255 OID 7506293)
-- Dependencies: 1221 1221 3
-- Name: box2d_overlap(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box2d_overlap(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_overlap'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_overlap(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 94 (class 1255 OID 7506294)
-- Dependencies: 1221 3 1221
-- Name: box2d_overleft(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box2d_overleft(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_overleft'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_overleft(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 95 (class 1255 OID 7506295)
-- Dependencies: 1221 3 1221
-- Name: box2d_overright(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box2d_overright(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_overright'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_overright(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 96 (class 1255 OID 7506296)
-- Dependencies: 3 1221 1221
-- Name: box2d_right(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box2d_right(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_right'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_right(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 97 (class 1255 OID 7506297)
-- Dependencies: 1221 1221 3
-- Name: box2d_same(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box2d_same(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_same'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_same(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 98 (class 1255 OID 7506298)
-- Dependencies: 1225 930 3
-- Name: box3d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box3d(geometry) RETURNS box3d
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX3D'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box3d(geometry) OWNER TO postgres;

--
-- TOC entry 99 (class 1255 OID 7506299)
-- Dependencies: 1221 1225 3
-- Name: box3d(box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box3d(box2d) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_to_BOX3D'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box3d(box2d) OWNER TO postgres;

--
-- TOC entry 100 (class 1255 OID 7506300)
-- Dependencies: 1225 3
-- Name: box3d_in(cstring); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box3d_in(cstring) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box3d_in(cstring) OWNER TO postgres;

--
-- TOC entry 101 (class 1255 OID 7506301)
-- Dependencies: 3 1225
-- Name: box3d_out(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box3d_out(box3d) RETURNS cstring
    AS '$libdir/liblwgeom', 'BOX3D_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box3d_out(box3d) OWNER TO postgres;

--
-- TOC entry 102 (class 1255 OID 7506302)
-- Dependencies: 1225 3
-- Name: box3dtobox(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION box3dtobox(box3d) RETURNS box
    AS $_$SELECT box($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.box3dtobox(box3d) OWNER TO postgres;

--
-- TOC entry 103 (class 1255 OID 7506303)
-- Dependencies: 930 3 930
-- Name: buffer(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION buffer(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'buffer'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.buffer(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 104 (class 1255 OID 7506304)
-- Dependencies: 930 930 3
-- Name: buffer(geometry, double precision, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION buffer(geometry, double precision, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'buffer'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.buffer(geometry, double precision, integer) OWNER TO postgres;

--
-- TOC entry 105 (class 1255 OID 7506305)
-- Dependencies: 1237 3 1237
-- Name: build_histogram2d(histogram2d, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION build_histogram2d(histogram2d, text, text) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'build_lwhistogram2d'
    LANGUAGE c STABLE STRICT;


ALTER FUNCTION public.build_histogram2d(histogram2d, text, text) OWNER TO postgres;

--
-- TOC entry 106 (class 1255 OID 7506306)
-- Dependencies: 1237 1237 1478 3
-- Name: build_histogram2d(histogram2d, text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION build_histogram2d(histogram2d, text, text, text) RETURNS histogram2d
    AS $_$
BEGIN
	EXECUTE 'SET local search_path = '||$2||',public';
	RETURN public.build_histogram2d($1,$3,$4);
END
$_$
    LANGUAGE plpgsql STABLE STRICT;


ALTER FUNCTION public.build_histogram2d(histogram2d, text, text, text) OWNER TO postgres;

--
-- TOC entry 107 (class 1255 OID 7506307)
-- Dependencies: 930 3 930
-- Name: buildarea(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION buildarea(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_buildarea'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.buildarea(geometry) OWNER TO postgres;

--
-- TOC entry 108 (class 1255 OID 7506308)
-- Dependencies: 930 3
-- Name: bytea(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION bytea(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_to_bytea'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.bytea(geometry) OWNER TO postgres;

--
-- TOC entry 109 (class 1255 OID 7506309)
-- Dependencies: 3
-- Name: cache_bbox(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION cache_bbox() RETURNS trigger
    AS '$libdir/liblwgeom', 'cache_bbox'
    LANGUAGE c;


ALTER FUNCTION public.cache_bbox() OWNER TO postgres;

--
-- TOC entry 110 (class 1255 OID 7506310)
-- Dependencies: 3 930 930
-- Name: centroid(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION centroid(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'centroid'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.centroid(geometry) OWNER TO postgres;

--
-- TOC entry 111 (class 1255 OID 7506311)
-- Dependencies: 1478 3
-- Name: checkauth(text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION checkauth(text, text, text) RETURNS integer
    AS $_$
DECLARE

	schema text;

BEGIN
	IF NOT LongTransactionsEnabled() THEN
		RAISE EXCEPTION 'Long transaction support disabled, use EnableLongTransaction() to enable.';
	END IF;


	if ( $1 != '' ) THEN
		schema = $1;
	ELSE
		SELECT current_schema() into schema;
	END IF;


	-- TODO: check for an already existing trigger ?

	EXECUTE 'CREATE TRIGGER check_auth BEFORE UPDATE OR DELETE ON ' 

		|| quote_ident(schema) || '.' || quote_ident($2)



		||' FOR EACH ROW EXECUTE PROCEDURE CheckAuthTrigger('
		|| quote_literal($3) || ')';

	RETURN 0;
END;
$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.checkauth(text, text, text) OWNER TO postgres;

--
-- TOC entry 112 (class 1255 OID 7506312)
-- Dependencies: 3
-- Name: checkauth(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION checkauth(text, text) RETURNS integer
    AS $_$SELECT CheckAuth('', $1, $2)$_$
    LANGUAGE sql;


ALTER FUNCTION public.checkauth(text, text) OWNER TO postgres;

--
-- TOC entry 113 (class 1255 OID 7506313)
-- Dependencies: 3
-- Name: checkauthtrigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION checkauthtrigger() RETURNS trigger
    AS '$libdir/liblwgeom', 'check_authorization'
    LANGUAGE c;


ALTER FUNCTION public.checkauthtrigger() OWNER TO postgres;

--
-- TOC entry 114 (class 1255 OID 7506314)
-- Dependencies: 1229 3
-- Name: chip_in(cstring); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION chip_in(cstring) RETURNS chip
    AS '$libdir/liblwgeom', 'CHIP_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.chip_in(cstring) OWNER TO postgres;

--
-- TOC entry 115 (class 1255 OID 7506315)
-- Dependencies: 3 1229
-- Name: chip_out(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION chip_out(chip) RETURNS cstring
    AS '$libdir/liblwgeom', 'CHIP_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.chip_out(chip) OWNER TO postgres;

--
-- TOC entry 116 (class 1255 OID 7506316)
-- Dependencies: 930 930 930 3
-- Name: collect(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION collect(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_collect'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.collect(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 117 (class 1255 OID 7506317)
-- Dependencies: 3 933 930
-- Name: collect_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION collect_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_collect_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.collect_garray(geometry[]) OWNER TO postgres;

--
-- TOC entry 118 (class 1255 OID 7506318)
-- Dependencies: 3 930 930 930
-- Name: collector(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION collector(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_collect'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.collector(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 119 (class 1255 OID 7506319)
-- Dependencies: 1221 3 930 1221
-- Name: combine_bbox(box2d, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION combine_bbox(box2d, geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_combine'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.combine_bbox(box2d, geometry) OWNER TO postgres;

--
-- TOC entry 120 (class 1255 OID 7506320)
-- Dependencies: 1225 3 1225 930
-- Name: combine_bbox(box3d, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION combine_bbox(box3d, geometry) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_combine'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.combine_bbox(box3d, geometry) OWNER TO postgres;

--
-- TOC entry 121 (class 1255 OID 7506321)
-- Dependencies: 3 1229
-- Name: compression(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION compression(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getCompression'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.compression(chip) OWNER TO postgres;

--
-- TOC entry 122 (class 1255 OID 7506322)
-- Dependencies: 3 930 930
-- Name: contains(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION contains(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'contains'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.contains(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 123 (class 1255 OID 7506323)
-- Dependencies: 930 3 930
-- Name: convexhull(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION convexhull(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'convexhull'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.convexhull(geometry) OWNER TO postgres;

--
-- TOC entry 124 (class 1255 OID 7506324)
-- Dependencies: 1237 3 1221
-- Name: create_histogram2d(box2d, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION create_histogram2d(box2d, integer) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'create_lwhistogram2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.create_histogram2d(box2d, integer) OWNER TO postgres;

--
-- TOC entry 125 (class 1255 OID 7506325)
-- Dependencies: 3 930 930
-- Name: crosses(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION crosses(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'crosses'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.crosses(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 126 (class 1255 OID 7506326)
-- Dependencies: 3 1229
-- Name: datatype(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION datatype(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getDatatype'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.datatype(chip) OWNER TO postgres;

--
-- TOC entry 127 (class 1255 OID 7506327)
-- Dependencies: 3 930 930 930
-- Name: difference(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION difference(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'difference'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.difference(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 128 (class 1255 OID 7506328)
-- Dependencies: 3 930
-- Name: dimension(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dimension(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_dimension'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.dimension(geometry) OWNER TO postgres;

--
-- TOC entry 129 (class 1255 OID 7506329)
-- Dependencies: 3 1478
-- Name: disablelongtransactions(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION disablelongtransactions() RETURNS text
    AS $$
DECLARE
	rec RECORD;

BEGIN

	--
	-- Drop all triggers applied by CheckAuth()
	--
	FOR rec IN
		SELECT c.relname, t.tgname, t.tgargs FROM pg_trigger t, pg_class c, pg_proc p
		WHERE p.proname = 'checkauthtrigger' and t.tgfoid = p.oid and t.tgrelid = c.oid
	LOOP
		EXECUTE 'DROP TRIGGER ' || quote_ident(rec.tgname) ||
			' ON ' || quote_ident(rec.relname);
	END LOOP;

	--
	-- Drop the authorization_table table
	--
	FOR rec IN SELECT * FROM pg_class WHERE relname = 'authorization_table' LOOP
		DROP TABLE authorization_table;
	END LOOP;

	--
	-- Drop the authorized_tables view
	--
	FOR rec IN SELECT * FROM pg_class WHERE relname = 'authorized_tables' LOOP
		DROP VIEW authorized_tables;
	END LOOP;

	RETURN 'Long transactions support disabled';
END;
$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.disablelongtransactions() OWNER TO postgres;

--
-- TOC entry 130 (class 1255 OID 7506330)
-- Dependencies: 930 930 3
-- Name: disjoint(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION disjoint(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'disjoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.disjoint(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 131 (class 1255 OID 7506331)
-- Dependencies: 3 930 930
-- Name: distance(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION distance(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_mindistance2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.distance(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 132 (class 1255 OID 7506332)
-- Dependencies: 930 930 3
-- Name: distance_sphere(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION distance_sphere(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_distance_sphere'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.distance_sphere(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 133 (class 1255 OID 7506333)
-- Dependencies: 3 930 1255 930
-- Name: distance_spheroid(geometry, geometry, spheroid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION distance_spheroid(geometry, geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_distance_ellipsoid_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.distance_spheroid(geometry, geometry, spheroid) OWNER TO postgres;

--
-- TOC entry 134 (class 1255 OID 7506334)
-- Dependencies: 930 930 3
-- Name: dropbbox(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dropbbox(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_dropBBOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.dropbbox(geometry) OWNER TO postgres;

--
-- TOC entry 135 (class 1255 OID 7506335)
-- Dependencies: 3 1478
-- Name: dropgeometrycolumn(character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dropgeometrycolumn(character varying, character varying, character varying, character varying) RETURNS text
    AS $_$
DECLARE
	catalog_name alias for $1; 
	schema_name alias for $2;
	table_name alias for $3;
	column_name alias for $4;
	myrec RECORD;
	okay boolean;
	real_schema name;

BEGIN



	-- Find, check or fix schema_name
	IF ( schema_name != '' ) THEN
		okay = 'f';

		FOR myrec IN SELECT nspname FROM pg_namespace WHERE text(nspname) = schema_name LOOP
			okay := 't';
		END LOOP;

		IF ( okay <> 't' ) THEN
			RAISE NOTICE 'Invalid schema name - using current_schema()';
			SELECT current_schema() into real_schema;
		ELSE
			real_schema = schema_name;
		END IF;
	ELSE
		SELECT current_schema() into real_schema;
	END IF;




 	-- Find out if the column is in the geometry_columns table
	okay = 'f';
	FOR myrec IN SELECT * from geometry_columns where f_table_schema = text(real_schema) and f_table_name = table_name and f_geometry_column = column_name LOOP
		okay := 't';
	END LOOP; 
	IF (okay <> 't') THEN 
		RAISE EXCEPTION 'column not found in geometry_columns table';
		RETURN 'f';
	END IF;

	-- Remove ref from geometry_columns table
	EXECUTE 'delete from geometry_columns where f_table_schema = ' ||
		quote_literal(real_schema) || ' and f_table_name = ' ||
		quote_literal(table_name)  || ' and f_geometry_column = ' ||
		quote_literal(column_name);
	
	-- Remove table column
	EXECUTE 'ALTER TABLE ' || quote_ident(real_schema) || '.' ||
		quote_ident(table_name) || ' DROP COLUMN ' ||
		quote_ident(column_name);



	RETURN real_schema || '.' || table_name || '.' || column_name ||' effectively removed.';
	
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.dropgeometrycolumn(character varying, character varying, character varying, character varying) OWNER TO postgres;

--
-- TOC entry 136 (class 1255 OID 7506336)
-- Dependencies: 3 1478
-- Name: dropgeometrycolumn(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dropgeometrycolumn(character varying, character varying, character varying) RETURNS text
    AS $_$
DECLARE
	ret text;
BEGIN
	SELECT DropGeometryColumn('',$1,$2,$3) into ret;
	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.dropgeometrycolumn(character varying, character varying, character varying) OWNER TO postgres;

--
-- TOC entry 137 (class 1255 OID 7506337)
-- Dependencies: 3 1478
-- Name: dropgeometrycolumn(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dropgeometrycolumn(character varying, character varying) RETURNS text
    AS $_$
DECLARE
	ret text;
BEGIN
	SELECT DropGeometryColumn('','',$1,$2) into ret;
	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.dropgeometrycolumn(character varying, character varying) OWNER TO postgres;

--
-- TOC entry 138 (class 1255 OID 7506338)
-- Dependencies: 3 1478
-- Name: dropgeometrytable(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dropgeometrytable(character varying, character varying, character varying) RETURNS text
    AS $_$
DECLARE
	catalog_name alias for $1; 
	schema_name alias for $2;
	table_name alias for $3;
	real_schema name;

BEGIN


	IF ( schema_name = '' ) THEN
		SELECT current_schema() into real_schema;
	ELSE
		real_schema = schema_name;
	END IF;


	-- Remove refs from geometry_columns table
	EXECUTE 'DELETE FROM geometry_columns WHERE ' ||

		'f_table_schema = ' || quote_literal(real_schema) ||
		' AND ' ||

		' f_table_name = ' || quote_literal(table_name);
	
	-- Remove table 
	EXECUTE 'DROP TABLE '

		|| quote_ident(real_schema) || '.' ||

		quote_ident(table_name);

	RETURN

		real_schema || '.' ||

		table_name ||' dropped.';
	
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.dropgeometrytable(character varying, character varying, character varying) OWNER TO postgres;

--
-- TOC entry 139 (class 1255 OID 7506339)
-- Dependencies: 3
-- Name: dropgeometrytable(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dropgeometrytable(character varying, character varying) RETURNS text
    AS $_$SELECT DropGeometryTable('',$1,$2)$_$
    LANGUAGE sql STRICT;


ALTER FUNCTION public.dropgeometrytable(character varying, character varying) OWNER TO postgres;

--
-- TOC entry 140 (class 1255 OID 7506340)
-- Dependencies: 3
-- Name: dropgeometrytable(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dropgeometrytable(character varying) RETURNS text
    AS $_$SELECT DropGeometryTable('','',$1)$_$
    LANGUAGE sql STRICT;


ALTER FUNCTION public.dropgeometrytable(character varying) OWNER TO postgres;

--
-- TOC entry 141 (class 1255 OID 7506341)
-- Dependencies: 930 3 1235
-- Name: dump(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dump(geometry) RETURNS SETOF geometry_dump
    AS '$libdir/liblwgeom', 'LWGEOM_dump'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.dump(geometry) OWNER TO postgres;

--
-- TOC entry 142 (class 1255 OID 7506342)
-- Dependencies: 1235 3 930
-- Name: dumprings(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dumprings(geometry) RETURNS SETOF geometry_dump
    AS '$libdir/liblwgeom', 'LWGEOM_dump_rings'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.dumprings(geometry) OWNER TO postgres;

--
-- TOC entry 143 (class 1255 OID 7506343)
-- Dependencies: 3 1478
-- Name: enablelongtransactions(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION enablelongtransactions() RETURNS text
    AS $$
DECLARE
	"query" text;
	exists bool;
	rec RECORD;

BEGIN

	exists = 'f';
	FOR rec IN SELECT * FROM pg_class WHERE relname = 'authorization_table'
	LOOP
		exists = 't';
	END LOOP;

	IF NOT exists
	THEN
		"query" = 'CREATE TABLE authorization_table (
			toid oid, -- table oid
			rid text, -- row id
			expires timestamp,
			authid text
		)';
		EXECUTE "query";
	END IF;

	exists = 'f';
	FOR rec IN SELECT * FROM pg_class WHERE relname = 'authorized_tables'
	LOOP
		exists = 't';
	END LOOP;

	IF NOT exists THEN
		"query" = 'CREATE VIEW authorized_tables AS ' ||
			'SELECT ' ||

			'n.nspname as schema, ' ||

			'c.relname as table, trim(' ||
			quote_literal(chr(92) || '000') ||
			' from t.tgargs) as id_column ' ||
			'FROM pg_trigger t, pg_class c, pg_proc p ' ||

			', pg_namespace n ' ||

			'WHERE p.proname = ' || quote_literal('checkauthtrigger') ||

			' AND c.relnamespace = n.oid' ||

			' AND t.tgfoid = p.oid and t.tgrelid = c.oid';
		EXECUTE "query";
	END IF;

	RETURN 'Long transactions support enabled';
END;
$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.enablelongtransactions() OWNER TO postgres;

--
-- TOC entry 144 (class 1255 OID 7506344)
-- Dependencies: 930 3 930
-- Name: endpoint(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION endpoint(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_endpoint_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.endpoint(geometry) OWNER TO postgres;

--
-- TOC entry 145 (class 1255 OID 7506345)
-- Dependencies: 3 930 930
-- Name: envelope(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION envelope(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_envelope'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.envelope(geometry) OWNER TO postgres;

--
-- TOC entry 146 (class 1255 OID 7506346)
-- Dependencies: 3 930 930
-- Name: equals(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION equals(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'geomequals'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.equals(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 147 (class 1255 OID 7506347)
-- Dependencies: 3 1237 1221
-- Name: estimate_histogram2d(histogram2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION estimate_histogram2d(histogram2d, box2d) RETURNS double precision
    AS '$libdir/liblwgeom', 'estimate_lwhistogram2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.estimate_histogram2d(histogram2d, box2d) OWNER TO postgres;

--
-- TOC entry 148 (class 1255 OID 7506348)
-- Dependencies: 3 1221
-- Name: estimated_extent(text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION estimated_extent(text, text, text) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_estimated_extent'
    LANGUAGE c IMMUTABLE STRICT SECURITY DEFINER;


ALTER FUNCTION public.estimated_extent(text, text, text) OWNER TO postgres;

--
-- TOC entry 149 (class 1255 OID 7506349)
-- Dependencies: 3 1221
-- Name: estimated_extent(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION estimated_extent(text, text) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_estimated_extent'
    LANGUAGE c IMMUTABLE STRICT SECURITY DEFINER;


ALTER FUNCTION public.estimated_extent(text, text) OWNER TO postgres;

--
-- TOC entry 150 (class 1255 OID 7506350)
-- Dependencies: 1225 1225 3
-- Name: expand(box3d, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION expand(box3d, double precision) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_expand'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.expand(box3d, double precision) OWNER TO postgres;

--
-- TOC entry 151 (class 1255 OID 7506351)
-- Dependencies: 3 1221 1221
-- Name: expand(box2d, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION expand(box2d, double precision) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_expand'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.expand(box2d, double precision) OWNER TO postgres;

--
-- TOC entry 152 (class 1255 OID 7506352)
-- Dependencies: 3 930 930
-- Name: expand(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION expand(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_expand'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.expand(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 153 (class 1255 OID 7506353)
-- Dependencies: 3 1237 1237
-- Name: explode_histogram2d(histogram2d, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION explode_histogram2d(histogram2d, text) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'explode_lwhistogram2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.explode_histogram2d(histogram2d, text) OWNER TO postgres;

--
-- TOC entry 154 (class 1255 OID 7506354)
-- Dependencies: 3 930 930
-- Name: exteriorring(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION exteriorring(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_exteriorring_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.exteriorring(geometry) OWNER TO postgres;

--
-- TOC entry 155 (class 1255 OID 7506355)
-- Dependencies: 3 1229
-- Name: factor(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION factor(chip) RETURNS real
    AS '$libdir/liblwgeom', 'CHIP_getFactor'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.factor(chip) OWNER TO postgres;

--
-- TOC entry 156 (class 1255 OID 7506356)
-- Dependencies: 1221 1478 3
-- Name: find_extent(text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION find_extent(text, text, text) RETURNS box2d
    AS $_$
DECLARE
	schemaname alias for $1;
	tablename alias for $2;
	columnname alias for $3;
	myrec RECORD;

BEGIN
	FOR myrec IN EXECUTE 'SELECT extent("'||columnname||'") FROM "'||schemaname||'"."'||tablename||'"' LOOP
		return myrec.extent;
	END LOOP; 
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.find_extent(text, text, text) OWNER TO postgres;

--
-- TOC entry 157 (class 1255 OID 7506357)
-- Dependencies: 1221 3 1478
-- Name: find_extent(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION find_extent(text, text) RETURNS box2d
    AS $_$
DECLARE
	tablename alias for $1;
	columnname alias for $2;
	myrec RECORD;

BEGIN
	FOR myrec IN EXECUTE 'SELECT extent("'||columnname||'") FROM "'||tablename||'"' LOOP
		return myrec.extent;
	END LOOP; 
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.find_extent(text, text) OWNER TO postgres;

--
-- TOC entry 158 (class 1255 OID 7506358)
-- Dependencies: 1478 3
-- Name: find_srid(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION find_srid(character varying, character varying, character varying) RETURNS integer
    AS $_$DECLARE
   schem text;
   tabl text;
   sr int4;
BEGIN
   IF $1 IS NULL THEN
      RAISE EXCEPTION 'find_srid() - schema is NULL!';
   END IF;
   IF $2 IS NULL THEN
      RAISE EXCEPTION 'find_srid() - table name is NULL!';
   END IF;
   IF $3 IS NULL THEN
      RAISE EXCEPTION 'find_srid() - column name is NULL!';
   END IF;
   schem = $1;
   tabl = $2;
-- if the table contains a . and the schema is empty
-- split the table into a schema and a table
-- otherwise drop through to default behavior
   IF ( schem = '' and tabl LIKE '%.%' ) THEN
     schem = substr(tabl,1,strpos(tabl,'.')-1);
     tabl = substr(tabl,length(schem)+2);
   ELSE
     schem = schem || '%';
   END IF;

   select SRID into sr from geometry_columns where f_table_schema like schem and f_table_name = tabl and f_geometry_column = $3;
   IF NOT FOUND THEN
       RAISE EXCEPTION 'find_srid() - couldnt find the corresponding SRID - is the geometry registered in the GEOMETRY_COLUMNS table?  Is there an uppercase/lowercase missmatch?';
   END IF;
  return sr;
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.find_srid(character varying, character varying, character varying) OWNER TO postgres;

--
-- TOC entry 159 (class 1255 OID 7506359)
-- Dependencies: 1478 3
-- Name: fix_geometry_columns(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION fix_geometry_columns() RETURNS text
    AS $$
DECLARE
	mislinked record;
	result text;
	linked integer;
	deleted integer;

	foundschema integer;

BEGIN


	-- Since 7.3 schema support has been added.
	-- Previous postgis versions used to put the database name in
	-- the schema column. This needs to be fixed, so we try to 
	-- set the correct schema for each geometry_colums record
	-- looking at table, column, type and srid.
	UPDATE geometry_columns SET f_table_schema = n.nspname
		FROM pg_namespace n, pg_class c, pg_attribute a,
			pg_constraint sridcheck, pg_constraint typecheck
                WHERE ( f_table_schema is NULL
		OR f_table_schema = ''
                OR f_table_schema NOT IN (
                        SELECT nspname::varchar
                        FROM pg_namespace nn, pg_class cc, pg_attribute aa
                        WHERE cc.relnamespace = nn.oid
                        AND cc.relname = f_table_name::name
                        AND aa.attrelid = cc.oid
                        AND aa.attname = f_geometry_column::name))
                AND f_table_name::name = c.relname
                AND c.oid = a.attrelid
                AND c.relnamespace = n.oid
                AND f_geometry_column::name = a.attname

                AND sridcheck.conrelid = c.oid
		AND sridcheck.consrc LIKE '(srid(% = %)'
                AND sridcheck.consrc ~ textcat(' = ', srid::text)

                AND typecheck.conrelid = c.oid
		AND typecheck.consrc LIKE
	'((geometrytype(%) = ''%''::text) OR (% IS NULL))'
                AND typecheck.consrc ~ textcat(' = ''', type::text)

                AND NOT EXISTS (
                        SELECT oid FROM geometry_columns gc
                        WHERE c.relname::varchar = gc.f_table_name
                        AND n.nspname::varchar = gc.f_table_schema
                        AND a.attname::varchar = gc.f_geometry_column
                );

	GET DIAGNOSTICS foundschema = ROW_COUNT;



	-- no linkage to system table needed
	return 'fixed:'||foundschema::text;


	-- fix linking to system tables
	SELECT 0 INTO linked;
	FOR mislinked in
		SELECT gc.oid as gcrec,
			a.attrelid as attrelid, a.attnum as attnum
                FROM geometry_columns gc, pg_class c,

		pg_namespace n, pg_attribute a



                WHERE ( gc.attrelid IS NULL OR gc.attrelid != a.attrelid 
			OR gc.varattnum IS NULL OR gc.varattnum != a.attnum)

                AND n.nspname = gc.f_table_schema::name
                AND c.relnamespace = n.oid

                AND c.relname = gc.f_table_name::name
                AND a.attname = f_geometry_column::name
                AND a.attrelid = c.oid
	LOOP
		UPDATE geometry_columns SET
			attrelid = mislinked.attrelid,
			varattnum = mislinked.attnum,
			stats = NULL
			WHERE geometry_columns.oid = mislinked.gcrec;
		SELECT linked+1 INTO linked;
	END LOOP; 

	-- remove stale records
	DELETE FROM geometry_columns WHERE attrelid IS NULL;

	GET DIAGNOSTICS deleted = ROW_COUNT;

	result = 

		'fixed:' || foundschema::text ||

		' linked:' || linked::text || 
		' deleted:' || deleted::text;

	return result;

END;
$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fix_geometry_columns() OWNER TO postgres;

--
-- TOC entry 160 (class 1255 OID 7506360)
-- Dependencies: 930 930 3
-- Name: force_2d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION force_2d(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.force_2d(geometry) OWNER TO postgres;

--
-- TOC entry 161 (class 1255 OID 7506361)
-- Dependencies: 930 930 3
-- Name: force_3d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION force_3d(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_3dz'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.force_3d(geometry) OWNER TO postgres;

--
-- TOC entry 162 (class 1255 OID 7506362)
-- Dependencies: 930 3 930
-- Name: force_3dm(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION force_3dm(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_3dm'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.force_3dm(geometry) OWNER TO postgres;

--
-- TOC entry 163 (class 1255 OID 7506363)
-- Dependencies: 930 3 930
-- Name: force_3dz(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION force_3dz(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_3dz'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.force_3dz(geometry) OWNER TO postgres;

--
-- TOC entry 164 (class 1255 OID 7506364)
-- Dependencies: 930 3 930
-- Name: force_4d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION force_4d(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_4d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.force_4d(geometry) OWNER TO postgres;

--
-- TOC entry 165 (class 1255 OID 7506365)
-- Dependencies: 930 3 930
-- Name: force_collection(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION force_collection(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_collection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.force_collection(geometry) OWNER TO postgres;

--
-- TOC entry 166 (class 1255 OID 7506366)
-- Dependencies: 930 3 930
-- Name: forcerhr(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION forcerhr(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_forceRHR_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.forcerhr(geometry) OWNER TO postgres;

--
-- TOC entry 167 (class 1255 OID 7506367)
-- Dependencies: 933 3 933 930
-- Name: geom_accum(geometry[], geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geom_accum(geometry[], geometry) RETURNS geometry[]
    AS '$libdir/liblwgeom', 'LWGEOM_accum'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.geom_accum(geometry[], geometry) OWNER TO postgres;

--
-- TOC entry 168 (class 1255 OID 7506368)
-- Dependencies: 3 930
-- Name: geomcollfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geomcollfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromText($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomcollfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 169 (class 1255 OID 7506369)
-- Dependencies: 3 930
-- Name: geomcollfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geomcollfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromText($1)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomcollfromtext(text) OWNER TO postgres;

--
-- TOC entry 170 (class 1255 OID 7506370)
-- Dependencies: 3 930
-- Name: geomcollfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geomcollfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromWKB($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomcollfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 171 (class 1255 OID 7506371)
-- Dependencies: 3 930
-- Name: geomcollfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geomcollfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromWKB($1)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomcollfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 172 (class 1255 OID 7506372)
-- Dependencies: 930 3 1221
-- Name: geometry(box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry(box2d) RETURNS geometry
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_to_LWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry(box2d) OWNER TO postgres;

--
-- TOC entry 173 (class 1255 OID 7506373)
-- Dependencies: 930 3 1225
-- Name: geometry(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry(box3d) RETURNS geometry
    AS '$libdir/liblwgeom', 'BOX3D_to_LWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry(box3d) OWNER TO postgres;

--
-- TOC entry 174 (class 1255 OID 7506374)
-- Dependencies: 930 3
-- Name: geometry(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry(text) RETURNS geometry
    AS '$libdir/liblwgeom', 'parse_WKT_lwgeom'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry(text) OWNER TO postgres;

--
-- TOC entry 175 (class 1255 OID 7506375)
-- Dependencies: 3 930 1229
-- Name: geometry(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry(chip) RETURNS geometry
    AS '$libdir/liblwgeom', 'CHIP_to_LWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry(chip) OWNER TO postgres;

--
-- TOC entry 176 (class 1255 OID 7506376)
-- Dependencies: 930 3
-- Name: geometry(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry(bytea) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_bytea'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry(bytea) OWNER TO postgres;

--
-- TOC entry 177 (class 1255 OID 7506377)
-- Dependencies: 930 3 930
-- Name: geometry_above(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_above(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_above'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_above(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 178 (class 1255 OID 7506378)
-- Dependencies: 3
-- Name: geometry_analyze(internal); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_analyze(internal) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_analyze'
    LANGUAGE c STRICT;


ALTER FUNCTION public.geometry_analyze(internal) OWNER TO postgres;

--
-- TOC entry 179 (class 1255 OID 7506379)
-- Dependencies: 930 3 930
-- Name: geometry_below(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_below(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_below'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_below(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 180 (class 1255 OID 7506380)
-- Dependencies: 930 3 930
-- Name: geometry_cmp(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_cmp(geometry, geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'lwgeom_cmp'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_cmp(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 181 (class 1255 OID 7506381)
-- Dependencies: 930 3 930
-- Name: geometry_contain(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_contain(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_contain'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_contain(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 182 (class 1255 OID 7506382)
-- Dependencies: 930 3 930
-- Name: geometry_contained(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_contained(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_contained'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_contained(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 183 (class 1255 OID 7506383)
-- Dependencies: 930 3 930
-- Name: geometry_eq(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_eq(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_eq'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_eq(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 184 (class 1255 OID 7506384)
-- Dependencies: 930 3 930
-- Name: geometry_ge(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_ge(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_ge'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_ge(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 185 (class 1255 OID 7506385)
-- Dependencies: 930 3 930
-- Name: geometry_gt(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_gt(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_gt'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_gt(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 186 (class 1255 OID 7506386)
-- Dependencies: 3 930
-- Name: geometry_in(cstring); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_in(cstring) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_in(cstring) OWNER TO postgres;

--
-- TOC entry 187 (class 1255 OID 7506387)
-- Dependencies: 930 930 3
-- Name: geometry_le(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_le(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_le'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_le(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 188 (class 1255 OID 7506388)
-- Dependencies: 3 930 930
-- Name: geometry_left(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_left(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_left'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_left(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 189 (class 1255 OID 7506389)
-- Dependencies: 3 930 930
-- Name: geometry_lt(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_lt(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_lt'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_lt(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 190 (class 1255 OID 7506390)
-- Dependencies: 930 3
-- Name: geometry_out(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_out(geometry) RETURNS cstring
    AS '$libdir/liblwgeom', 'LWGEOM_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_out(geometry) OWNER TO postgres;

--
-- TOC entry 191 (class 1255 OID 7506391)
-- Dependencies: 930 3 930
-- Name: geometry_overabove(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_overabove(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overabove'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_overabove(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 192 (class 1255 OID 7506392)
-- Dependencies: 930 3 930
-- Name: geometry_overbelow(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_overbelow(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overbelow'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_overbelow(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 193 (class 1255 OID 7506393)
-- Dependencies: 930 3 930
-- Name: geometry_overlap(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_overlap(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overlap'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_overlap(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 194 (class 1255 OID 7506394)
-- Dependencies: 930 3 930
-- Name: geometry_overleft(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_overleft(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overleft'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_overleft(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 195 (class 1255 OID 7506395)
-- Dependencies: 930 3 930
-- Name: geometry_overright(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_overright(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overright'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_overright(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 196 (class 1255 OID 7506396)
-- Dependencies: 3 930
-- Name: geometry_recv(internal); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_recv(internal) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_recv'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_recv(internal) OWNER TO postgres;

--
-- TOC entry 197 (class 1255 OID 7506397)
-- Dependencies: 930 3 930
-- Name: geometry_right(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_right(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_right'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_right(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 198 (class 1255 OID 7506398)
-- Dependencies: 930 3 930
-- Name: geometry_same(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_same(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_same'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_same(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 199 (class 1255 OID 7506399)
-- Dependencies: 3 930
-- Name: geometry_send(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometry_send(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_send'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_send(geometry) OWNER TO postgres;

--
-- TOC entry 200 (class 1255 OID 7506400)
-- Dependencies: 3 930
-- Name: geometryfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometryfromtext(text) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometryfromtext(text) OWNER TO postgres;

--
-- TOC entry 201 (class 1255 OID 7506401)
-- Dependencies: 930 3
-- Name: geometryfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometryfromtext(text, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometryfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 202 (class 1255 OID 7506402)
-- Dependencies: 930 3 930
-- Name: geometryn(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geometryn(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_geometryn_collection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometryn(geometry, integer) OWNER TO postgres;

--
-- TOC entry 203 (class 1255 OID 7506403)
-- Dependencies: 3 930
-- Name: geomfromewkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geomfromewkb(bytea) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOMFromWKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geomfromewkb(bytea) OWNER TO postgres;

--
-- TOC entry 204 (class 1255 OID 7506404)
-- Dependencies: 930 3
-- Name: geomfromewkt(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geomfromewkt(text) RETURNS geometry
    AS '$libdir/liblwgeom', 'parse_WKT_lwgeom'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geomfromewkt(text) OWNER TO postgres;

--
-- TOC entry 205 (class 1255 OID 7506405)
-- Dependencies: 3 930
-- Name: geomfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geomfromtext(text) RETURNS geometry
    AS $_$SELECT geometryfromtext($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomfromtext(text) OWNER TO postgres;

--
-- TOC entry 206 (class 1255 OID 7506406)
-- Dependencies: 3 930
-- Name: geomfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geomfromtext(text, integer) RETURNS geometry
    AS $_$SELECT geometryfromtext($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 207 (class 1255 OID 7506407)
-- Dependencies: 3 930
-- Name: geomfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geomfromwkb(bytea) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_WKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geomfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 208 (class 1255 OID 7506408)
-- Dependencies: 3 930
-- Name: geomfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geomfromwkb(bytea, integer) RETURNS geometry
    AS $_$SELECT setSRID(GeomFromWKB($1), $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 209 (class 1255 OID 7506409)
-- Dependencies: 930 3 930 930
-- Name: geomunion(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geomunion(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'geomunion'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geomunion(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 210 (class 1255 OID 7506410)
-- Dependencies: 930 3 930
-- Name: geosnoop(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION geosnoop(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'GEOSnoop'
    LANGUAGE c STRICT;


ALTER FUNCTION public.geosnoop(geometry) OWNER TO postgres;

--
-- TOC entry 211 (class 1255 OID 7506411)
-- Dependencies: 1478 3
-- Name: get_proj4_from_srid(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION get_proj4_from_srid(integer) RETURNS text
    AS $_$
BEGIN
	RETURN proj4text::text FROM spatial_ref_sys WHERE srid= $1;
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.get_proj4_from_srid(integer) OWNER TO postgres;

--
-- TOC entry 212 (class 1255 OID 7506412)
-- Dependencies: 3 930 1221
-- Name: getbbox(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getbbox(geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX2DFLOAT4'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.getbbox(geometry) OWNER TO postgres;

--
-- TOC entry 213 (class 1255 OID 7506413)
-- Dependencies: 930 3
-- Name: getsrid(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getsrid(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_getSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.getsrid(geometry) OWNER TO postgres;

--
-- TOC entry 214 (class 1255 OID 7506414)
-- Dependencies: 3
-- Name: gettransactionid(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION gettransactionid() RETURNS xid
    AS '$libdir/liblwgeom', 'getTransactionID'
    LANGUAGE c;


ALTER FUNCTION public.gettransactionid() OWNER TO postgres;

--
-- TOC entry 215 (class 1255 OID 7506415)
-- Dependencies: 930 3
-- Name: hasbbox(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION hasbbox(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_hasBBOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.hasbbox(geometry) OWNER TO postgres;

--
-- TOC entry 216 (class 1255 OID 7506416)
-- Dependencies: 1229 3
-- Name: height(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION height(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getHeight'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.height(chip) OWNER TO postgres;

--
-- TOC entry 217 (class 1255 OID 7506417)
-- Dependencies: 1237 3
-- Name: histogram2d_in(cstring); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION histogram2d_in(cstring) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'lwhistogram2d_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.histogram2d_in(cstring) OWNER TO postgres;

--
-- TOC entry 218 (class 1255 OID 7506418)
-- Dependencies: 3 1237
-- Name: histogram2d_out(histogram2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION histogram2d_out(histogram2d) RETURNS cstring
    AS '$libdir/liblwgeom', 'lwhistogram2d_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.histogram2d_out(histogram2d) OWNER TO postgres;

--
-- TOC entry 219 (class 1255 OID 7506419)
-- Dependencies: 930 3 930
-- Name: interiorringn(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION interiorringn(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_interiorringn_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.interiorringn(geometry, integer) OWNER TO postgres;

--
-- TOC entry 220 (class 1255 OID 7506420)
-- Dependencies: 930 3 930 930
-- Name: intersection(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION intersection(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'intersection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.intersection(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 221 (class 1255 OID 7506421)
-- Dependencies: 930 3 930
-- Name: intersects(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION intersects(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'intersects'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.intersects(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 222 (class 1255 OID 7506422)
-- Dependencies: 3 930
-- Name: isclosed(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION isclosed(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_isclosed_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.isclosed(geometry) OWNER TO postgres;

--
-- TOC entry 223 (class 1255 OID 7506423)
-- Dependencies: 3 930
-- Name: isempty(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION isempty(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_isempty'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.isempty(geometry) OWNER TO postgres;

--
-- TOC entry 224 (class 1255 OID 7506424)
-- Dependencies: 3 930
-- Name: isring(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION isring(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'isring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.isring(geometry) OWNER TO postgres;

--
-- TOC entry 225 (class 1255 OID 7506425)
-- Dependencies: 3 930
-- Name: issimple(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION issimple(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'issimple'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.issimple(geometry) OWNER TO postgres;

--
-- TOC entry 226 (class 1255 OID 7506426)
-- Dependencies: 3 930
-- Name: isvalid(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION isvalid(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'isvalid'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.isvalid(geometry) OWNER TO postgres;

--
-- TOC entry 227 (class 1255 OID 7506427)
-- Dependencies: 930 3 930
-- Name: jtsnoop(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION jtsnoop(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'JTSnoop'
    LANGUAGE c STRICT;


ALTER FUNCTION public.jtsnoop(geometry) OWNER TO postgres;

--
-- TOC entry 228 (class 1255 OID 7506428)
-- Dependencies: 3 930
-- Name: length(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION length(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.length(geometry) OWNER TO postgres;

--
-- TOC entry 229 (class 1255 OID 7506429)
-- Dependencies: 3 930
-- Name: length2d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION length2d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length2d_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.length2d(geometry) OWNER TO postgres;

--
-- TOC entry 230 (class 1255 OID 7506430)
-- Dependencies: 930 3 1255
-- Name: length2d_spheroid(geometry, spheroid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION length2d_spheroid(geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length2d_ellipsoid_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.length2d_spheroid(geometry, spheroid) OWNER TO postgres;

--
-- TOC entry 231 (class 1255 OID 7506431)
-- Dependencies: 3 930
-- Name: length3d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION length3d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.length3d(geometry) OWNER TO postgres;

--
-- TOC entry 232 (class 1255 OID 7506432)
-- Dependencies: 3 930 1255
-- Name: length3d_spheroid(geometry, spheroid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION length3d_spheroid(geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_ellipsoid_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.length3d_spheroid(geometry, spheroid) OWNER TO postgres;

--
-- TOC entry 233 (class 1255 OID 7506433)
-- Dependencies: 1255 3 930
-- Name: length_spheroid(geometry, spheroid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION length_spheroid(geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_ellipsoid_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.length_spheroid(geometry, spheroid) OWNER TO postgres;

--
-- TOC entry 234 (class 1255 OID 7506434)
-- Dependencies: 930 3 930
-- Name: line_interpolate_point(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION line_interpolate_point(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_interpolate_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.line_interpolate_point(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 235 (class 1255 OID 7506435)
-- Dependencies: 930 3 930
-- Name: line_locate_point(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION line_locate_point(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_line_locate_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.line_locate_point(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 236 (class 1255 OID 7506436)
-- Dependencies: 930 3 930
-- Name: line_substring(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION line_substring(geometry, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_substring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.line_substring(geometry, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 237 (class 1255 OID 7506437)
-- Dependencies: 930 3 930
-- Name: linefrommultipoint(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION linefrommultipoint(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_from_mpoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.linefrommultipoint(geometry) OWNER TO postgres;

--
-- TOC entry 238 (class 1255 OID 7506438)
-- Dependencies: 3 930
-- Name: linefromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION linefromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'LINESTRING'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linefromtext(text) OWNER TO postgres;

--
-- TOC entry 239 (class 1255 OID 7506439)
-- Dependencies: 3 930
-- Name: linefromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION linefromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'LINESTRING'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linefromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 240 (class 1255 OID 7506440)
-- Dependencies: 3 930
-- Name: linefromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION linefromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'LINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linefromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 241 (class 1255 OID 7506441)
-- Dependencies: 3 930
-- Name: linefromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION linefromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'LINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linefromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 242 (class 1255 OID 7506442)
-- Dependencies: 930 3 930
-- Name: linemerge(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION linemerge(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'linemerge'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.linemerge(geometry) OWNER TO postgres;

--
-- TOC entry 243 (class 1255 OID 7506443)
-- Dependencies: 3 930
-- Name: linestringfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION linestringfromtext(text) RETURNS geometry
    AS $_$SELECT LineFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linestringfromtext(text) OWNER TO postgres;

--
-- TOC entry 244 (class 1255 OID 7506444)
-- Dependencies: 930 3
-- Name: linestringfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION linestringfromtext(text, integer) RETURNS geometry
    AS $_$SELECT LineFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linestringfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 245 (class 1255 OID 7506445)
-- Dependencies: 3 930
-- Name: linestringfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION linestringfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'LINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linestringfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 246 (class 1255 OID 7506446)
-- Dependencies: 3 930
-- Name: linestringfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION linestringfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'LINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linestringfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 247 (class 1255 OID 7506447)
-- Dependencies: 930 3 930
-- Name: locate_along_measure(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION locate_along_measure(geometry, double precision) RETURNS geometry
    AS $_$SELECT locate_between_measures($1, $2, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.locate_along_measure(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 248 (class 1255 OID 7506448)
-- Dependencies: 930 3 930
-- Name: locate_between_measures(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION locate_between_measures(geometry, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_locate_between_m'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.locate_between_measures(geometry, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 249 (class 1255 OID 7506449)
-- Dependencies: 1478 3
-- Name: lockrow(text, text, text, text, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION lockrow(text, text, text, text, timestamp without time zone) RETURNS integer
    AS $_$
DECLARE
	myschema alias for $1;
	mytable alias for $2;
	myrid   alias for $3;
	authid alias for $4;
	expires alias for $5;
	ret int;
	mytoid oid;
	myrec RECORD;
	
BEGIN

	IF NOT LongTransactionsEnabled() THEN
		RAISE EXCEPTION 'Long transaction support disabled, use EnableLongTransaction() to enable.';
	END IF;

	EXECUTE 'DELETE FROM authorization_table WHERE expires < now()'; 


	SELECT c.oid INTO mytoid FROM pg_class c, pg_namespace n
		WHERE c.relname = mytable
		AND c.relnamespace = n.oid
		AND n.nspname = myschema;





	-- RAISE NOTICE 'toid: %', mytoid;

	FOR myrec IN SELECT * FROM authorization_table WHERE 
		toid = mytoid AND rid = myrid
	LOOP
		IF myrec.authid != authid THEN
			RETURN 0;
		ELSE
			RETURN 1;
		END IF;
	END LOOP;

	EXECUTE 'INSERT INTO authorization_table VALUES ('||
		quote_literal(mytoid::text)||','||quote_literal(myrid)||
		','||quote_literal(expires::text)||
		','||quote_literal(authid) ||')';

	GET DIAGNOSTICS ret = ROW_COUNT;

	RETURN ret;
END;$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.lockrow(text, text, text, text, timestamp without time zone) OWNER TO postgres;

--
-- TOC entry 250 (class 1255 OID 7506450)
-- Dependencies: 3
-- Name: lockrow(text, text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION lockrow(text, text, text, text) RETURNS integer
    AS $_$SELECT LockRow($1, $2, $3, $4, now()::timestamp+'1:00');$_$
    LANGUAGE sql STRICT;


ALTER FUNCTION public.lockrow(text, text, text, text) OWNER TO postgres;

--
-- TOC entry 251 (class 1255 OID 7506451)
-- Dependencies: 3
-- Name: lockrow(text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION lockrow(text, text, text) RETURNS integer
    AS $_$SELECT LockRow(current_schema(), $1, $2, $3, now()::timestamp+'1:00');$_$
    LANGUAGE sql STRICT;


ALTER FUNCTION public.lockrow(text, text, text) OWNER TO postgres;

--
-- TOC entry 252 (class 1255 OID 7506452)
-- Dependencies: 3
-- Name: lockrow(text, text, text, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION lockrow(text, text, text, timestamp without time zone) RETURNS integer
    AS $_$SELECT LockRow(current_schema(), $1, $2, $3, $4);$_$
    LANGUAGE sql STRICT;


ALTER FUNCTION public.lockrow(text, text, text, timestamp without time zone) OWNER TO postgres;

--
-- TOC entry 253 (class 1255 OID 7506453)
-- Dependencies: 1478 3
-- Name: longtransactionsenabled(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION longtransactionsenabled() RETURNS boolean
    AS $$
DECLARE
	rec RECORD;
BEGIN
	FOR rec IN SELECT oid FROM pg_class WHERE relname = 'authorized_tables'
	LOOP
		return 't';
	END LOOP;
	return 'f';
END;
$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.longtransactionsenabled() OWNER TO postgres;

--
-- TOC entry 254 (class 1255 OID 7506454)
-- Dependencies: 3
-- Name: lwgeom_gist_compress(internal); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION lwgeom_gist_compress(internal) RETURNS internal
    AS '$libdir/liblwgeom', 'LWGEOM_gist_compress'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_compress(internal) OWNER TO postgres;

--
-- TOC entry 255 (class 1255 OID 7506455)
-- Dependencies: 930 3
-- Name: lwgeom_gist_consistent(internal, geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION lwgeom_gist_consistent(internal, geometry, integer) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_gist_consistent'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_consistent(internal, geometry, integer) OWNER TO postgres;

--
-- TOC entry 256 (class 1255 OID 7506456)
-- Dependencies: 3
-- Name: lwgeom_gist_decompress(internal); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION lwgeom_gist_decompress(internal) RETURNS internal
    AS '$libdir/liblwgeom', 'LWGEOM_gist_decompress'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_decompress(internal) OWNER TO postgres;

--
-- TOC entry 257 (class 1255 OID 7506457)
-- Dependencies: 3
-- Name: lwgeom_gist_penalty(internal, internal, internal); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION lwgeom_gist_penalty(internal, internal, internal) RETURNS internal
    AS '$libdir/liblwgeom', 'LWGEOM_gist_penalty'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_penalty(internal, internal, internal) OWNER TO postgres;

--
-- TOC entry 258 (class 1255 OID 7506458)
-- Dependencies: 3
-- Name: lwgeom_gist_picksplit(internal, internal); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION lwgeom_gist_picksplit(internal, internal) RETURNS internal
    AS '$libdir/liblwgeom', 'LWGEOM_gist_picksplit'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_picksplit(internal, internal) OWNER TO postgres;

--
-- TOC entry 259 (class 1255 OID 7506459)
-- Dependencies: 1221 3 1221
-- Name: lwgeom_gist_same(box2d, box2d, internal); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION lwgeom_gist_same(box2d, box2d, internal) RETURNS internal
    AS '$libdir/liblwgeom', 'LWGEOM_gist_same'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_same(box2d, box2d, internal) OWNER TO postgres;

--
-- TOC entry 260 (class 1255 OID 7506460)
-- Dependencies: 3
-- Name: lwgeom_gist_union(bytea, internal); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION lwgeom_gist_union(bytea, internal) RETURNS internal
    AS '$libdir/liblwgeom', 'LWGEOM_gist_union'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_union(bytea, internal) OWNER TO postgres;

--
-- TOC entry 261 (class 1255 OID 7506461)
-- Dependencies: 3 930
-- Name: m(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION m(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_m_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.m(geometry) OWNER TO postgres;

--
-- TOC entry 262 (class 1255 OID 7506462)
-- Dependencies: 930 3 1221 930
-- Name: makebox2d(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION makebox2d(geometry, geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_construct'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makebox2d(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 263 (class 1255 OID 7506463)
-- Dependencies: 930 3 1225 930
-- Name: makebox3d(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION makebox3d(geometry, geometry) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_construct'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makebox3d(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 264 (class 1255 OID 7506464)
-- Dependencies: 930 3 930 930
-- Name: makeline(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION makeline(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makeline'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makeline(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 265 (class 1255 OID 7506465)
-- Dependencies: 930 3 933
-- Name: makeline_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION makeline_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makeline_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makeline_garray(geometry[]) OWNER TO postgres;

--
-- TOC entry 266 (class 1255 OID 7506466)
-- Dependencies: 3 930
-- Name: makepoint(double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION makepoint(double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makepoint(double precision, double precision) OWNER TO postgres;

--
-- TOC entry 267 (class 1255 OID 7506467)
-- Dependencies: 3 930
-- Name: makepoint(double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION makepoint(double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makepoint(double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 268 (class 1255 OID 7506468)
-- Dependencies: 3 930
-- Name: makepoint(double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION makepoint(double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makepoint(double precision, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 269 (class 1255 OID 7506469)
-- Dependencies: 3 930
-- Name: makepointm(double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION makepointm(double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint3dm'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makepointm(double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 270 (class 1255 OID 7506470)
-- Dependencies: 930 3 930 933
-- Name: makepolygon(geometry, geometry[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION makepolygon(geometry, geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makepolygon(geometry, geometry[]) OWNER TO postgres;

--
-- TOC entry 271 (class 1255 OID 7506471)
-- Dependencies: 930 3 930
-- Name: makepolygon(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION makepolygon(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makepolygon(geometry) OWNER TO postgres;

--
-- TOC entry 272 (class 1255 OID 7506472)
-- Dependencies: 930 3 930
-- Name: max_distance(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION max_distance(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_maxdistance2d_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.max_distance(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 273 (class 1255 OID 7506473)
-- Dependencies: 3 930
-- Name: mem_size(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION mem_size(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_mem_size'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.mem_size(geometry) OWNER TO postgres;

--
-- TOC entry 274 (class 1255 OID 7506474)
-- Dependencies: 3 930
-- Name: mlinefromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION mlinefromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromText($1, $2)) = 'MULTILINESTRING'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mlinefromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 275 (class 1255 OID 7506475)
-- Dependencies: 3 930
-- Name: mlinefromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION mlinefromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'MULTILINESTRING'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mlinefromtext(text) OWNER TO postgres;

--
-- TOC entry 276 (class 1255 OID 7506476)
-- Dependencies: 3 930
-- Name: mlinefromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION mlinefromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mlinefromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 277 (class 1255 OID 7506477)
-- Dependencies: 3 930
-- Name: mlinefromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION mlinefromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mlinefromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 278 (class 1255 OID 7506478)
-- Dependencies: 3 930
-- Name: mpointfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION mpointfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1,$2)) = 'MULTIPOINT'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpointfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 279 (class 1255 OID 7506479)
-- Dependencies: 3 930
-- Name: mpointfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION mpointfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'MULTIPOINT'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpointfromtext(text) OWNER TO postgres;

--
-- TOC entry 280 (class 1255 OID 7506480)
-- Dependencies: 930 3
-- Name: mpointfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION mpointfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1,$2)) = 'MULTIPOINT'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpointfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 281 (class 1255 OID 7506481)
-- Dependencies: 3 930
-- Name: mpointfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION mpointfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOINT'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpointfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 282 (class 1255 OID 7506482)
-- Dependencies: 3 930
-- Name: mpolyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION mpolyfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'MULTIPOLYGON'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpolyfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 283 (class 1255 OID 7506483)
-- Dependencies: 3 930
-- Name: mpolyfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION mpolyfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'MULTIPOLYGON'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpolyfromtext(text) OWNER TO postgres;

--
-- TOC entry 284 (class 1255 OID 7506484)
-- Dependencies: 3 930
-- Name: mpolyfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION mpolyfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpolyfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 285 (class 1255 OID 7506485)
-- Dependencies: 3 930
-- Name: mpolyfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION mpolyfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpolyfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 286 (class 1255 OID 7506486)
-- Dependencies: 930 3 930
-- Name: multi(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION multi(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_multi'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.multi(geometry) OWNER TO postgres;

--
-- TOC entry 287 (class 1255 OID 7506487)
-- Dependencies: 3 930
-- Name: multilinefromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION multilinefromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multilinefromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 288 (class 1255 OID 7506488)
-- Dependencies: 3 930
-- Name: multilinefromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION multilinefromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multilinefromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 289 (class 1255 OID 7506489)
-- Dependencies: 3 930
-- Name: multilinestringfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION multilinestringfromtext(text) RETURNS geometry
    AS $_$SELECT MLineFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multilinestringfromtext(text) OWNER TO postgres;

--
-- TOC entry 290 (class 1255 OID 7506490)
-- Dependencies: 3 930
-- Name: multilinestringfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION multilinestringfromtext(text, integer) RETURNS geometry
    AS $_$SELECT MLineFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multilinestringfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 291 (class 1255 OID 7506491)
-- Dependencies: 3 930
-- Name: multipointfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION multipointfromtext(text, integer) RETURNS geometry
    AS $_$SELECT MPointFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipointfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 292 (class 1255 OID 7506492)
-- Dependencies: 3 930
-- Name: multipointfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION multipointfromtext(text) RETURNS geometry
    AS $_$SELECT MPointFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipointfromtext(text) OWNER TO postgres;

--
-- TOC entry 293 (class 1255 OID 7506493)
-- Dependencies: 930 3
-- Name: multipointfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION multipointfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1,$2)) = 'MULTIPOINT'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipointfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 294 (class 1255 OID 7506494)
-- Dependencies: 3 930
-- Name: multipointfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION multipointfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOINT'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipointfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 295 (class 1255 OID 7506495)
-- Dependencies: 3 930
-- Name: multipolyfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION multipolyfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipolyfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 296 (class 1255 OID 7506496)
-- Dependencies: 930 3
-- Name: multipolyfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION multipolyfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipolyfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 297 (class 1255 OID 7506497)
-- Dependencies: 3 930
-- Name: multipolygonfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION multipolygonfromtext(text, integer) RETURNS geometry
    AS $_$SELECT MPolyFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipolygonfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 298 (class 1255 OID 7506498)
-- Dependencies: 3 930
-- Name: multipolygonfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION multipolygonfromtext(text) RETURNS geometry
    AS $_$SELECT MPolyFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipolygonfromtext(text) OWNER TO postgres;

--
-- TOC entry 299 (class 1255 OID 7506499)
-- Dependencies: 930 3 930
-- Name: noop(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION noop(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_noop'
    LANGUAGE c STRICT;


ALTER FUNCTION public.noop(geometry) OWNER TO postgres;

--
-- TOC entry 300 (class 1255 OID 7506500)
-- Dependencies: 3 930
-- Name: npoints(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION npoints(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_npoints'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.npoints(geometry) OWNER TO postgres;

--
-- TOC entry 301 (class 1255 OID 7506501)
-- Dependencies: 3 930
-- Name: nrings(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION nrings(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_nrings'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.nrings(geometry) OWNER TO postgres;

--
-- TOC entry 302 (class 1255 OID 7506502)
-- Dependencies: 3 930
-- Name: numgeometries(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION numgeometries(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numgeometries_collection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.numgeometries(geometry) OWNER TO postgres;

--
-- TOC entry 303 (class 1255 OID 7506503)
-- Dependencies: 3 930
-- Name: numinteriorring(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION numinteriorring(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numinteriorrings_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.numinteriorring(geometry) OWNER TO postgres;

--
-- TOC entry 304 (class 1255 OID 7506504)
-- Dependencies: 3 930
-- Name: numinteriorrings(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION numinteriorrings(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numinteriorrings_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.numinteriorrings(geometry) OWNER TO postgres;

--
-- TOC entry 305 (class 1255 OID 7506505)
-- Dependencies: 3 930
-- Name: numpoints(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION numpoints(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numpoints_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.numpoints(geometry) OWNER TO postgres;

--
-- TOC entry 306 (class 1255 OID 7506506)
-- Dependencies: 930 3 930
-- Name: overlaps(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "overlaps"(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'overlaps'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public."overlaps"(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 307 (class 1255 OID 7506507)
-- Dependencies: 3 930
-- Name: perimeter(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION perimeter(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_perimeter_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.perimeter(geometry) OWNER TO postgres;

--
-- TOC entry 308 (class 1255 OID 7506508)
-- Dependencies: 3 930
-- Name: perimeter2d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION perimeter2d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_perimeter2d_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.perimeter2d(geometry) OWNER TO postgres;

--
-- TOC entry 309 (class 1255 OID 7506509)
-- Dependencies: 3 930
-- Name: perimeter3d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION perimeter3d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_perimeter_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.perimeter3d(geometry) OWNER TO postgres;

--
-- TOC entry 310 (class 1255 OID 7506510)
-- Dependencies: 3 930
-- Name: point_inside_circle(geometry, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION point_inside_circle(geometry, double precision, double precision, double precision) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_inside_circle_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.point_inside_circle(geometry, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 311 (class 1255 OID 7506511)
-- Dependencies: 3 930
-- Name: pointfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pointfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'POINT'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.pointfromtext(text) OWNER TO postgres;

--
-- TOC entry 312 (class 1255 OID 7506512)
-- Dependencies: 3 930
-- Name: pointfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pointfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'POINT'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.pointfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 313 (class 1255 OID 7506513)
-- Dependencies: 930 3
-- Name: pointfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pointfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'POINT'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.pointfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 314 (class 1255 OID 7506514)
-- Dependencies: 3 930
-- Name: pointfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pointfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'POINT'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.pointfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 315 (class 1255 OID 7506515)
-- Dependencies: 930 3 930
-- Name: pointn(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pointn(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_pointn_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.pointn(geometry, integer) OWNER TO postgres;

--
-- TOC entry 316 (class 1255 OID 7506516)
-- Dependencies: 930 3 930
-- Name: pointonsurface(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pointonsurface(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'pointonsurface'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.pointonsurface(geometry) OWNER TO postgres;

--
-- TOC entry 317 (class 1255 OID 7506517)
-- Dependencies: 3 930
-- Name: polyfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION polyfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'POLYGON'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polyfromtext(text) OWNER TO postgres;

--
-- TOC entry 318 (class 1255 OID 7506518)
-- Dependencies: 3 930
-- Name: polyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION polyfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'POLYGON'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polyfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 319 (class 1255 OID 7506519)
-- Dependencies: 3 930
-- Name: polyfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION polyfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'POLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polyfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 320 (class 1255 OID 7506520)
-- Dependencies: 930 3
-- Name: polyfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION polyfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'POLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polyfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 321 (class 1255 OID 7506521)
-- Dependencies: 3 930
-- Name: polygonfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION polygonfromtext(text, integer) RETURNS geometry
    AS $_$SELECT PolyFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polygonfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 322 (class 1255 OID 7506522)
-- Dependencies: 3 930
-- Name: polygonfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION polygonfromtext(text) RETURNS geometry
    AS $_$SELECT PolyFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polygonfromtext(text) OWNER TO postgres;

--
-- TOC entry 323 (class 1255 OID 7506523)
-- Dependencies: 930 3
-- Name: polygonfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION polygonfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1,$2)) = 'POLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polygonfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 324 (class 1255 OID 7506524)
-- Dependencies: 3 930
-- Name: polygonfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION polygonfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'POLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polygonfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 325 (class 1255 OID 7506525)
-- Dependencies: 3 933 930
-- Name: polygonize_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION polygonize_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'polygonize_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.polygonize_garray(geometry[]) OWNER TO postgres;

--
-- TOC entry 326 (class 1255 OID 7506526)
-- Dependencies: 3 1478
-- Name: postgis_full_version(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION postgis_full_version() RETURNS text
    AS $$
DECLARE
	libver text;
	projver text;
	geosver text;
	jtsver text;
	usestats bool;
	dbproc text;
	relproc text;
	fullver text;
BEGIN
	SELECT postgis_lib_version() INTO libver;
	SELECT postgis_proj_version() INTO projver;
	SELECT postgis_geos_version() INTO geosver;
	SELECT postgis_jts_version() INTO jtsver;
	SELECT postgis_uses_stats() INTO usestats;
	SELECT postgis_scripts_installed() INTO dbproc;
	SELECT postgis_scripts_released() INTO relproc;

	fullver = 'POSTGIS="' || libver || '"';

	IF  geosver IS NOT NULL THEN
		fullver = fullver || ' GEOS="' || geosver || '"';
	END IF;

	IF  jtsver IS NOT NULL THEN
		fullver = fullver || ' JTS="' || jtsver || '"';
	END IF;

	IF  projver IS NOT NULL THEN
		fullver = fullver || ' PROJ="' || projver || '"';
	END IF;

	IF usestats THEN
		fullver = fullver || ' USE_STATS';
	END IF;

	-- fullver = fullver || ' DBPROC="' || dbproc || '"';
	-- fullver = fullver || ' RELPROC="' || relproc || '"';

	IF dbproc != relproc THEN
		fullver = fullver || ' (procs from ' || dbproc || ' need upgrade)';
	END IF;

	RETURN fullver;
END
$$
    LANGUAGE plpgsql IMMUTABLE;


ALTER FUNCTION public.postgis_full_version() OWNER TO postgres;

--
-- TOC entry 327 (class 1255 OID 7506527)
-- Dependencies: 3
-- Name: postgis_geos_version(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION postgis_geos_version() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_geos_version'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_geos_version() OWNER TO postgres;

--
-- TOC entry 328 (class 1255 OID 7506528)
-- Dependencies: 3
-- Name: postgis_gist_joinsel(internal, oid, internal, smallint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION postgis_gist_joinsel(internal, oid, internal, smallint) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_gist_joinsel'
    LANGUAGE c;


ALTER FUNCTION public.postgis_gist_joinsel(internal, oid, internal, smallint) OWNER TO postgres;

--
-- TOC entry 329 (class 1255 OID 7506529)
-- Dependencies: 3
-- Name: postgis_gist_sel(internal, oid, internal, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION postgis_gist_sel(internal, oid, internal, integer) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_gist_sel'
    LANGUAGE c;


ALTER FUNCTION public.postgis_gist_sel(internal, oid, internal, integer) OWNER TO postgres;

--
-- TOC entry 330 (class 1255 OID 7506530)
-- Dependencies: 3
-- Name: postgis_jts_version(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION postgis_jts_version() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_jts_version'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_jts_version() OWNER TO postgres;

--
-- TOC entry 331 (class 1255 OID 7506531)
-- Dependencies: 3
-- Name: postgis_lib_build_date(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION postgis_lib_build_date() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_lib_build_date'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_lib_build_date() OWNER TO postgres;

--
-- TOC entry 332 (class 1255 OID 7506532)
-- Dependencies: 3
-- Name: postgis_lib_version(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION postgis_lib_version() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_lib_version'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_lib_version() OWNER TO postgres;

--
-- TOC entry 333 (class 1255 OID 7506533)
-- Dependencies: 3
-- Name: postgis_proj_version(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION postgis_proj_version() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_proj_version'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_proj_version() OWNER TO postgres;

--
-- TOC entry 334 (class 1255 OID 7506534)
-- Dependencies: 3
-- Name: postgis_scripts_build_date(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION postgis_scripts_build_date() RETURNS text
    AS $$SELECT '2008-12-16 16:35:20'::text AS version$$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.postgis_scripts_build_date() OWNER TO postgres;

--
-- TOC entry 335 (class 1255 OID 7506535)
-- Dependencies: 3
-- Name: postgis_scripts_installed(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION postgis_scripts_installed() RETURNS text
    AS $$SELECT '1.3.5'::text AS version$$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.postgis_scripts_installed() OWNER TO postgres;

--
-- TOC entry 336 (class 1255 OID 7506536)
-- Dependencies: 3
-- Name: postgis_scripts_released(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION postgis_scripts_released() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_scripts_released'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_scripts_released() OWNER TO postgres;

--
-- TOC entry 337 (class 1255 OID 7506537)
-- Dependencies: 3
-- Name: postgis_uses_stats(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION postgis_uses_stats() RETURNS boolean
    AS '$libdir/liblwgeom', 'postgis_uses_stats'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_uses_stats() OWNER TO postgres;

--
-- TOC entry 338 (class 1255 OID 7506538)
-- Dependencies: 3
-- Name: postgis_version(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION postgis_version() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_version'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_version() OWNER TO postgres;

--
-- TOC entry 339 (class 1255 OID 7506539)
-- Dependencies: 1478 3
-- Name: probe_geometry_columns(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION probe_geometry_columns() RETURNS text
    AS $$
DECLARE
	inserted integer;
	oldcount integer;
	probed integer;
	stale integer;
BEGIN

	SELECT count(*) INTO oldcount FROM geometry_columns;

	SELECT count(*) INTO probed
		FROM pg_class c, pg_attribute a, pg_type t, 

			pg_namespace n,
			pg_constraint sridcheck, pg_constraint typecheck




		WHERE t.typname = 'geometry'
		AND a.atttypid = t.oid
		AND a.attrelid = c.oid

		AND c.relnamespace = n.oid
		AND sridcheck.connamespace = n.oid
		AND typecheck.connamespace = n.oid



		AND sridcheck.conrelid = c.oid
		AND sridcheck.consrc LIKE '(srid('||a.attname||') = %)'
		AND typecheck.conrelid = c.oid
		AND typecheck.consrc LIKE
	'((geometrytype('||a.attname||') = ''%''::text) OR (% IS NULL))'







		;

	INSERT INTO geometry_columns SELECT
		''::varchar as f_table_catalogue,

		n.nspname::varchar as f_table_schema,



		c.relname::varchar as f_table_name,
		a.attname::varchar as f_geometry_column,
		2 as coord_dimension,

		trim(both  ' =)' from substr(sridcheck.consrc,
			strpos(sridcheck.consrc, '=')))::integer as srid,
		trim(both ' =)''' from substr(typecheck.consrc, 
			strpos(typecheck.consrc, '='),
			strpos(typecheck.consrc, '::')-
			strpos(typecheck.consrc, '=')
			))::varchar as type






		FROM pg_class c, pg_attribute a, pg_type t, 

			pg_namespace n,
			pg_constraint sridcheck, pg_constraint typecheck



		WHERE t.typname = 'geometry'
		AND a.atttypid = t.oid
		AND a.attrelid = c.oid

		AND c.relnamespace = n.oid
		AND sridcheck.connamespace = n.oid
		AND typecheck.connamespace = n.oid
		AND sridcheck.conrelid = c.oid
		AND sridcheck.consrc LIKE '(srid('||a.attname||') = %)'
		AND typecheck.conrelid = c.oid
		AND typecheck.consrc LIKE
	'((geometrytype('||a.attname||') = ''%''::text) OR (% IS NULL))'








                AND NOT EXISTS (
                        SELECT oid FROM geometry_columns gc
                        WHERE c.relname::varchar = gc.f_table_name

                        AND n.nspname::varchar = gc.f_table_schema

                        AND a.attname::varchar = gc.f_geometry_column
                );

	GET DIAGNOSTICS inserted = ROW_COUNT;

	IF oldcount > probed THEN
		stale = oldcount-probed;
	ELSE
		stale = 0;
	END IF;

        RETURN 'probed:'||probed::text||
		' inserted:'||inserted::text||
		' conflicts:'||(probed-inserted)::text||
		' stale:'||stale::text;
END

$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.probe_geometry_columns() OWNER TO postgres;

--
-- TOC entry 340 (class 1255 OID 7506540)
-- Dependencies: 3 930 930
-- Name: relate(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION relate(geometry, geometry) RETURNS text
    AS '$libdir/liblwgeom', 'relate_full'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.relate(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 341 (class 1255 OID 7506541)
-- Dependencies: 930 3 930
-- Name: relate(geometry, geometry, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION relate(geometry, geometry, text) RETURNS boolean
    AS '$libdir/liblwgeom', 'relate_pattern'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.relate(geometry, geometry, text) OWNER TO postgres;

--
-- TOC entry 342 (class 1255 OID 7506542)
-- Dependencies: 930 3 930
-- Name: removepoint(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION removepoint(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_removepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.removepoint(geometry, integer) OWNER TO postgres;

--
-- TOC entry 343 (class 1255 OID 7506543)
-- Dependencies: 3
-- Name: rename_geometry_table_constraints(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION rename_geometry_table_constraints() RETURNS text
    AS $$
SELECT 'rename_geometry_table_constraint() is obsoleted'::text
$$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.rename_geometry_table_constraints() OWNER TO postgres;

--
-- TOC entry 344 (class 1255 OID 7506544)
-- Dependencies: 3 930 930
-- Name: reverse(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION reverse(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_reverse'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.reverse(geometry) OWNER TO postgres;

--
-- TOC entry 345 (class 1255 OID 7506545)
-- Dependencies: 3 930 930
-- Name: rotate(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION rotate(geometry, double precision) RETURNS geometry
    AS $_$SELECT rotateZ($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.rotate(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 346 (class 1255 OID 7506546)
-- Dependencies: 930 930 3
-- Name: rotatex(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION rotatex(geometry, double precision) RETURNS geometry
    AS $_$SELECT affine($1, 1, 0, 0, 0, cos($2), -sin($2), 0, sin($2), cos($2), 0, 0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.rotatex(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 347 (class 1255 OID 7506547)
-- Dependencies: 930 3 930
-- Name: rotatey(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION rotatey(geometry, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  cos($2), 0, sin($2),  0, 1, 0,  -sin($2), 0, cos($2), 0,  0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.rotatey(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 348 (class 1255 OID 7506548)
-- Dependencies: 930 3 930
-- Name: rotatez(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION rotatez(geometry, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  cos($2), -sin($2), 0,  sin($2), cos($2), 0,  0, 0, 1,  0, 0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.rotatez(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 349 (class 1255 OID 7506549)
-- Dependencies: 930 930 3
-- Name: scale(geometry, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION scale(geometry, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  $2, 0, 0,  0, $3, 0,  0, 0, $4,  0, 0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.scale(geometry, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 350 (class 1255 OID 7506550)
-- Dependencies: 930 3 930
-- Name: scale(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION scale(geometry, double precision, double precision) RETURNS geometry
    AS $_$SELECT scale($1, $2, $3, 1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.scale(geometry, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 351 (class 1255 OID 7506551)
-- Dependencies: 930 3 930
-- Name: se_envelopesintersect(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION se_envelopesintersect(geometry, geometry) RETURNS boolean
    AS $_$
	SELECT $1 && $2
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.se_envelopesintersect(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 352 (class 1255 OID 7506552)
-- Dependencies: 930 3
-- Name: se_is3d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION se_is3d(geometry) RETURNS boolean
    AS $_$
    SELECT CASE ST_zmflag($1)
               WHEN 0 THEN false
               WHEN 1 THEN false
               WHEN 2 THEN true
               WHEN 3 THEN true
               ELSE false
           END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.se_is3d(geometry) OWNER TO postgres;

--
-- TOC entry 353 (class 1255 OID 7506553)
-- Dependencies: 3 930
-- Name: se_ismeasured(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION se_ismeasured(geometry) RETURNS boolean
    AS $_$
    SELECT CASE ST_zmflag($1)
               WHEN 0 THEN false
               WHEN 1 THEN true
               WHEN 2 THEN false
               WHEN 3 THEN true
               ELSE false
           END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.se_ismeasured(geometry) OWNER TO postgres;

--
-- TOC entry 354 (class 1255 OID 7506554)
-- Dependencies: 930 3 930
-- Name: se_locatealong(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION se_locatealong(geometry, double precision) RETURNS geometry
    AS $_$SELECT locate_between_measures($1, $2, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.se_locatealong(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 355 (class 1255 OID 7506555)
-- Dependencies: 930 3 930
-- Name: se_locatebetween(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION se_locatebetween(geometry, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_locate_between_m'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.se_locatebetween(geometry, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 356 (class 1255 OID 7506556)
-- Dependencies: 3 930
-- Name: se_m(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION se_m(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_m_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.se_m(geometry) OWNER TO postgres;

--
-- TOC entry 357 (class 1255 OID 7506557)
-- Dependencies: 3 930
-- Name: se_z(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION se_z(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_z_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.se_z(geometry) OWNER TO postgres;

--
-- TOC entry 358 (class 1255 OID 7506558)
-- Dependencies: 930 930 3
-- Name: segmentize(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION segmentize(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_segmentize2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.segmentize(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 359 (class 1255 OID 7506559)
-- Dependencies: 1229 1229 3
-- Name: setfactor(chip, real); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION setfactor(chip, real) RETURNS chip
    AS '$libdir/liblwgeom', 'CHIP_setFactor'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.setfactor(chip, real) OWNER TO postgres;

--
-- TOC entry 360 (class 1255 OID 7506560)
-- Dependencies: 930 930 3 930
-- Name: setpoint(geometry, integer, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION setpoint(geometry, integer, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_setpoint_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.setpoint(geometry, integer, geometry) OWNER TO postgres;

--
-- TOC entry 361 (class 1255 OID 7506561)
-- Dependencies: 1229 1229 3
-- Name: setsrid(chip, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION setsrid(chip, integer) RETURNS chip
    AS '$libdir/liblwgeom', 'CHIP_setSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.setsrid(chip, integer) OWNER TO postgres;

--
-- TOC entry 362 (class 1255 OID 7506562)
-- Dependencies: 3 930 930
-- Name: setsrid(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION setsrid(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_setSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.setsrid(geometry, integer) OWNER TO postgres;

--
-- TOC entry 363 (class 1255 OID 7506563)
-- Dependencies: 3 930 930
-- Name: shift_longitude(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION shift_longitude(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_longitude_shift'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.shift_longitude(geometry) OWNER TO postgres;

--
-- TOC entry 364 (class 1255 OID 7506564)
-- Dependencies: 3 930 930
-- Name: simplify(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION simplify(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_simplify2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.simplify(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 365 (class 1255 OID 7506565)
-- Dependencies: 930 930 3
-- Name: snaptogrid(geometry, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION snaptogrid(geometry, double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_snaptogrid'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.snaptogrid(geometry, double precision, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 366 (class 1255 OID 7506566)
-- Dependencies: 930 3 930
-- Name: snaptogrid(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION snaptogrid(geometry, double precision, double precision) RETURNS geometry
    AS $_$SELECT SnapToGrid($1, 0, 0, $2, $3)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.snaptogrid(geometry, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 367 (class 1255 OID 7506567)
-- Dependencies: 930 930 3
-- Name: snaptogrid(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION snaptogrid(geometry, double precision) RETURNS geometry
    AS $_$SELECT SnapToGrid($1, 0, 0, $2, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.snaptogrid(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 368 (class 1255 OID 7506568)
-- Dependencies: 930 3 930 930
-- Name: snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_snaptogrid_pointoff'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 369 (class 1255 OID 7506569)
-- Dependencies: 3 1255
-- Name: spheroid_in(cstring); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION spheroid_in(cstring) RETURNS spheroid
    AS '$libdir/liblwgeom', 'ellipsoid_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.spheroid_in(cstring) OWNER TO postgres;

--
-- TOC entry 370 (class 1255 OID 7506570)
-- Dependencies: 1255 3
-- Name: spheroid_out(spheroid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION spheroid_out(spheroid) RETURNS cstring
    AS '$libdir/liblwgeom', 'ellipsoid_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.spheroid_out(spheroid) OWNER TO postgres;

--
-- TOC entry 371 (class 1255 OID 7506571)
-- Dependencies: 3 1229
-- Name: srid(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION srid(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.srid(chip) OWNER TO postgres;

--
-- TOC entry 372 (class 1255 OID 7506572)
-- Dependencies: 930 930 3
-- Name: st_addbbox(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_addbbox(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_addBBOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_addbbox(geometry) OWNER TO postgres;

--
-- TOC entry 373 (class 1255 OID 7506573)
-- Dependencies: 930 930 3 930
-- Name: st_addpoint(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_addpoint(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_addpoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_addpoint(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 374 (class 1255 OID 7506574)
-- Dependencies: 930 930 3 930
-- Name: st_addpoint(geometry, geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_addpoint(geometry, geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_addpoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_addpoint(geometry, geometry, integer) OWNER TO postgres;

--
-- TOC entry 375 (class 1255 OID 7506575)
-- Dependencies: 930 930 3
-- Name: st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_affine'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 376 (class 1255 OID 7506576)
-- Dependencies: 930 930 3
-- Name: st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  $2, $3, 0,  $4, $5, 0,  0, 0, 1,  $6, $7, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 377 (class 1255 OID 7506577)
-- Dependencies: 930 3
-- Name: st_area(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_area(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_area_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_area(geometry) OWNER TO postgres;

--
-- TOC entry 378 (class 1255 OID 7506578)
-- Dependencies: 930 3
-- Name: st_area2d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_area2d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_area_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_area2d(geometry) OWNER TO postgres;

--
-- TOC entry 379 (class 1255 OID 7506579)
-- Dependencies: 3 930
-- Name: st_asbinary(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asbinary(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_asBinary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_asbinary(geometry) OWNER TO postgres;

--
-- TOC entry 380 (class 1255 OID 7506580)
-- Dependencies: 3 930
-- Name: st_asbinary(geometry, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asbinary(geometry, text) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_asBinary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_asbinary(geometry, text) OWNER TO postgres;

--
-- TOC entry 381 (class 1255 OID 7506581)
-- Dependencies: 3 930
-- Name: st_asewkb(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asewkb(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'WKBFromLWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_asewkb(geometry) OWNER TO postgres;

--
-- TOC entry 382 (class 1255 OID 7506582)
-- Dependencies: 3 930
-- Name: st_asewkb(geometry, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asewkb(geometry, text) RETURNS bytea
    AS '$libdir/liblwgeom', 'WKBFromLWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_asewkb(geometry, text) OWNER TO postgres;

--
-- TOC entry 383 (class 1255 OID 7506583)
-- Dependencies: 3 930
-- Name: st_asewkt(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asewkt(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asEWKT'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_asewkt(geometry) OWNER TO postgres;

--
-- TOC entry 384 (class 1255 OID 7506584)
-- Dependencies: 930 3
-- Name: st_asgeojson(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asgeojson(geometry, integer) RETURNS text
    AS $_$SELECT _ST_AsGeoJson(1, $1, $2, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgeojson(geometry, integer) OWNER TO postgres;

--
-- TOC entry 385 (class 1255 OID 7506585)
-- Dependencies: 930 3
-- Name: st_asgeojson(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asgeojson(geometry) RETURNS text
    AS $_$SELECT _ST_AsGeoJson(1, $1, 15, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgeojson(geometry) OWNER TO postgres;

--
-- TOC entry 386 (class 1255 OID 7506586)
-- Dependencies: 930 3
-- Name: st_asgeojson(integer, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asgeojson(integer, geometry) RETURNS text
    AS $_$SELECT _ST_AsGeoJson($1, $2, 15, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgeojson(integer, geometry) OWNER TO postgres;

--
-- TOC entry 387 (class 1255 OID 7506587)
-- Dependencies: 930 3
-- Name: st_asgeojson(integer, geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asgeojson(integer, geometry, integer) RETURNS text
    AS $_$SELECT _ST_AsGeoJson($1, $2, $3, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgeojson(integer, geometry, integer) OWNER TO postgres;

--
-- TOC entry 388 (class 1255 OID 7506588)
-- Dependencies: 3 930
-- Name: st_asgeojson(geometry, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asgeojson(geometry, integer, integer) RETURNS text
    AS $_$SELECT _ST_AsGeoJson(1, $1, $2, $3)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgeojson(geometry, integer, integer) OWNER TO postgres;

--
-- TOC entry 389 (class 1255 OID 7506589)
-- Dependencies: 930 3
-- Name: st_asgeojson(integer, geometry, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asgeojson(integer, geometry, integer, integer) RETURNS text
    AS $_$SELECT _ST_AsGeoJson($1, $2, $3, $4)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgeojson(integer, geometry, integer, integer) OWNER TO postgres;

--
-- TOC entry 390 (class 1255 OID 7506590)
-- Dependencies: 3 930
-- Name: st_asgml(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asgml(geometry, integer) RETURNS text
    AS $_$SELECT _ST_AsGML(2, $1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgml(geometry, integer) OWNER TO postgres;

--
-- TOC entry 391 (class 1255 OID 7506591)
-- Dependencies: 3 930
-- Name: st_asgml(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asgml(geometry) RETURNS text
    AS $_$SELECT _ST_AsGML(2, $1, 15)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgml(geometry) OWNER TO postgres;

--
-- TOC entry 392 (class 1255 OID 7506592)
-- Dependencies: 3 930
-- Name: st_asgml(integer, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asgml(integer, geometry) RETURNS text
    AS $_$SELECT _ST_AsGML($1, $2, 15)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgml(integer, geometry) OWNER TO postgres;

--
-- TOC entry 393 (class 1255 OID 7506593)
-- Dependencies: 3 930
-- Name: st_asgml(integer, geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_asgml(integer, geometry, integer) RETURNS text
    AS $_$SELECT _ST_AsGML($1, $2, $3)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgml(integer, geometry, integer) OWNER TO postgres;

--
-- TOC entry 394 (class 1255 OID 7506594)
-- Dependencies: 930 3
-- Name: st_ashexewkb(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_ashexewkb(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asHEXEWKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_ashexewkb(geometry) OWNER TO postgres;

--
-- TOC entry 395 (class 1255 OID 7506595)
-- Dependencies: 3 930
-- Name: st_ashexewkb(geometry, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_ashexewkb(geometry, text) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asHEXEWKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_ashexewkb(geometry, text) OWNER TO postgres;

--
-- TOC entry 396 (class 1255 OID 7506596)
-- Dependencies: 930 3
-- Name: st_askml(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_askml(geometry, integer) RETURNS text
    AS $_$SELECT _ST_AsKML(2, ST_Transform($1,4326), $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_askml(geometry, integer) OWNER TO postgres;

--
-- TOC entry 397 (class 1255 OID 7506597)
-- Dependencies: 3 930
-- Name: st_askml(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_askml(geometry) RETURNS text
    AS $_$SELECT _ST_AsKML(2, ST_Transform($1,4326), 15)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_askml(geometry) OWNER TO postgres;

--
-- TOC entry 398 (class 1255 OID 7506598)
-- Dependencies: 3 930
-- Name: st_askml(integer, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_askml(integer, geometry) RETURNS text
    AS $_$SELECT _ST_AsKML($1, ST_Transform($2,4326), 15)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_askml(integer, geometry) OWNER TO postgres;

--
-- TOC entry 399 (class 1255 OID 7506599)
-- Dependencies: 3 930
-- Name: st_askml(integer, geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_askml(integer, geometry, integer) RETURNS text
    AS $_$SELECT _ST_AsKML($1, ST_Transform($2,4326), $3)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_askml(integer, geometry, integer) OWNER TO postgres;

--
-- TOC entry 400 (class 1255 OID 7506600)
-- Dependencies: 930 3
-- Name: st_assvg(geometry, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_assvg(geometry, integer, integer) RETURNS text
    AS '$libdir/liblwgeom', 'assvg_geometry'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_assvg(geometry, integer, integer) OWNER TO postgres;

--
-- TOC entry 401 (class 1255 OID 7506601)
-- Dependencies: 930 3
-- Name: st_assvg(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_assvg(geometry, integer) RETURNS text
    AS '$libdir/liblwgeom', 'assvg_geometry'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_assvg(geometry, integer) OWNER TO postgres;

--
-- TOC entry 402 (class 1255 OID 7506602)
-- Dependencies: 930 3
-- Name: st_assvg(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_assvg(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'assvg_geometry'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_assvg(geometry) OWNER TO postgres;

--
-- TOC entry 403 (class 1255 OID 7506603)
-- Dependencies: 3 930
-- Name: st_astext(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_astext(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asText'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_astext(geometry) OWNER TO postgres;

--
-- TOC entry 404 (class 1255 OID 7506604)
-- Dependencies: 930 3 930
-- Name: st_azimuth(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_azimuth(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_azimuth'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_azimuth(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 405 (class 1255 OID 7506605)
-- Dependencies: 930 3 1478
-- Name: st_bdmpolyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_bdmpolyfromtext(text, integer) RETURNS geometry
    AS $_$
DECLARE
	geomtext alias for $1;
	srid alias for $2;
	mline geometry;
	geom geometry;
BEGIN
	mline := MultiLineStringFromText(geomtext, srid);

	IF mline IS NULL
	THEN
		RAISE EXCEPTION 'Input is not a MultiLinestring';
	END IF;

	geom := multi(BuildArea(mline));

	RETURN geom;
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.st_bdmpolyfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 406 (class 1255 OID 7506606)
-- Dependencies: 1478 930 3
-- Name: st_bdpolyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_bdpolyfromtext(text, integer) RETURNS geometry
    AS $_$
DECLARE
	geomtext alias for $1;
	srid alias for $2;
	mline geometry;
	geom geometry;
BEGIN
	mline := MultiLineStringFromText(geomtext, srid);

	IF mline IS NULL
	THEN
		RAISE EXCEPTION 'Input is not a MultiLinestring';
	END IF;

	geom := BuildArea(mline);

	IF GeometryType(geom) != 'POLYGON'
	THEN
		RAISE EXCEPTION 'Input returns more then a single polygon, try using BdMPolyFromText instead';
	END IF;

	RETURN geom;
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.st_bdpolyfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 407 (class 1255 OID 7506607)
-- Dependencies: 930 930 3
-- Name: st_boundary(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_boundary(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'boundary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_boundary(geometry) OWNER TO postgres;

--
-- TOC entry 408 (class 1255 OID 7506608)
-- Dependencies: 3 930
-- Name: st_box(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box(geometry) RETURNS box
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box(geometry) OWNER TO postgres;

--
-- TOC entry 409 (class 1255 OID 7506609)
-- Dependencies: 1225 3
-- Name: st_box(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box(box3d) RETURNS box
    AS '$libdir/liblwgeom', 'BOX3D_to_BOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box(box3d) OWNER TO postgres;

--
-- TOC entry 410 (class 1255 OID 7506610)
-- Dependencies: 3 930 1221
-- Name: st_box2d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box2d(geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX2DFLOAT4'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d(geometry) OWNER TO postgres;

--
-- TOC entry 411 (class 1255 OID 7506611)
-- Dependencies: 3 1225 1221
-- Name: st_box2d(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box2d(box3d) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX3D_to_BOX2DFLOAT4'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d(box3d) OWNER TO postgres;

--
-- TOC entry 412 (class 1255 OID 7506612)
-- Dependencies: 1221 3 1221
-- Name: st_box2d_contain(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box2d_contain(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_contain'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_contain(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 413 (class 1255 OID 7506613)
-- Dependencies: 3 1221 1221
-- Name: st_box2d_contained(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box2d_contained(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_contained'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_contained(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 414 (class 1255 OID 7506614)
-- Dependencies: 3 1221 1221
-- Name: st_box2d_intersects(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box2d_intersects(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_intersects'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_intersects(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 415 (class 1255 OID 7506615)
-- Dependencies: 3 1221 1221
-- Name: st_box2d_left(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box2d_left(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_left'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_left(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 416 (class 1255 OID 7506616)
-- Dependencies: 1221 3 1221
-- Name: st_box2d_overlap(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box2d_overlap(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_overlap'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_overlap(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 417 (class 1255 OID 7506617)
-- Dependencies: 1221 3 1221
-- Name: st_box2d_overleft(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box2d_overleft(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_overleft'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_overleft(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 418 (class 1255 OID 7506618)
-- Dependencies: 1221 3 1221
-- Name: st_box2d_overright(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box2d_overright(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_overright'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_overright(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 419 (class 1255 OID 7506619)
-- Dependencies: 3 1221 1221
-- Name: st_box2d_right(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box2d_right(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_right'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_right(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 420 (class 1255 OID 7506620)
-- Dependencies: 3 1221 1221
-- Name: st_box2d_same(box2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box2d_same(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_same'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_same(box2d, box2d) OWNER TO postgres;

--
-- TOC entry 421 (class 1255 OID 7506621)
-- Dependencies: 930 3 1225
-- Name: st_box3d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box3d(geometry) RETURNS box3d
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX3D'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box3d(geometry) OWNER TO postgres;

--
-- TOC entry 422 (class 1255 OID 7506622)
-- Dependencies: 1225 3 1221
-- Name: st_box3d(box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_box3d(box2d) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_to_BOX3D'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box3d(box2d) OWNER TO postgres;

--
-- TOC entry 423 (class 1255 OID 7506623)
-- Dependencies: 3 930 930
-- Name: st_buffer(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_buffer(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'buffer'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_buffer(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 424 (class 1255 OID 7506624)
-- Dependencies: 930 930 3
-- Name: st_buffer(geometry, double precision, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_buffer(geometry, double precision, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'buffer'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_buffer(geometry, double precision, integer) OWNER TO postgres;

--
-- TOC entry 425 (class 1255 OID 7506625)
-- Dependencies: 1237 3 1237
-- Name: st_build_histogram2d(histogram2d, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_build_histogram2d(histogram2d, text, text) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'build_lwhistogram2d'
    LANGUAGE c STABLE STRICT;


ALTER FUNCTION public.st_build_histogram2d(histogram2d, text, text) OWNER TO postgres;

--
-- TOC entry 426 (class 1255 OID 7506626)
-- Dependencies: 1237 3 1478 1237
-- Name: st_build_histogram2d(histogram2d, text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_build_histogram2d(histogram2d, text, text, text) RETURNS histogram2d
    AS $_$
BEGIN
	EXECUTE 'SET local search_path = '||$2||',public';
	RETURN public.build_histogram2d($1,$3,$4);
END
$_$
    LANGUAGE plpgsql STABLE STRICT;


ALTER FUNCTION public.st_build_histogram2d(histogram2d, text, text, text) OWNER TO postgres;

--
-- TOC entry 427 (class 1255 OID 7506627)
-- Dependencies: 930 3 930
-- Name: st_buildarea(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_buildarea(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_buildarea'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_buildarea(geometry) OWNER TO postgres;

--
-- TOC entry 428 (class 1255 OID 7506628)
-- Dependencies: 930 3
-- Name: st_bytea(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_bytea(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_to_bytea'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_bytea(geometry) OWNER TO postgres;

--
-- TOC entry 429 (class 1255 OID 7506629)
-- Dependencies: 3
-- Name: st_cache_bbox(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_cache_bbox() RETURNS trigger
    AS '$libdir/liblwgeom', 'cache_bbox'
    LANGUAGE c;


ALTER FUNCTION public.st_cache_bbox() OWNER TO postgres;

--
-- TOC entry 430 (class 1255 OID 7506630)
-- Dependencies: 930 3 930
-- Name: st_centroid(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_centroid(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'centroid'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_centroid(geometry) OWNER TO postgres;

--
-- TOC entry 431 (class 1255 OID 7506631)
-- Dependencies: 930 3 930 930
-- Name: st_collect(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_collect(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_collect'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.st_collect(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 432 (class 1255 OID 7506632)
-- Dependencies: 930 3 933
-- Name: st_collect_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_collect_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_collect_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_collect_garray(geometry[]) OWNER TO postgres;

--
-- TOC entry 433 (class 1255 OID 7506633)
-- Dependencies: 930 3 930 930
-- Name: st_collector(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_collector(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_collect'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.st_collector(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 434 (class 1255 OID 7506634)
-- Dependencies: 930 1221 1221 3
-- Name: st_combine_bbox(box2d, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_combine_bbox(box2d, geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_combine'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.st_combine_bbox(box2d, geometry) OWNER TO postgres;

--
-- TOC entry 435 (class 1255 OID 7506635)
-- Dependencies: 1225 3 930 1225
-- Name: st_combine_bbox(box3d, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_combine_bbox(box3d, geometry) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_combine'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.st_combine_bbox(box3d, geometry) OWNER TO postgres;

--
-- TOC entry 436 (class 1255 OID 7506636)
-- Dependencies: 1229 3
-- Name: st_compression(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_compression(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getCompression'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_compression(chip) OWNER TO postgres;

--
-- TOC entry 437 (class 1255 OID 7506637)
-- Dependencies: 3 930 930
-- Name: st_contains(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_contains(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Contains($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_contains(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 438 (class 1255 OID 7506638)
-- Dependencies: 3 930 930
-- Name: st_convexhull(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_convexhull(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'convexhull'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_convexhull(geometry) OWNER TO postgres;

--
-- TOC entry 439 (class 1255 OID 7506639)
-- Dependencies: 930 3
-- Name: st_coorddim(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_coorddim(geometry) RETURNS smallint
    AS '$libdir/liblwgeom', 'LWGEOM_ndims'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_coorddim(geometry) OWNER TO postgres;

--
-- TOC entry 440 (class 1255 OID 7506640)
-- Dependencies: 3 930 930
-- Name: st_coveredby(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_coveredby(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_CoveredBy($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_coveredby(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 441 (class 1255 OID 7506641)
-- Dependencies: 930 930 3
-- Name: st_covers(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_covers(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Covers($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_covers(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 442 (class 1255 OID 7506642)
-- Dependencies: 1221 1237 3
-- Name: st_create_histogram2d(box2d, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_create_histogram2d(box2d, integer) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'create_lwhistogram2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_create_histogram2d(box2d, integer) OWNER TO postgres;

--
-- TOC entry 443 (class 1255 OID 7506643)
-- Dependencies: 3 930 930
-- Name: st_crosses(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_crosses(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Crosses($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_crosses(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 444 (class 1255 OID 7506644)
-- Dependencies: 930 930 3
-- Name: st_curvetoline(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_curvetoline(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_curve_segmentize'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_curvetoline(geometry, integer) OWNER TO postgres;

--
-- TOC entry 445 (class 1255 OID 7506645)
-- Dependencies: 3 930 930
-- Name: st_curvetoline(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_curvetoline(geometry) RETURNS geometry
    AS $_$SELECT ST_CurveToLine($1, 32)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_curvetoline(geometry) OWNER TO postgres;

--
-- TOC entry 446 (class 1255 OID 7506646)
-- Dependencies: 3 1229
-- Name: st_datatype(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_datatype(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getDatatype'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_datatype(chip) OWNER TO postgres;

--
-- TOC entry 447 (class 1255 OID 7506647)
-- Dependencies: 3 930 930 930
-- Name: st_difference(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_difference(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'difference'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_difference(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 448 (class 1255 OID 7506648)
-- Dependencies: 930 3
-- Name: st_dimension(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_dimension(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_dimension'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_dimension(geometry) OWNER TO postgres;

--
-- TOC entry 449 (class 1255 OID 7506649)
-- Dependencies: 930 930 3
-- Name: st_disjoint(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_disjoint(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'disjoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_disjoint(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 450 (class 1255 OID 7506650)
-- Dependencies: 3 930 930
-- Name: st_distance(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_distance(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_mindistance2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_distance(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 451 (class 1255 OID 7506651)
-- Dependencies: 930 3 930
-- Name: st_distance_sphere(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_distance_sphere(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_distance_sphere'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_distance_sphere(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 452 (class 1255 OID 7506652)
-- Dependencies: 930 3 930 1255
-- Name: st_distance_spheroid(geometry, geometry, spheroid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_distance_spheroid(geometry, geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_distance_ellipsoid_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_distance_spheroid(geometry, geometry, spheroid) OWNER TO postgres;

--
-- TOC entry 453 (class 1255 OID 7506653)
-- Dependencies: 930 930 3
-- Name: st_dropbbox(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_dropbbox(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_dropBBOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_dropbbox(geometry) OWNER TO postgres;

--
-- TOC entry 454 (class 1255 OID 7506654)
-- Dependencies: 930 1235 3
-- Name: st_dump(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_dump(geometry) RETURNS SETOF geometry_dump
    AS '$libdir/liblwgeom', 'LWGEOM_dump'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_dump(geometry) OWNER TO postgres;

--
-- TOC entry 455 (class 1255 OID 7506655)
-- Dependencies: 930 1235 3
-- Name: st_dumprings(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_dumprings(geometry) RETURNS SETOF geometry_dump
    AS '$libdir/liblwgeom', 'LWGEOM_dump_rings'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_dumprings(geometry) OWNER TO postgres;

--
-- TOC entry 456 (class 1255 OID 7506656)
-- Dependencies: 930 3 930
-- Name: st_dwithin(geometry, geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_dwithin(geometry, geometry, double precision) RETURNS boolean
    AS $_$SELECT $1 && ST_Expand($2,$3) AND $2 && ST_Expand($1,$3) AND _ST_DWithin($1, $2, $3)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_dwithin(geometry, geometry, double precision) OWNER TO postgres;

--
-- TOC entry 457 (class 1255 OID 7506657)
-- Dependencies: 930 3 930
-- Name: st_endpoint(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_endpoint(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_endpoint_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_endpoint(geometry) OWNER TO postgres;

--
-- TOC entry 458 (class 1255 OID 7506658)
-- Dependencies: 930 930 3
-- Name: st_envelope(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_envelope(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_envelope'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_envelope(geometry) OWNER TO postgres;

--
-- TOC entry 459 (class 1255 OID 7506659)
-- Dependencies: 930 930 3
-- Name: st_equals(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_equals(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'geomequals'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_equals(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 460 (class 1255 OID 7506660)
-- Dependencies: 1237 3 1221
-- Name: st_estimate_histogram2d(histogram2d, box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_estimate_histogram2d(histogram2d, box2d) RETURNS double precision
    AS '$libdir/liblwgeom', 'estimate_lwhistogram2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_estimate_histogram2d(histogram2d, box2d) OWNER TO postgres;

--
-- TOC entry 461 (class 1255 OID 7506661)
-- Dependencies: 3 1221
-- Name: st_estimated_extent(text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_estimated_extent(text, text, text) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_estimated_extent'
    LANGUAGE c IMMUTABLE STRICT SECURITY DEFINER;


ALTER FUNCTION public.st_estimated_extent(text, text, text) OWNER TO postgres;

--
-- TOC entry 462 (class 1255 OID 7506662)
-- Dependencies: 1221 3
-- Name: st_estimated_extent(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_estimated_extent(text, text) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_estimated_extent'
    LANGUAGE c IMMUTABLE STRICT SECURITY DEFINER;


ALTER FUNCTION public.st_estimated_extent(text, text) OWNER TO postgres;

--
-- TOC entry 463 (class 1255 OID 7506663)
-- Dependencies: 1225 1225 3
-- Name: st_expand(box3d, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_expand(box3d, double precision) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_expand'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_expand(box3d, double precision) OWNER TO postgres;

--
-- TOC entry 464 (class 1255 OID 7506664)
-- Dependencies: 3 1221 1221
-- Name: st_expand(box2d, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_expand(box2d, double precision) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_expand'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_expand(box2d, double precision) OWNER TO postgres;

--
-- TOC entry 465 (class 1255 OID 7506665)
-- Dependencies: 3 930 930
-- Name: st_expand(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_expand(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_expand'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_expand(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 466 (class 1255 OID 7506666)
-- Dependencies: 3 1237 1237
-- Name: st_explode_histogram2d(histogram2d, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_explode_histogram2d(histogram2d, text) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'explode_lwhistogram2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_explode_histogram2d(histogram2d, text) OWNER TO postgres;

--
-- TOC entry 467 (class 1255 OID 7506667)
-- Dependencies: 3 930 930
-- Name: st_exteriorring(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_exteriorring(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_exteriorring_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_exteriorring(geometry) OWNER TO postgres;

--
-- TOC entry 468 (class 1255 OID 7506668)
-- Dependencies: 3 1229
-- Name: st_factor(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_factor(chip) RETURNS real
    AS '$libdir/liblwgeom', 'CHIP_getFactor'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_factor(chip) OWNER TO postgres;

--
-- TOC entry 469 (class 1255 OID 7506669)
-- Dependencies: 3 1478 1221
-- Name: st_find_extent(text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_find_extent(text, text, text) RETURNS box2d
    AS $_$
DECLARE
	schemaname alias for $1;
	tablename alias for $2;
	columnname alias for $3;
	myrec RECORD;

BEGIN
	FOR myrec IN EXECUTE 'SELECT extent("'||columnname||'") FROM "'||schemaname||'"."'||tablename||'"' LOOP
		return myrec.extent;
	END LOOP; 
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.st_find_extent(text, text, text) OWNER TO postgres;

--
-- TOC entry 470 (class 1255 OID 7506670)
-- Dependencies: 3 1478 1221
-- Name: st_find_extent(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_find_extent(text, text) RETURNS box2d
    AS $_$
DECLARE
	tablename alias for $1;
	columnname alias for $2;
	myrec RECORD;

BEGIN
	FOR myrec IN EXECUTE 'SELECT extent("'||columnname||'") FROM "'||tablename||'"' LOOP
		return myrec.extent;
	END LOOP; 
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.st_find_extent(text, text) OWNER TO postgres;

--
-- TOC entry 471 (class 1255 OID 7506671)
-- Dependencies: 3 930 930
-- Name: st_force_2d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_force_2d(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_force_2d(geometry) OWNER TO postgres;

--
-- TOC entry 472 (class 1255 OID 7506672)
-- Dependencies: 3 930 930
-- Name: st_force_3d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_force_3d(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_3dz'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_force_3d(geometry) OWNER TO postgres;

--
-- TOC entry 473 (class 1255 OID 7506673)
-- Dependencies: 3 930 930
-- Name: st_force_3dm(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_force_3dm(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_3dm'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_force_3dm(geometry) OWNER TO postgres;

--
-- TOC entry 474 (class 1255 OID 7506674)
-- Dependencies: 3 930 930
-- Name: st_force_3dz(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_force_3dz(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_3dz'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_force_3dz(geometry) OWNER TO postgres;

--
-- TOC entry 475 (class 1255 OID 7506675)
-- Dependencies: 930 930 3
-- Name: st_force_4d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_force_4d(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_4d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_force_4d(geometry) OWNER TO postgres;

--
-- TOC entry 476 (class 1255 OID 7506676)
-- Dependencies: 3 930 930
-- Name: st_force_collection(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_force_collection(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_collection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_force_collection(geometry) OWNER TO postgres;

--
-- TOC entry 477 (class 1255 OID 7506677)
-- Dependencies: 3 930 930
-- Name: st_forcerhr(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_forcerhr(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_forceRHR_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_forcerhr(geometry) OWNER TO postgres;

--
-- TOC entry 478 (class 1255 OID 7506678)
-- Dependencies: 3 930 933 933
-- Name: st_geom_accum(geometry[], geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geom_accum(geometry[], geometry) RETURNS geometry[]
    AS '$libdir/liblwgeom', 'LWGEOM_accum'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.st_geom_accum(geometry[], geometry) OWNER TO postgres;

--
-- TOC entry 479 (class 1255 OID 7506679)
-- Dependencies: 3 930
-- Name: st_geomcollfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geomcollfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromText($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomcollfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 480 (class 1255 OID 7506680)
-- Dependencies: 3 930
-- Name: st_geomcollfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geomcollfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromText($1)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomcollfromtext(text) OWNER TO postgres;

--
-- TOC entry 481 (class 1255 OID 7506681)
-- Dependencies: 3 930
-- Name: st_geomcollfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geomcollfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromWKB($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomcollfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 482 (class 1255 OID 7506682)
-- Dependencies: 930 3
-- Name: st_geomcollfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geomcollfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromWKB($1)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomcollfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 483 (class 1255 OID 7506683)
-- Dependencies: 1221 930 3
-- Name: st_geometry(box2d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry(box2d) RETURNS geometry
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_to_LWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry(box2d) OWNER TO postgres;

--
-- TOC entry 484 (class 1255 OID 7506684)
-- Dependencies: 3 930 1225
-- Name: st_geometry(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry(box3d) RETURNS geometry
    AS '$libdir/liblwgeom', 'BOX3D_to_LWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry(box3d) OWNER TO postgres;

--
-- TOC entry 485 (class 1255 OID 7506685)
-- Dependencies: 930 3
-- Name: st_geometry(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry(text) RETURNS geometry
    AS '$libdir/liblwgeom', 'parse_WKT_lwgeom'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry(text) OWNER TO postgres;

--
-- TOC entry 486 (class 1255 OID 7506686)
-- Dependencies: 930 1229 3
-- Name: st_geometry(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry(chip) RETURNS geometry
    AS '$libdir/liblwgeom', 'CHIP_to_LWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry(chip) OWNER TO postgres;

--
-- TOC entry 487 (class 1255 OID 7506687)
-- Dependencies: 930 3
-- Name: st_geometry(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry(bytea) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_bytea'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry(bytea) OWNER TO postgres;

--
-- TOC entry 488 (class 1255 OID 7506688)
-- Dependencies: 3 930 930
-- Name: st_geometry_above(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_above(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_above'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_above(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 489 (class 1255 OID 7506689)
-- Dependencies: 3 930 930
-- Name: st_geometry_below(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_below(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_below'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_below(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 490 (class 1255 OID 7506690)
-- Dependencies: 930 3 930
-- Name: st_geometry_cmp(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_cmp(geometry, geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'lwgeom_cmp'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_cmp(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 491 (class 1255 OID 7506691)
-- Dependencies: 3 930 930
-- Name: st_geometry_contain(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_contain(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_contain'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_contain(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 492 (class 1255 OID 7506692)
-- Dependencies: 3 930 930
-- Name: st_geometry_contained(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_contained(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_contained'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_contained(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 493 (class 1255 OID 7506693)
-- Dependencies: 3 930 930
-- Name: st_geometry_eq(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_eq(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_eq'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_eq(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 494 (class 1255 OID 7506694)
-- Dependencies: 3 930 930
-- Name: st_geometry_ge(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_ge(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_ge'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_ge(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 495 (class 1255 OID 7506695)
-- Dependencies: 3 930 930
-- Name: st_geometry_gt(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_gt(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_gt'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_gt(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 496 (class 1255 OID 7506696)
-- Dependencies: 930 930 3
-- Name: st_geometry_le(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_le(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_le'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_le(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 497 (class 1255 OID 7506697)
-- Dependencies: 3 930 930
-- Name: st_geometry_left(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_left(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_left'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_left(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 498 (class 1255 OID 7506698)
-- Dependencies: 930 930 3
-- Name: st_geometry_lt(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_lt(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_lt'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_lt(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 499 (class 1255 OID 7506699)
-- Dependencies: 930 930 3
-- Name: st_geometry_overabove(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_overabove(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overabove'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_overabove(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 500 (class 1255 OID 7506700)
-- Dependencies: 930 3 930
-- Name: st_geometry_overbelow(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_overbelow(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overbelow'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_overbelow(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 501 (class 1255 OID 7506701)
-- Dependencies: 3 930 930
-- Name: st_geometry_overlap(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_overlap(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overlap'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_overlap(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 502 (class 1255 OID 7506702)
-- Dependencies: 3 930 930
-- Name: st_geometry_overleft(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_overleft(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overleft'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_overleft(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 503 (class 1255 OID 7506703)
-- Dependencies: 930 3 930
-- Name: st_geometry_overright(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_overright(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overright'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_overright(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 504 (class 1255 OID 7506704)
-- Dependencies: 3 930 930
-- Name: st_geometry_right(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_right(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_right'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_right(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 505 (class 1255 OID 7506705)
-- Dependencies: 930 930 3
-- Name: st_geometry_same(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometry_same(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_same'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_same(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 506 (class 1255 OID 7506706)
-- Dependencies: 3 930
-- Name: st_geometryfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometryfromtext(text) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometryfromtext(text) OWNER TO postgres;

--
-- TOC entry 507 (class 1255 OID 7506707)
-- Dependencies: 3 930
-- Name: st_geometryfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometryfromtext(text, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometryfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 508 (class 1255 OID 7506708)
-- Dependencies: 930 930 3
-- Name: st_geometryn(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometryn(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_geometryn_collection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometryn(geometry, integer) OWNER TO postgres;

--
-- TOC entry 509 (class 1255 OID 7506709)
-- Dependencies: 3 1478 930
-- Name: st_geometrytype(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geometrytype(geometry) RETURNS text
    AS $_$
    DECLARE
        gtype text := geometrytype($1);
    BEGIN
        IF (gtype IN ('POINT', 'POINTM')) THEN
            gtype := 'Point';
        ELSIF (gtype IN ('LINESTRING', 'LINESTRINGM')) THEN
            gtype := 'LineString';
        ELSIF (gtype IN ('POLYGON', 'POLYGONM')) THEN
            gtype := 'Polygon';
        ELSIF (gtype IN ('MULTIPOINT', 'MULTIPOINTM')) THEN
            gtype := 'MultiPoint';
        ELSIF (gtype IN ('MULTILINESTRING', 'MULTILINESTRINGM')) THEN
            gtype := 'MultiLineString';
        ELSIF (gtype IN ('MULTIPOLYGON', 'MULTIPOLYGONM')) THEN
            gtype := 'MultiPolygon';
        ELSE
            gtype := 'Geometry';
        END IF;
        RETURN 'ST_' || gtype;
    END
	$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometrytype(geometry) OWNER TO postgres;

--
-- TOC entry 510 (class 1255 OID 7506710)
-- Dependencies: 930 3
-- Name: st_geomfromewkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geomfromewkb(bytea) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOMFromWKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomfromewkb(bytea) OWNER TO postgres;

--
-- TOC entry 511 (class 1255 OID 7506711)
-- Dependencies: 3 930
-- Name: st_geomfromewkt(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geomfromewkt(text) RETURNS geometry
    AS '$libdir/liblwgeom', 'parse_WKT_lwgeom'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomfromewkt(text) OWNER TO postgres;

--
-- TOC entry 512 (class 1255 OID 7506712)
-- Dependencies: 3 930
-- Name: st_geomfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geomfromtext(text) RETURNS geometry
    AS $_$SELECT geometryfromtext($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomfromtext(text) OWNER TO postgres;

--
-- TOC entry 513 (class 1255 OID 7506713)
-- Dependencies: 3 930
-- Name: st_geomfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geomfromtext(text, integer) RETURNS geometry
    AS $_$SELECT geometryfromtext($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 514 (class 1255 OID 7506714)
-- Dependencies: 930 3
-- Name: st_geomfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geomfromwkb(bytea) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_WKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 515 (class 1255 OID 7506715)
-- Dependencies: 930 3
-- Name: st_geomfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_geomfromwkb(bytea, integer) RETURNS geometry
    AS $_$SELECT setSRID(GeomFromWKB($1), $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 516 (class 1255 OID 7506716)
-- Dependencies: 3 930
-- Name: st_hasarc(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_hasarc(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_has_arc'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_hasarc(geometry) OWNER TO postgres;

--
-- TOC entry 517 (class 1255 OID 7506717)
-- Dependencies: 3 930
-- Name: st_hasbbox(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_hasbbox(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_hasBBOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_hasbbox(geometry) OWNER TO postgres;

--
-- TOC entry 518 (class 1255 OID 7506718)
-- Dependencies: 3 1229
-- Name: st_height(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_height(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getHeight'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_height(chip) OWNER TO postgres;

--
-- TOC entry 519 (class 1255 OID 7506719)
-- Dependencies: 930 3 930
-- Name: st_interiorringn(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_interiorringn(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_interiorringn_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_interiorringn(geometry, integer) OWNER TO postgres;

--
-- TOC entry 520 (class 1255 OID 7506720)
-- Dependencies: 3 930 930 930
-- Name: st_intersection(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_intersection(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'intersection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_intersection(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 521 (class 1255 OID 7506721)
-- Dependencies: 930 930 3
-- Name: st_intersects(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_intersects(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Intersects($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_intersects(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 522 (class 1255 OID 7506722)
-- Dependencies: 930 3
-- Name: st_isclosed(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_isclosed(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_isclosed_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_isclosed(geometry) OWNER TO postgres;

--
-- TOC entry 523 (class 1255 OID 7506723)
-- Dependencies: 930 3
-- Name: st_isempty(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_isempty(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_isempty'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_isempty(geometry) OWNER TO postgres;

--
-- TOC entry 524 (class 1255 OID 7506724)
-- Dependencies: 930 3
-- Name: st_isring(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_isring(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'isring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_isring(geometry) OWNER TO postgres;

--
-- TOC entry 525 (class 1255 OID 7506725)
-- Dependencies: 930 3
-- Name: st_issimple(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_issimple(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'issimple'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_issimple(geometry) OWNER TO postgres;

--
-- TOC entry 526 (class 1255 OID 7506726)
-- Dependencies: 3 930
-- Name: st_isvalid(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_isvalid(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'isvalid'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_isvalid(geometry) OWNER TO postgres;

--
-- TOC entry 527 (class 1255 OID 7506727)
-- Dependencies: 3 930
-- Name: st_length(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_length(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length2d_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_length(geometry) OWNER TO postgres;

--
-- TOC entry 528 (class 1255 OID 7506728)
-- Dependencies: 3 930
-- Name: st_length2d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_length2d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length2d_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_length2d(geometry) OWNER TO postgres;

--
-- TOC entry 529 (class 1255 OID 7506729)
-- Dependencies: 3 930 1255
-- Name: st_length2d_spheroid(geometry, spheroid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_length2d_spheroid(geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length2d_ellipsoid_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_length2d_spheroid(geometry, spheroid) OWNER TO postgres;

--
-- TOC entry 530 (class 1255 OID 7506730)
-- Dependencies: 3 930
-- Name: st_length3d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_length3d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_length3d(geometry) OWNER TO postgres;

--
-- TOC entry 531 (class 1255 OID 7506731)
-- Dependencies: 930 3 1255
-- Name: st_length3d_spheroid(geometry, spheroid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_length3d_spheroid(geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_ellipsoid_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_length3d_spheroid(geometry, spheroid) OWNER TO postgres;

--
-- TOC entry 532 (class 1255 OID 7506732)
-- Dependencies: 930 3 1255
-- Name: st_length_spheroid(geometry, spheroid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_length_spheroid(geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_ellipsoid_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_length_spheroid(geometry, spheroid) OWNER TO postgres;

--
-- TOC entry 533 (class 1255 OID 7506733)
-- Dependencies: 930 3 930
-- Name: st_line_interpolate_point(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_line_interpolate_point(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_interpolate_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_line_interpolate_point(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 534 (class 1255 OID 7506734)
-- Dependencies: 930 930 3
-- Name: st_line_locate_point(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_line_locate_point(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_line_locate_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_line_locate_point(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 535 (class 1255 OID 7506735)
-- Dependencies: 3 930 930
-- Name: st_line_substring(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_line_substring(geometry, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_substring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_line_substring(geometry, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 536 (class 1255 OID 7506736)
-- Dependencies: 3 930 930
-- Name: st_linefrommultipoint(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_linefrommultipoint(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_from_mpoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_linefrommultipoint(geometry) OWNER TO postgres;

--
-- TOC entry 537 (class 1255 OID 7506737)
-- Dependencies: 930 3
-- Name: st_linefromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_linefromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'LINESTRING'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_linefromtext(text) OWNER TO postgres;

--
-- TOC entry 538 (class 1255 OID 7506738)
-- Dependencies: 3 930
-- Name: st_linefromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_linefromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'LINESTRING'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_linefromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 539 (class 1255 OID 7506739)
-- Dependencies: 3 930
-- Name: st_linefromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_linefromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'LINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_linefromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 540 (class 1255 OID 7506740)
-- Dependencies: 3 930
-- Name: st_linefromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_linefromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'LINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_linefromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 541 (class 1255 OID 7506741)
-- Dependencies: 3 930 930
-- Name: st_linemerge(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_linemerge(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'linemerge'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_linemerge(geometry) OWNER TO postgres;

--
-- TOC entry 542 (class 1255 OID 7506742)
-- Dependencies: 3 930
-- Name: st_linestringfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_linestringfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'LINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_linestringfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 543 (class 1255 OID 7506743)
-- Dependencies: 3 930
-- Name: st_linestringfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_linestringfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'LINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_linestringfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 544 (class 1255 OID 7506744)
-- Dependencies: 3 930 930
-- Name: st_linetocurve(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_linetocurve(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_desegmentize'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_linetocurve(geometry) OWNER TO postgres;

--
-- TOC entry 545 (class 1255 OID 7506745)
-- Dependencies: 3 930 930
-- Name: st_locate_along_measure(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_locate_along_measure(geometry, double precision) RETURNS geometry
    AS $_$SELECT locate_between_measures($1, $2, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_locate_along_measure(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 546 (class 1255 OID 7506746)
-- Dependencies: 3 930 930
-- Name: st_locate_between_measures(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_locate_between_measures(geometry, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_locate_between_m'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_locate_between_measures(geometry, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 547 (class 1255 OID 7506747)
-- Dependencies: 3 930
-- Name: st_m(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_m(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_m_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_m(geometry) OWNER TO postgres;

--
-- TOC entry 548 (class 1255 OID 7506748)
-- Dependencies: 3 1221 930 930
-- Name: st_makebox2d(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_makebox2d(geometry, geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_construct'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makebox2d(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 549 (class 1255 OID 7506749)
-- Dependencies: 3 1225 930 930
-- Name: st_makebox3d(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_makebox3d(geometry, geometry) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_construct'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makebox3d(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 550 (class 1255 OID 7506750)
-- Dependencies: 930 3 930 930
-- Name: st_makeline(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_makeline(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makeline'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makeline(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 551 (class 1255 OID 7506751)
-- Dependencies: 3 930 933
-- Name: st_makeline_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_makeline_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makeline_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makeline_garray(geometry[]) OWNER TO postgres;

--
-- TOC entry 552 (class 1255 OID 7506752)
-- Dependencies: 3 930
-- Name: st_makepoint(double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_makepoint(double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makepoint(double precision, double precision) OWNER TO postgres;

--
-- TOC entry 553 (class 1255 OID 7506753)
-- Dependencies: 3 930
-- Name: st_makepoint(double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_makepoint(double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makepoint(double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 554 (class 1255 OID 7506754)
-- Dependencies: 3 930
-- Name: st_makepoint(double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_makepoint(double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makepoint(double precision, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 555 (class 1255 OID 7506755)
-- Dependencies: 3 930
-- Name: st_makepointm(double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_makepointm(double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint3dm'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makepointm(double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 556 (class 1255 OID 7506756)
-- Dependencies: 3 930 930 933
-- Name: st_makepolygon(geometry, geometry[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_makepolygon(geometry, geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makepolygon(geometry, geometry[]) OWNER TO postgres;

--
-- TOC entry 557 (class 1255 OID 7506757)
-- Dependencies: 3 930 930
-- Name: st_makepolygon(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_makepolygon(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makepolygon(geometry) OWNER TO postgres;

--
-- TOC entry 558 (class 1255 OID 7506758)
-- Dependencies: 3 930 930
-- Name: st_max_distance(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_max_distance(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_maxdistance2d_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_max_distance(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 559 (class 1255 OID 7506759)
-- Dependencies: 3 930
-- Name: st_mem_size(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_mem_size(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_mem_size'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_mem_size(geometry) OWNER TO postgres;

--
-- TOC entry 560 (class 1255 OID 7506760)
-- Dependencies: 3 930
-- Name: st_mlinefromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_mlinefromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromText($1, $2)) = 'MULTILINESTRING'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mlinefromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 561 (class 1255 OID 7506761)
-- Dependencies: 3 930
-- Name: st_mlinefromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_mlinefromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'MULTILINESTRING'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mlinefromtext(text) OWNER TO postgres;

--
-- TOC entry 562 (class 1255 OID 7506762)
-- Dependencies: 3 930
-- Name: st_mlinefromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_mlinefromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mlinefromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 563 (class 1255 OID 7506763)
-- Dependencies: 3 930
-- Name: st_mlinefromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_mlinefromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mlinefromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 564 (class 1255 OID 7506764)
-- Dependencies: 3 930
-- Name: st_mpointfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_mpointfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'MULTIPOINT'
	THEN GeomFromText($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpointfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 565 (class 1255 OID 7506765)
-- Dependencies: 3 930
-- Name: st_mpointfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_mpointfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'MULTIPOINT'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpointfromtext(text) OWNER TO postgres;

--
-- TOC entry 566 (class 1255 OID 7506766)
-- Dependencies: 3 930
-- Name: st_mpointfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_mpointfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTIPOINT'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpointfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 567 (class 1255 OID 7506767)
-- Dependencies: 3 930
-- Name: st_mpointfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_mpointfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOINT'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpointfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 568 (class 1255 OID 7506768)
-- Dependencies: 3 930
-- Name: st_mpolyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_mpolyfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'MULTIPOLYGON'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpolyfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 569 (class 1255 OID 7506769)
-- Dependencies: 3 930
-- Name: st_mpolyfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_mpolyfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'MULTIPOLYGON'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpolyfromtext(text) OWNER TO postgres;

--
-- TOC entry 570 (class 1255 OID 7506770)
-- Dependencies: 3 930
-- Name: st_mpolyfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_mpolyfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpolyfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 571 (class 1255 OID 7506771)
-- Dependencies: 3 930
-- Name: st_mpolyfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_mpolyfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpolyfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 572 (class 1255 OID 7506772)
-- Dependencies: 3 930 930
-- Name: st_multi(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_multi(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_multi'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_multi(geometry) OWNER TO postgres;

--
-- TOC entry 573 (class 1255 OID 7506773)
-- Dependencies: 3 930
-- Name: st_multilinefromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_multilinefromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multilinefromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 574 (class 1255 OID 7506774)
-- Dependencies: 930 3
-- Name: st_multilinestringfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_multilinestringfromtext(text) RETURNS geometry
    AS $_$SELECT MLineFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multilinestringfromtext(text) OWNER TO postgres;

--
-- TOC entry 575 (class 1255 OID 7506775)
-- Dependencies: 3 930
-- Name: st_multilinestringfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_multilinestringfromtext(text, integer) RETURNS geometry
    AS $_$SELECT MLineFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multilinestringfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 576 (class 1255 OID 7506776)
-- Dependencies: 3 930
-- Name: st_multipointfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_multipointfromtext(text) RETURNS geometry
    AS $_$SELECT MPointFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipointfromtext(text) OWNER TO postgres;

--
-- TOC entry 577 (class 1255 OID 7506777)
-- Dependencies: 930 3
-- Name: st_multipointfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_multipointfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1,$2)) = 'MULTIPOINT'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipointfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 578 (class 1255 OID 7506778)
-- Dependencies: 3 930
-- Name: st_multipointfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_multipointfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOINT'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipointfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 579 (class 1255 OID 7506779)
-- Dependencies: 3 930
-- Name: st_multipolyfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_multipolyfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipolyfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 580 (class 1255 OID 7506780)
-- Dependencies: 930 3
-- Name: st_multipolyfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_multipolyfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipolyfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 581 (class 1255 OID 7506781)
-- Dependencies: 3 930
-- Name: st_multipolygonfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_multipolygonfromtext(text, integer) RETURNS geometry
    AS $_$SELECT MPolyFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipolygonfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 582 (class 1255 OID 7506782)
-- Dependencies: 3 930
-- Name: st_multipolygonfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_multipolygonfromtext(text) RETURNS geometry
    AS $_$SELECT MPolyFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipolygonfromtext(text) OWNER TO postgres;

--
-- TOC entry 583 (class 1255 OID 7506783)
-- Dependencies: 3 930
-- Name: st_ndims(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_ndims(geometry) RETURNS smallint
    AS '$libdir/liblwgeom', 'LWGEOM_ndims'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_ndims(geometry) OWNER TO postgres;

--
-- TOC entry 584 (class 1255 OID 7506784)
-- Dependencies: 3 930 930
-- Name: st_noop(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_noop(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_noop'
    LANGUAGE c STRICT;


ALTER FUNCTION public.st_noop(geometry) OWNER TO postgres;

--
-- TOC entry 585 (class 1255 OID 7506785)
-- Dependencies: 3 930
-- Name: st_npoints(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_npoints(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_npoints'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_npoints(geometry) OWNER TO postgres;

--
-- TOC entry 586 (class 1255 OID 7506786)
-- Dependencies: 3 930
-- Name: st_nrings(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_nrings(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_nrings'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_nrings(geometry) OWNER TO postgres;

--
-- TOC entry 587 (class 1255 OID 7506787)
-- Dependencies: 3 930
-- Name: st_numgeometries(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_numgeometries(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numgeometries_collection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_numgeometries(geometry) OWNER TO postgres;

--
-- TOC entry 588 (class 1255 OID 7506788)
-- Dependencies: 3 930
-- Name: st_numinteriorring(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_numinteriorring(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numinteriorrings_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_numinteriorring(geometry) OWNER TO postgres;

--
-- TOC entry 589 (class 1255 OID 7506789)
-- Dependencies: 3 930
-- Name: st_numinteriorrings(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_numinteriorrings(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numinteriorrings_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_numinteriorrings(geometry) OWNER TO postgres;

--
-- TOC entry 590 (class 1255 OID 7506790)
-- Dependencies: 3 930
-- Name: st_numpoints(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_numpoints(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numpoints_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_numpoints(geometry) OWNER TO postgres;

--
-- TOC entry 591 (class 1255 OID 7506791)
-- Dependencies: 930 3 930
-- Name: st_orderingequals(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_orderingequals(geometry, geometry) RETURNS boolean
    AS $_$
    SELECT $1 && $2 AND $1 ~= $2
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_orderingequals(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 592 (class 1255 OID 7506792)
-- Dependencies: 930 3 930
-- Name: st_overlaps(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_overlaps(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Overlaps($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_overlaps(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 593 (class 1255 OID 7506793)
-- Dependencies: 3 930
-- Name: st_perimeter(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_perimeter(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_perimeter2d_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_perimeter(geometry) OWNER TO postgres;

--
-- TOC entry 594 (class 1255 OID 7506794)
-- Dependencies: 3 930
-- Name: st_perimeter2d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_perimeter2d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_perimeter2d_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_perimeter2d(geometry) OWNER TO postgres;

--
-- TOC entry 595 (class 1255 OID 7506795)
-- Dependencies: 3 930
-- Name: st_perimeter3d(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_perimeter3d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_perimeter_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_perimeter3d(geometry) OWNER TO postgres;

--
-- TOC entry 596 (class 1255 OID 7506796)
-- Dependencies: 930 3
-- Name: st_point(double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_point(double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_point(double precision, double precision) OWNER TO postgres;

--
-- TOC entry 597 (class 1255 OID 7506797)
-- Dependencies: 930 3
-- Name: st_point_inside_circle(geometry, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_point_inside_circle(geometry, double precision, double precision, double precision) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_inside_circle_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_point_inside_circle(geometry, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 598 (class 1255 OID 7506798)
-- Dependencies: 3 930
-- Name: st_pointfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_pointfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'POINT'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_pointfromtext(text) OWNER TO postgres;

--
-- TOC entry 599 (class 1255 OID 7506799)
-- Dependencies: 930 3
-- Name: st_pointfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_pointfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'POINT'
	THEN GeomFromText($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_pointfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 600 (class 1255 OID 7506800)
-- Dependencies: 3 930
-- Name: st_pointfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_pointfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'POINT'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_pointfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 601 (class 1255 OID 7506801)
-- Dependencies: 930 3
-- Name: st_pointfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_pointfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'POINT'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_pointfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 602 (class 1255 OID 7506802)
-- Dependencies: 3 930 930
-- Name: st_pointn(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_pointn(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_pointn_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_pointn(geometry, integer) OWNER TO postgres;

--
-- TOC entry 603 (class 1255 OID 7506803)
-- Dependencies: 3 930 930
-- Name: st_pointonsurface(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_pointonsurface(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'pointonsurface'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_pointonsurface(geometry) OWNER TO postgres;

--
-- TOC entry 604 (class 1255 OID 7506804)
-- Dependencies: 3 930
-- Name: st_polyfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_polyfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'POLYGON'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polyfromtext(text) OWNER TO postgres;

--
-- TOC entry 605 (class 1255 OID 7506805)
-- Dependencies: 3 930
-- Name: st_polyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_polyfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'POLYGON'
	THEN GeomFromText($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polyfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 606 (class 1255 OID 7506806)
-- Dependencies: 3 930
-- Name: st_polyfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_polyfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'POLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polyfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 607 (class 1255 OID 7506807)
-- Dependencies: 3 930
-- Name: st_polyfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_polyfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'POLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polyfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 608 (class 1255 OID 7506808)
-- Dependencies: 3 930 930
-- Name: st_polygon(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_polygon(geometry, integer) RETURNS geometry
    AS $_$
	SELECT setSRID(makepolygon($1), $2)
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polygon(geometry, integer) OWNER TO postgres;

--
-- TOC entry 609 (class 1255 OID 7506809)
-- Dependencies: 3 930
-- Name: st_polygonfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_polygonfromtext(text, integer) RETURNS geometry
    AS $_$SELECT PolyFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polygonfromtext(text, integer) OWNER TO postgres;

--
-- TOC entry 610 (class 1255 OID 7506810)
-- Dependencies: 3 930
-- Name: st_polygonfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_polygonfromtext(text) RETURNS geometry
    AS $_$SELECT PolyFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polygonfromtext(text) OWNER TO postgres;

--
-- TOC entry 611 (class 1255 OID 7506811)
-- Dependencies: 3 930
-- Name: st_polygonfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_polygonfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1,$2)) = 'POLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polygonfromwkb(bytea, integer) OWNER TO postgres;

--
-- TOC entry 612 (class 1255 OID 7506812)
-- Dependencies: 3 930
-- Name: st_polygonfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_polygonfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'POLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polygonfromwkb(bytea) OWNER TO postgres;

--
-- TOC entry 613 (class 1255 OID 7506813)
-- Dependencies: 3 930 933
-- Name: st_polygonize_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_polygonize_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'polygonize_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_polygonize_garray(geometry[]) OWNER TO postgres;

--
-- TOC entry 614 (class 1255 OID 7506814)
-- Dependencies: 3
-- Name: st_postgis_gist_joinsel(internal, oid, internal, smallint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_postgis_gist_joinsel(internal, oid, internal, smallint) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_gist_joinsel'
    LANGUAGE c;


ALTER FUNCTION public.st_postgis_gist_joinsel(internal, oid, internal, smallint) OWNER TO postgres;

--
-- TOC entry 615 (class 1255 OID 7506815)
-- Dependencies: 3
-- Name: st_postgis_gist_sel(internal, oid, internal, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_postgis_gist_sel(internal, oid, internal, integer) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_gist_sel'
    LANGUAGE c;


ALTER FUNCTION public.st_postgis_gist_sel(internal, oid, internal, integer) OWNER TO postgres;

--
-- TOC entry 616 (class 1255 OID 7506816)
-- Dependencies: 3 930 930
-- Name: st_relate(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_relate(geometry, geometry) RETURNS text
    AS '$libdir/liblwgeom', 'relate_full'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_relate(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 617 (class 1255 OID 7506817)
-- Dependencies: 3 930 930
-- Name: st_relate(geometry, geometry, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_relate(geometry, geometry, text) RETURNS boolean
    AS '$libdir/liblwgeom', 'relate_pattern'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_relate(geometry, geometry, text) OWNER TO postgres;

--
-- TOC entry 618 (class 1255 OID 7506818)
-- Dependencies: 3 930 930
-- Name: st_removepoint(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_removepoint(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_removepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_removepoint(geometry, integer) OWNER TO postgres;

--
-- TOC entry 619 (class 1255 OID 7506819)
-- Dependencies: 3 930 930
-- Name: st_reverse(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_reverse(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_reverse'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_reverse(geometry) OWNER TO postgres;

--
-- TOC entry 620 (class 1255 OID 7506820)
-- Dependencies: 930 3 930
-- Name: st_rotate(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_rotate(geometry, double precision) RETURNS geometry
    AS $_$SELECT rotateZ($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_rotate(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 621 (class 1255 OID 7506821)
-- Dependencies: 930 930 3
-- Name: st_rotatex(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_rotatex(geometry, double precision) RETURNS geometry
    AS $_$SELECT affine($1, 1, 0, 0, 0, cos($2), -sin($2), 0, sin($2), cos($2), 0, 0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_rotatex(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 622 (class 1255 OID 7506822)
-- Dependencies: 930 3 930
-- Name: st_rotatey(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_rotatey(geometry, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  cos($2), 0, sin($2),  0, 1, 0,  -sin($2), 0, cos($2), 0,  0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_rotatey(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 623 (class 1255 OID 7506823)
-- Dependencies: 930 930 3
-- Name: st_rotatez(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_rotatez(geometry, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  cos($2), -sin($2), 0,  sin($2), cos($2), 0,  0, 0, 1,  0, 0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_rotatez(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 624 (class 1255 OID 7506824)
-- Dependencies: 930 930 3
-- Name: st_scale(geometry, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_scale(geometry, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  $2, 0, 0,  0, $3, 0,  0, 0, $4,  0, 0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_scale(geometry, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 625 (class 1255 OID 7506825)
-- Dependencies: 930 3 930
-- Name: st_scale(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_scale(geometry, double precision, double precision) RETURNS geometry
    AS $_$SELECT scale($1, $2, $3, 1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_scale(geometry, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 626 (class 1255 OID 7506826)
-- Dependencies: 3 930 930
-- Name: st_segmentize(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_segmentize(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_segmentize2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_segmentize(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 627 (class 1255 OID 7506827)
-- Dependencies: 1229 1229 3
-- Name: st_setfactor(chip, real); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_setfactor(chip, real) RETURNS chip
    AS '$libdir/liblwgeom', 'CHIP_setFactor'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_setfactor(chip, real) OWNER TO postgres;

--
-- TOC entry 628 (class 1255 OID 7506828)
-- Dependencies: 930 930 930 3
-- Name: st_setpoint(geometry, integer, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_setpoint(geometry, integer, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_setpoint_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_setpoint(geometry, integer, geometry) OWNER TO postgres;

--
-- TOC entry 629 (class 1255 OID 7506829)
-- Dependencies: 3 930 930
-- Name: st_setsrid(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_setsrid(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_setSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_setsrid(geometry, integer) OWNER TO postgres;

--
-- TOC entry 630 (class 1255 OID 7506830)
-- Dependencies: 930 3 930
-- Name: st_shift_longitude(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_shift_longitude(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_longitude_shift'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_shift_longitude(geometry) OWNER TO postgres;

--
-- TOC entry 631 (class 1255 OID 7506831)
-- Dependencies: 930 3 930
-- Name: st_simplify(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_simplify(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_simplify2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_simplify(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 632 (class 1255 OID 7506832)
-- Dependencies: 3 930 930
-- Name: st_simplifypreservetopology(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_simplifypreservetopology(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'topologypreservesimplify'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_simplifypreservetopology(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 633 (class 1255 OID 7506833)
-- Dependencies: 930 930 3
-- Name: st_snaptogrid(geometry, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_snaptogrid(geometry, double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_snaptogrid'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_snaptogrid(geometry, double precision, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 634 (class 1255 OID 7506834)
-- Dependencies: 3 930 930
-- Name: st_snaptogrid(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_snaptogrid(geometry, double precision, double precision) RETURNS geometry
    AS $_$SELECT SnapToGrid($1, 0, 0, $2, $3)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_snaptogrid(geometry, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 635 (class 1255 OID 7506835)
-- Dependencies: 3 930 930
-- Name: st_snaptogrid(geometry, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_snaptogrid(geometry, double precision) RETURNS geometry
    AS $_$SELECT SnapToGrid($1, 0, 0, $2, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_snaptogrid(geometry, double precision) OWNER TO postgres;

--
-- TOC entry 636 (class 1255 OID 7506836)
-- Dependencies: 930 3 930 930
-- Name: st_snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_snaptogrid_pointoff'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 637 (class 1255 OID 7506837)
-- Dependencies: 3 1229
-- Name: st_srid(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_srid(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_srid(chip) OWNER TO postgres;

--
-- TOC entry 638 (class 1255 OID 7506838)
-- Dependencies: 3 930
-- Name: st_srid(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_srid(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_getSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_srid(geometry) OWNER TO postgres;

--
-- TOC entry 639 (class 1255 OID 7506839)
-- Dependencies: 930 3 930
-- Name: st_startpoint(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_startpoint(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_startpoint_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_startpoint(geometry) OWNER TO postgres;

--
-- TOC entry 640 (class 1255 OID 7506840)
-- Dependencies: 3 930
-- Name: st_summary(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_summary(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_summary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_summary(geometry) OWNER TO postgres;

--
-- TOC entry 641 (class 1255 OID 7506841)
-- Dependencies: 930 3 930 930
-- Name: st_symdifference(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_symdifference(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'symdifference'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_symdifference(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 642 (class 1255 OID 7506842)
-- Dependencies: 930 3 930 930
-- Name: st_symmetricdifference(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_symmetricdifference(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'symdifference'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_symmetricdifference(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 643 (class 1255 OID 7506843)
-- Dependencies: 3 930
-- Name: st_text(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_text(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_to_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_text(geometry) OWNER TO postgres;

--
-- TOC entry 644 (class 1255 OID 7506844)
-- Dependencies: 3
-- Name: st_text(boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_text(boolean) RETURNS text
    AS '$libdir/liblwgeom', 'BOOL_to_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_text(boolean) OWNER TO postgres;

--
-- TOC entry 645 (class 1255 OID 7506845)
-- Dependencies: 930 3 930
-- Name: st_touches(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_touches(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Touches($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_touches(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 646 (class 1255 OID 7506846)
-- Dependencies: 3 930 930
-- Name: st_transform(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_transform(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'transform'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_transform(geometry, integer) OWNER TO postgres;

--
-- TOC entry 647 (class 1255 OID 7506847)
-- Dependencies: 930 3 930
-- Name: st_translate(geometry, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_translate(geometry, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1, 1, 0, 0, 0, 1, 0, 0, 0, 1, $2, $3, $4)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_translate(geometry, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 648 (class 1255 OID 7506848)
-- Dependencies: 3 930 930
-- Name: st_translate(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_translate(geometry, double precision, double precision) RETURNS geometry
    AS $_$SELECT translate($1, $2, $3, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_translate(geometry, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 649 (class 1255 OID 7506849)
-- Dependencies: 930 930 3
-- Name: st_transscale(geometry, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_transscale(geometry, double precision, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  $4, 0, 0,  0, $5, 0, 
		0, 0, 1,  $2 * $4, $3 * $5, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_transscale(geometry, double precision, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 650 (class 1255 OID 7506850)
-- Dependencies: 930 930 930 3
-- Name: st_union(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_union(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'geomunion'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_union(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 651 (class 1255 OID 7506851)
-- Dependencies: 3 933 930
-- Name: st_unite_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_unite_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'unite_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_unite_garray(geometry[]) OWNER TO postgres;

--
-- TOC entry 652 (class 1255 OID 7506852)
-- Dependencies: 3 1229
-- Name: st_width(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_width(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getWidth'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_width(chip) OWNER TO postgres;

--
-- TOC entry 653 (class 1255 OID 7506853)
-- Dependencies: 3 930 930
-- Name: st_within(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_within(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Within($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_within(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 654 (class 1255 OID 7506854)
-- Dependencies: 3 930
-- Name: st_wkbtosql(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_wkbtosql(bytea) RETURNS geometry
    AS $_$SELECT GeomFromWKB($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_wkbtosql(bytea) OWNER TO postgres;

--
-- TOC entry 655 (class 1255 OID 7506855)
-- Dependencies: 930 3
-- Name: st_wkttosql(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_wkttosql(text) RETURNS geometry
    AS $_$SELECT geometryfromtext($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_wkttosql(text) OWNER TO postgres;

--
-- TOC entry 656 (class 1255 OID 7506856)
-- Dependencies: 3 930
-- Name: st_x(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_x(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_x_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_x(geometry) OWNER TO postgres;

--
-- TOC entry 657 (class 1255 OID 7506857)
-- Dependencies: 1225 3
-- Name: st_xmax(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_xmax(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_xmax'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_xmax(box3d) OWNER TO postgres;

--
-- TOC entry 658 (class 1255 OID 7506858)
-- Dependencies: 3 1225
-- Name: st_xmin(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_xmin(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_xmin'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_xmin(box3d) OWNER TO postgres;

--
-- TOC entry 659 (class 1255 OID 7506859)
-- Dependencies: 930 3
-- Name: st_y(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_y(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_y_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_y(geometry) OWNER TO postgres;

--
-- TOC entry 660 (class 1255 OID 7506860)
-- Dependencies: 3 1225
-- Name: st_ymax(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_ymax(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_ymax'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_ymax(box3d) OWNER TO postgres;

--
-- TOC entry 661 (class 1255 OID 7506861)
-- Dependencies: 3 1225
-- Name: st_ymin(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_ymin(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_ymin'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_ymin(box3d) OWNER TO postgres;

--
-- TOC entry 662 (class 1255 OID 7506862)
-- Dependencies: 930 3
-- Name: st_z(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_z(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_z_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_z(geometry) OWNER TO postgres;

--
-- TOC entry 663 (class 1255 OID 7506863)
-- Dependencies: 3 1225
-- Name: st_zmax(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_zmax(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_zmax'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_zmax(box3d) OWNER TO postgres;

--
-- TOC entry 664 (class 1255 OID 7506864)
-- Dependencies: 3 930
-- Name: st_zmflag(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_zmflag(geometry) RETURNS smallint
    AS '$libdir/liblwgeom', 'LWGEOM_zmflag'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_zmflag(geometry) OWNER TO postgres;

--
-- TOC entry 665 (class 1255 OID 7506865)
-- Dependencies: 1225 3
-- Name: st_zmin(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION st_zmin(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_zmin'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_zmin(box3d) OWNER TO postgres;

--
-- TOC entry 666 (class 1255 OID 7506866)
-- Dependencies: 930 930 3
-- Name: startpoint(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION startpoint(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_startpoint_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.startpoint(geometry) OWNER TO postgres;

--
-- TOC entry 667 (class 1255 OID 7506867)
-- Dependencies: 930 3
-- Name: summary(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION summary(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_summary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.summary(geometry) OWNER TO postgres;

--
-- TOC entry 668 (class 1255 OID 7506868)
-- Dependencies: 930 930 3 930
-- Name: symdifference(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION symdifference(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'symdifference'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.symdifference(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 669 (class 1255 OID 7506869)
-- Dependencies: 930 3 930 930
-- Name: symmetricdifference(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION symmetricdifference(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'symdifference'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.symmetricdifference(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 670 (class 1255 OID 7506870)
-- Dependencies: 930 3
-- Name: text(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION text(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_to_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.text(geometry) OWNER TO postgres;

--
-- TOC entry 671 (class 1255 OID 7506871)
-- Dependencies: 3
-- Name: text(boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION text(boolean) RETURNS text
    AS '$libdir/liblwgeom', 'BOOL_to_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.text(boolean) OWNER TO postgres;

--
-- TOC entry 672 (class 1255 OID 7506872)
-- Dependencies: 930 930 3
-- Name: touches(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION touches(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'touches'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.touches(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 673 (class 1255 OID 7506873)
-- Dependencies: 930 930 3
-- Name: transform(geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION transform(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'transform'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.transform(geometry, integer) OWNER TO postgres;

--
-- TOC entry 674 (class 1255 OID 7506874)
-- Dependencies: 930 3 930
-- Name: transform_geometry(geometry, text, text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION transform_geometry(geometry, text, text, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'transform_geom'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.transform_geometry(geometry, text, text, integer) OWNER TO postgres;

--
-- TOC entry 675 (class 1255 OID 7506875)
-- Dependencies: 930 930 3
-- Name: translate(geometry, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION translate(geometry, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1, 1, 0, 0, 0, 1, 0, 0, 0, 1, $2, $3, $4)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.translate(geometry, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 676 (class 1255 OID 7506876)
-- Dependencies: 930 3 930
-- Name: translate(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION translate(geometry, double precision, double precision) RETURNS geometry
    AS $_$SELECT translate($1, $2, $3, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.translate(geometry, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 677 (class 1255 OID 7506877)
-- Dependencies: 930 3 930
-- Name: transscale(geometry, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION transscale(geometry, double precision, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  $4, 0, 0,  0, $5, 0, 
		0, 0, 1,  $2 * $4, $3 * $5, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.transscale(geometry, double precision, double precision, double precision, double precision) OWNER TO postgres;

--
-- TOC entry 678 (class 1255 OID 7506878)
-- Dependencies: 3 933 930
-- Name: unite_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION unite_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'unite_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.unite_garray(geometry[]) OWNER TO postgres;

--
-- TOC entry 679 (class 1255 OID 7506879)
-- Dependencies: 3 1478
-- Name: unlockrows(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION unlockrows(text) RETURNS integer
    AS $_$
DECLARE
	ret int;
BEGIN

	IF NOT LongTransactionsEnabled() THEN
		RAISE EXCEPTION 'Long transaction support disabled, use EnableLongTransaction() to enable.';
	END IF;

	EXECUTE 'DELETE FROM authorization_table where authid = ' ||
		quote_literal($1);

	GET DIAGNOSTICS ret = ROW_COUNT;

	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.unlockrows(text) OWNER TO postgres;

--
-- TOC entry 680 (class 1255 OID 7506880)
-- Dependencies: 3
-- Name: update_geometry_stats(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_geometry_stats() RETURNS text
    AS $$ SELECT 'update_geometry_stats() has been obsoleted. Statistics are automatically built running the ANALYZE command'::text$$
    LANGUAGE sql;


ALTER FUNCTION public.update_geometry_stats() OWNER TO postgres;

--
-- TOC entry 681 (class 1255 OID 7506881)
-- Dependencies: 3
-- Name: update_geometry_stats(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_geometry_stats(character varying, character varying) RETURNS text
    AS $$SELECT update_geometry_stats();$$
    LANGUAGE sql;


ALTER FUNCTION public.update_geometry_stats(character varying, character varying) OWNER TO postgres;

--
-- TOC entry 682 (class 1255 OID 7506882)
-- Dependencies: 1478 3
-- Name: updategeometrysrid(character varying, character varying, character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION updategeometrysrid(character varying, character varying, character varying, character varying, integer) RETURNS text
    AS $_$
DECLARE
	catalog_name alias for $1; 
	schema_name alias for $2;
	table_name alias for $3;
	column_name alias for $4;
	new_srid alias for $5;
	myrec RECORD;
	okay boolean;
	cname varchar;
	real_schema name;

BEGIN



	-- Find, check or fix schema_name
	IF ( schema_name != '' ) THEN
		okay = 'f';

		FOR myrec IN SELECT nspname FROM pg_namespace WHERE text(nspname) = schema_name LOOP
			okay := 't';
		END LOOP;

		IF ( okay <> 't' ) THEN
			RAISE EXCEPTION 'Invalid schema name';
		ELSE
			real_schema = schema_name;
		END IF;
	ELSE
		SELECT INTO real_schema current_schema()::text;
	END IF;


 	-- Find out if the column is in the geometry_columns table
	okay = 'f';
	FOR myrec IN SELECT * from geometry_columns where f_table_schema = text(real_schema) and f_table_name = table_name and f_geometry_column = column_name LOOP
		okay := 't';
	END LOOP; 
	IF (okay <> 't') THEN 
		RAISE EXCEPTION 'column not found in geometry_columns table';
		RETURN 'f';
	END IF;

	-- Update ref from geometry_columns table
	EXECUTE 'UPDATE geometry_columns SET SRID = ' || new_srid::text || 
		' where f_table_schema = ' ||
		quote_literal(real_schema) || ' and f_table_name = ' ||
		quote_literal(table_name)  || ' and f_geometry_column = ' ||
		quote_literal(column_name);
	
	-- Make up constraint name
	cname = 'enforce_srid_'  || column_name;

	-- Drop enforce_srid constraint



	EXECUTE 'ALTER TABLE ' || quote_ident(real_schema) ||
		'.' || quote_ident(table_name) ||

		' DROP constraint ' || quote_ident(cname);

	-- Update geometries SRID



	EXECUTE 'UPDATE ' || quote_ident(real_schema) ||
		'.' || quote_ident(table_name) ||

		' SET ' || quote_ident(column_name) ||
		' = setSRID(' || quote_ident(column_name) ||
		', ' || new_srid::text || ')';

	-- Reset enforce_srid constraint



	EXECUTE 'ALTER TABLE ' || quote_ident(real_schema) ||
		'.' || quote_ident(table_name) ||

		' ADD constraint ' || quote_ident(cname) ||
		' CHECK (srid(' || quote_ident(column_name) ||
		') = ' || new_srid::text || ')';

	RETURN real_schema || '.' || table_name || '.' || column_name ||' SRID changed to ' || new_srid::text;
	
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.updategeometrysrid(character varying, character varying, character varying, character varying, integer) OWNER TO postgres;

--
-- TOC entry 683 (class 1255 OID 7506883)
-- Dependencies: 1478 3
-- Name: updategeometrysrid(character varying, character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION updategeometrysrid(character varying, character varying, character varying, integer) RETURNS text
    AS $_$
DECLARE
	ret  text;
BEGIN
	SELECT UpdateGeometrySRID('',$1,$2,$3,$4) into ret;
	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.updategeometrysrid(character varying, character varying, character varying, integer) OWNER TO postgres;

--
-- TOC entry 684 (class 1255 OID 7506884)
-- Dependencies: 3 1478
-- Name: updategeometrysrid(character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION updategeometrysrid(character varying, character varying, integer) RETURNS text
    AS $_$
DECLARE
	ret  text;
BEGIN
	SELECT UpdateGeometrySRID('','',$1,$2,$3) into ret;
	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.updategeometrysrid(character varying, character varying, integer) OWNER TO postgres;

--
-- TOC entry 685 (class 1255 OID 7506885)
-- Dependencies: 3 1229
-- Name: width(chip); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION width(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getWidth'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.width(chip) OWNER TO postgres;

--
-- TOC entry 686 (class 1255 OID 7506886)
-- Dependencies: 930 3 930
-- Name: within(geometry, geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION within(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'within'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.within(geometry, geometry) OWNER TO postgres;

--
-- TOC entry 687 (class 1255 OID 7506887)
-- Dependencies: 3 930
-- Name: x(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION x(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_x_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.x(geometry) OWNER TO postgres;

--
-- TOC entry 688 (class 1255 OID 7506888)
-- Dependencies: 1225 3
-- Name: xmax(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION xmax(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_xmax'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.xmax(box3d) OWNER TO postgres;

--
-- TOC entry 689 (class 1255 OID 7506889)
-- Dependencies: 1225 3
-- Name: xmin(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION xmin(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_xmin'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.xmin(box3d) OWNER TO postgres;

--
-- TOC entry 690 (class 1255 OID 7506890)
-- Dependencies: 930 3
-- Name: y(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION y(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_y_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.y(geometry) OWNER TO postgres;

--
-- TOC entry 691 (class 1255 OID 7506891)
-- Dependencies: 1225 3
-- Name: ymax(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION ymax(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_ymax'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.ymax(box3d) OWNER TO postgres;

--
-- TOC entry 692 (class 1255 OID 7506892)
-- Dependencies: 1225 3
-- Name: ymin(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION ymin(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_ymin'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.ymin(box3d) OWNER TO postgres;

--
-- TOC entry 693 (class 1255 OID 7506893)
-- Dependencies: 930 3
-- Name: z(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION z(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_z_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.z(geometry) OWNER TO postgres;

--
-- TOC entry 694 (class 1255 OID 7506894)
-- Dependencies: 3 1225
-- Name: zmax(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION zmax(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_zmax'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.zmax(box3d) OWNER TO postgres;

--
-- TOC entry 695 (class 1255 OID 7506895)
-- Dependencies: 3 930
-- Name: zmflag(geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION zmflag(geometry) RETURNS smallint
    AS '$libdir/liblwgeom', 'LWGEOM_zmflag'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.zmflag(geometry) OWNER TO postgres;

--
-- TOC entry 696 (class 1255 OID 7506896)
-- Dependencies: 3 1225
-- Name: zmin(box3d); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION zmin(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_zmin'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.zmin(box3d) OWNER TO postgres;

--
-- TOC entry 1479 (class 1255 OID 7506897)
-- Dependencies: 930 3 933 478
-- Name: accum(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE accum(geometry) (
    SFUNC = st_geom_accum,
    STYPE = geometry[]
);


ALTER AGGREGATE public.accum(geometry) OWNER TO postgres;

--
-- TOC entry 1480 (class 1255 OID 7506898)
-- Dependencies: 432 930 478 930 3
-- Name: collect(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE collect(geometry) (
    SFUNC = st_geom_accum,
    STYPE = geometry[],
    FINALFUNC = st_collect_garray
);


ALTER AGGREGATE public.collect(geometry) OWNER TO postgres;

--
-- TOC entry 1481 (class 1255 OID 7506899)
-- Dependencies: 930 434 3 1221
-- Name: extent(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE extent(geometry) (
    SFUNC = public.st_combine_bbox,
    STYPE = box2d
);


ALTER AGGREGATE public.extent(geometry) OWNER TO postgres;

--
-- TOC entry 1482 (class 1255 OID 7506900)
-- Dependencies: 120 3 1225 930
-- Name: extent3d(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE extent3d(geometry) (
    SFUNC = public.combine_bbox,
    STYPE = box3d
);


ALTER AGGREGATE public.extent3d(geometry) OWNER TO postgres;

--
-- TOC entry 1483 (class 1255 OID 7506901)
-- Dependencies: 930 3 930 167 651
-- Name: geomunion(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE geomunion(geometry) (
    SFUNC = geom_accum,
    STYPE = geometry[],
    FINALFUNC = st_unite_garray
);


ALTER AGGREGATE public.geomunion(geometry) OWNER TO postgres;

--
-- TOC entry 1484 (class 1255 OID 7506902)
-- Dependencies: 3 930 167 930 265
-- Name: makeline(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE makeline(geometry) (
    SFUNC = geom_accum,
    STYPE = geometry[],
    FINALFUNC = makeline_garray
);


ALTER AGGREGATE public.makeline(geometry) OWNER TO postgres;

--
-- TOC entry 1485 (class 1255 OID 7506903)
-- Dependencies: 431 3 930 930
-- Name: memcollect(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE memcollect(geometry) (
    SFUNC = public.st_collect,
    STYPE = geometry
);


ALTER AGGREGATE public.memcollect(geometry) OWNER TO postgres;

--
-- TOC entry 1486 (class 1255 OID 7506904)
-- Dependencies: 209 930 930 3
-- Name: memgeomunion(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE memgeomunion(geometry) (
    SFUNC = public.geomunion,
    STYPE = geometry
);


ALTER AGGREGATE public.memgeomunion(geometry) OWNER TO postgres;

--
-- TOC entry 1487 (class 1255 OID 7506905)
-- Dependencies: 930 3 930 167 325
-- Name: polygonize(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE polygonize(geometry) (
    SFUNC = geom_accum,
    STYPE = geometry[],
    FINALFUNC = polygonize_garray
);


ALTER AGGREGATE public.polygonize(geometry) OWNER TO postgres;

--
-- TOC entry 1488 (class 1255 OID 7506906)
-- Dependencies: 930 933 478 3
-- Name: st_accum(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE st_accum(geometry) (
    SFUNC = st_geom_accum,
    STYPE = geometry[]
);


ALTER AGGREGATE public.st_accum(geometry) OWNER TO postgres;

--
-- TOC entry 1489 (class 1255 OID 7506907)
-- Dependencies: 930 930 432 3 478
-- Name: st_collect(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE st_collect(geometry) (
    SFUNC = st_geom_accum,
    STYPE = geometry[],
    FINALFUNC = st_collect_garray
);


ALTER AGGREGATE public.st_collect(geometry) OWNER TO postgres;

--
-- TOC entry 1490 (class 1255 OID 7506908)
-- Dependencies: 434 1221 3 930
-- Name: st_extent(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE st_extent(geometry) (
    SFUNC = public.st_combine_bbox,
    STYPE = box2d
);


ALTER AGGREGATE public.st_extent(geometry) OWNER TO postgres;

--
-- TOC entry 1491 (class 1255 OID 7506909)
-- Dependencies: 930 3 435 1225
-- Name: st_extent3d(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE st_extent3d(geometry) (
    SFUNC = public.st_combine_bbox,
    STYPE = box3d
);


ALTER AGGREGATE public.st_extent3d(geometry) OWNER TO postgres;

--
-- TOC entry 1492 (class 1255 OID 7506910)
-- Dependencies: 167 930 3 551 930
-- Name: st_makeline(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE st_makeline(geometry) (
    SFUNC = geom_accum,
    STYPE = geometry[],
    FINALFUNC = st_makeline_garray
);


ALTER AGGREGATE public.st_makeline(geometry) OWNER TO postgres;

--
-- TOC entry 1493 (class 1255 OID 7506911)
-- Dependencies: 431 930 930 3
-- Name: st_memcollect(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE st_memcollect(geometry) (
    SFUNC = public.st_collect,
    STYPE = geometry
);


ALTER AGGREGATE public.st_memcollect(geometry) OWNER TO postgres;

--
-- TOC entry 1494 (class 1255 OID 7506912)
-- Dependencies: 3 650 930 930
-- Name: st_memunion(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE st_memunion(geometry) (
    SFUNC = public.st_union,
    STYPE = geometry
);


ALTER AGGREGATE public.st_memunion(geometry) OWNER TO postgres;

--
-- TOC entry 1495 (class 1255 OID 7506913)
-- Dependencies: 930 3 613 478 930
-- Name: st_polygonize(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE st_polygonize(geometry) (
    SFUNC = st_geom_accum,
    STYPE = geometry[],
    FINALFUNC = st_polygonize_garray
);


ALTER AGGREGATE public.st_polygonize(geometry) OWNER TO postgres;

--
-- TOC entry 1496 (class 1255 OID 7506914)
-- Dependencies: 930 478 3 930 651
-- Name: st_union(geometry); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE st_union(geometry) (
    SFUNC = st_geom_accum,
    STYPE = geometry[],
    FINALFUNC = st_unite_garray
);


ALTER AGGREGATE public.st_union(geometry) OWNER TO postgres;

--
-- TOC entry 2199 (class 2617 OID 7506915)
-- Dependencies: 615 930 3 614 501 930
-- Name: &&; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR && (
    PROCEDURE = st_geometry_overlap,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = &&,
    RESTRICT = st_postgis_gist_sel,
    JOIN = st_postgis_gist_joinsel
);


ALTER OPERATOR public.&& (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2202 (class 2617 OID 7506917)
-- Dependencies: 3 930 930 502
-- Name: &<; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR &< (
    PROCEDURE = st_geometry_overleft,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = &>,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.&< (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2205 (class 2617 OID 7506919)
-- Dependencies: 500 3 930 930
-- Name: &<|; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR &<| (
    PROCEDURE = st_geometry_overbelow,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = |&>,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.&<| (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2201 (class 2617 OID 7506916)
-- Dependencies: 3 930 930 503
-- Name: &>; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR &> (
    PROCEDURE = st_geometry_overright,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = &<,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.&> (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2210 (class 2617 OID 7506922)
-- Dependencies: 498 3 930 930
-- Name: <; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR < (
    PROCEDURE = st_geometry_lt,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = >,
    NEGATOR = >=,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.< (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2204 (class 2617 OID 7506924)
-- Dependencies: 930 497 930 3
-- Name: <<; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR << (
    PROCEDURE = st_geometry_left,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = >>,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.<< (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2207 (class 2617 OID 7506926)
-- Dependencies: 489 3 930 930
-- Name: <<|; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR <<| (
    PROCEDURE = st_geometry_below,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = |>>,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.<<| (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2208 (class 2617 OID 7506927)
-- Dependencies: 930 3 930 496
-- Name: <=; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR <= (
    PROCEDURE = st_geometry_le,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = >=,
    NEGATOR = >,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.<= (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2211 (class 2617 OID 7506928)
-- Dependencies: 3 493 930 930
-- Name: =; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR = (
    PROCEDURE = st_geometry_eq,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = =,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.= (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2209 (class 2617 OID 7506920)
-- Dependencies: 495 3 930 930
-- Name: >; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR > (
    PROCEDURE = st_geometry_gt,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = <,
    NEGATOR = <=,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.> (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2200 (class 2617 OID 7506921)
-- Dependencies: 494 3 930 930
-- Name: >=; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR >= (
    PROCEDURE = st_geometry_ge,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = <=,
    NEGATOR = <,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.>= (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2203 (class 2617 OID 7506923)
-- Dependencies: 3 930 930 504
-- Name: >>; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR >> (
    PROCEDURE = st_geometry_right,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = <<,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.>> (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2213 (class 2617 OID 7506930)
-- Dependencies: 930 492 930 3
-- Name: @; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR @ (
    PROCEDURE = st_geometry_contained,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = ~,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.@ (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2214 (class 2617 OID 7506918)
-- Dependencies: 930 3 930 499
-- Name: |&>; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR |&> (
    PROCEDURE = st_geometry_overabove,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = &<|,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.|&> (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2206 (class 2617 OID 7506925)
-- Dependencies: 488 930 930 3
-- Name: |>>; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR |>> (
    PROCEDURE = st_geometry_above,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = <<|,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.|>> (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2212 (class 2617 OID 7506929)
-- Dependencies: 491 3 930 930
-- Name: ~; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR ~ (
    PROCEDURE = st_geometry_contain,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = @,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.~ (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2215 (class 2617 OID 7506931)
-- Dependencies: 3 930 505 930
-- Name: ~=; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR ~= (
    PROCEDURE = st_geometry_same,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = ~=,
    RESTRICT = eqsel,
    JOIN = eqjoinsel
);


ALTER OPERATOR public.~= (geometry, geometry) OWNER TO postgres;

--
-- TOC entry 2328 (class 2616 OID 7506933)
-- Dependencies: 930 2437 3
-- Name: btree_geometry_ops; Type: OPERATOR CLASS; Schema: public; Owner: postgres
--

CREATE OPERATOR CLASS btree_geometry_ops
    DEFAULT FOR TYPE geometry USING btree AS
    OPERATOR 1 <(geometry,geometry) ,
    OPERATOR 2 <=(geometry,geometry) ,
    OPERATOR 3 =(geometry,geometry) ,
    OPERATOR 4 >=(geometry,geometry) ,
    OPERATOR 5 >(geometry,geometry) ,
    FUNCTION 1 geometry_cmp(geometry,geometry);


ALTER OPERATOR CLASS public.btree_geometry_ops USING btree OWNER TO postgres;

--
-- TOC entry 2329 (class 2616 OID 7506941)
-- Dependencies: 2438 3 1221 930
-- Name: gist_geometry_ops; Type: OPERATOR CLASS; Schema: public; Owner: postgres
--

CREATE OPERATOR CLASS gist_geometry_ops
    DEFAULT FOR TYPE geometry USING gist AS
    STORAGE box2d ,
    OPERATOR 1 <<(geometry,geometry) RECHECK ,
    OPERATOR 2 &<(geometry,geometry) RECHECK ,
    OPERATOR 3 &&(geometry,geometry) RECHECK ,
    OPERATOR 4 &>(geometry,geometry) RECHECK ,
    OPERATOR 5 >>(geometry,geometry) RECHECK ,
    OPERATOR 6 ~=(geometry,geometry) RECHECK ,
    OPERATOR 7 ~(geometry,geometry) RECHECK ,
    OPERATOR 8 @(geometry,geometry) RECHECK ,
    OPERATOR 9 &<|(geometry,geometry) RECHECK ,
    OPERATOR 10 <<|(geometry,geometry) RECHECK ,
    OPERATOR 11 |>>(geometry,geometry) RECHECK ,
    OPERATOR 12 |&>(geometry,geometry) RECHECK ,
    FUNCTION 1 lwgeom_gist_consistent(internal,geometry,integer) ,
    FUNCTION 2 lwgeom_gist_union(bytea,internal) ,
    FUNCTION 3 lwgeom_gist_compress(internal) ,
    FUNCTION 4 lwgeom_gist_decompress(internal) ,
    FUNCTION 5 lwgeom_gist_penalty(internal,internal,internal) ,
    FUNCTION 6 lwgeom_gist_picksplit(internal,internal) ,
    FUNCTION 7 lwgeom_gist_same(box2d,box2d,internal);


ALTER OPERATOR CLASS public.gist_geometry_ops USING gist OWNER TO postgres;

SET search_path = pg_catalog;

--
-- TOC entry 3209 (class 2605 OID 7506961)
-- Dependencies: 422 1221 1225 422
-- Name: CAST (public.box2d AS public.box3d); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.box2d AS public.box3d) WITH FUNCTION public.st_box3d(public.box2d) AS IMPLICIT;


--
-- TOC entry 3208 (class 2605 OID 7506962)
-- Dependencies: 483 483 1221 930
-- Name: CAST (public.box2d AS public.geometry); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.box2d AS public.geometry) WITH FUNCTION public.st_geometry(public.box2d) AS IMPLICIT;


--
-- TOC entry 3210 (class 2605 OID 7506963)
-- Dependencies: 409 409 1225
-- Name: CAST (public.box3d AS box); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.box3d AS box) WITH FUNCTION public.st_box(public.box3d) AS IMPLICIT;


--
-- TOC entry 3212 (class 2605 OID 7506964)
-- Dependencies: 411 1225 1221 411
-- Name: CAST (public.box3d AS public.box2d); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.box3d AS public.box2d) WITH FUNCTION public.st_box2d(public.box3d) AS IMPLICIT;


--
-- TOC entry 3211 (class 2605 OID 7506965)
-- Dependencies: 484 484 1225 930
-- Name: CAST (public.box3d AS public.geometry); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.box3d AS public.geometry) WITH FUNCTION public.st_geometry(public.box3d) AS IMPLICIT;


--
-- TOC entry 3014 (class 2605 OID 7506966)
-- Dependencies: 487 487 930
-- Name: CAST (bytea AS public.geometry); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (bytea AS public.geometry) WITH FUNCTION public.st_geometry(bytea) AS IMPLICIT;


--
-- TOC entry 3213 (class 2605 OID 7506967)
-- Dependencies: 486 486 930 1229
-- Name: CAST (public.chip AS public.geometry); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.chip AS public.geometry) WITH FUNCTION public.st_geometry(public.chip) AS IMPLICIT;


--
-- TOC entry 3205 (class 2605 OID 7506968)
-- Dependencies: 408 408 930
-- Name: CAST (public.geometry AS box); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.geometry AS box) WITH FUNCTION public.st_box(public.geometry) AS IMPLICIT;


--
-- TOC entry 3206 (class 2605 OID 7506969)
-- Dependencies: 410 930 410 1221
-- Name: CAST (public.geometry AS public.box2d); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.geometry AS public.box2d) WITH FUNCTION public.st_box2d(public.geometry) AS IMPLICIT;


--
-- TOC entry 3207 (class 2605 OID 7506970)
-- Dependencies: 421 930 421 1225
-- Name: CAST (public.geometry AS public.box3d); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.geometry AS public.box3d) WITH FUNCTION public.st_box3d(public.geometry) AS IMPLICIT;


--
-- TOC entry 3203 (class 2605 OID 7506971)
-- Dependencies: 428 428 930
-- Name: CAST (public.geometry AS bytea); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.geometry AS bytea) WITH FUNCTION public.st_bytea(public.geometry) AS IMPLICIT;


--
-- TOC entry 3204 (class 2605 OID 7506972)
-- Dependencies: 643 643 930
-- Name: CAST (public.geometry AS text); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.geometry AS text) WITH FUNCTION public.st_text(public.geometry) AS IMPLICIT;


--
-- TOC entry 3080 (class 2605 OID 7506973)
-- Dependencies: 485 930 485
-- Name: CAST (text AS public.geometry); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (text AS public.geometry) WITH FUNCTION public.st_geometry(text) AS IMPLICIT;


SET search_path = public, pg_catalog;

--
-- TOC entry 2785 (class 1259 OID 7506974)
-- Dependencies: 3 2689
-- Name: ap_darstellung_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ap_darstellung_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ap_darstellung_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3944 (class 0 OID 0)
-- Dependencies: 2785
-- Name: ap_darstellung_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ap_darstellung_ogc_fid_seq OWNED BY ap_darstellung.ogc_fid;


--
-- TOC entry 2786 (class 1259 OID 7506976)
-- Dependencies: 2690 3
-- Name: ap_lpo_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ap_lpo_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ap_lpo_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3945 (class 0 OID 0)
-- Dependencies: 2786
-- Name: ap_lpo_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ap_lpo_ogc_fid_seq OWNED BY ap_lpo.ogc_fid;


--
-- TOC entry 2787 (class 1259 OID 7506978)
-- Dependencies: 2691 3
-- Name: ap_lto_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ap_lto_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ap_lto_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3946 (class 0 OID 0)
-- Dependencies: 2787
-- Name: ap_lto_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ap_lto_ogc_fid_seq OWNED BY ap_lto.ogc_fid;


--
-- TOC entry 2788 (class 1259 OID 7506980)
-- Dependencies: 2692 3
-- Name: ap_ppo_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ap_ppo_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ap_ppo_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3947 (class 0 OID 0)
-- Dependencies: 2788
-- Name: ap_ppo_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ap_ppo_ogc_fid_seq OWNED BY ap_ppo.ogc_fid;


--
-- TOC entry 2789 (class 1259 OID 7506982)
-- Dependencies: 2693 3
-- Name: ap_pto_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ap_pto_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ap_pto_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3948 (class 0 OID 0)
-- Dependencies: 2789
-- Name: ap_pto_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ap_pto_ogc_fid_seq OWNED BY ap_pto.ogc_fid;


--
-- TOC entry 2790 (class 1259 OID 7506984)
-- Dependencies: 3 2694
-- Name: ax_anschrift_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_anschrift_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_anschrift_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3949 (class 0 OID 0)
-- Dependencies: 2790
-- Name: ax_anschrift_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_anschrift_ogc_fid_seq OWNED BY ax_anschrift.ogc_fid;


--
-- TOC entry 2791 (class 1259 OID 7506986)
-- Dependencies: 2695 3
-- Name: ax_aufnahmepunkt_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_aufnahmepunkt_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_aufnahmepunkt_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3950 (class 0 OID 0)
-- Dependencies: 2791
-- Name: ax_aufnahmepunkt_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_aufnahmepunkt_ogc_fid_seq OWNED BY ax_aufnahmepunkt.ogc_fid;


--
-- TOC entry 2792 (class 1259 OID 7506988)
-- Dependencies: 3 2696
-- Name: ax_bahnverkehr_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_bahnverkehr_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_bahnverkehr_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3951 (class 0 OID 0)
-- Dependencies: 2792
-- Name: ax_bahnverkehr_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_bahnverkehr_ogc_fid_seq OWNED BY ax_bahnverkehr.ogc_fid;


--
-- TOC entry 2793 (class 1259 OID 7506990)
-- Dependencies: 2697 3
-- Name: ax_bauraumoderbodenordnungsrecht_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_bauraumoderbodenordnungsrecht_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_bauraumoderbodenordnungsrecht_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3952 (class 0 OID 0)
-- Dependencies: 2793
-- Name: ax_bauraumoderbodenordnungsrecht_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_bauraumoderbodenordnungsrecht_ogc_fid_seq OWNED BY ax_bauraumoderbodenordnungsrecht.ogc_fid;


--
-- TOC entry 2794 (class 1259 OID 7506992)
-- Dependencies: 3 2698
-- Name: ax_bauteil_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_bauteil_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_bauteil_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3953 (class 0 OID 0)
-- Dependencies: 2794
-- Name: ax_bauteil_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_bauteil_ogc_fid_seq OWNED BY ax_bauteil.ogc_fid;


--
-- TOC entry 2795 (class 1259 OID 7506994)
-- Dependencies: 3 2699
-- Name: ax_bauwerkimgewaesserbereich_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_bauwerkimgewaesserbereich_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_bauwerkimgewaesserbereich_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3954 (class 0 OID 0)
-- Dependencies: 2795
-- Name: ax_bauwerkimgewaesserbereich_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_bauwerkimgewaesserbereich_ogc_fid_seq OWNED BY ax_bauwerkimgewaesserbereich.ogc_fid;


--
-- TOC entry 2796 (class 1259 OID 7506996)
-- Dependencies: 3 2700
-- Name: ax_bauwerkimverkehrsbereich_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_bauwerkimverkehrsbereich_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_bauwerkimverkehrsbereich_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3955 (class 0 OID 0)
-- Dependencies: 2796
-- Name: ax_bauwerkimverkehrsbereich_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_bauwerkimverkehrsbereich_ogc_fid_seq OWNED BY ax_bauwerkimverkehrsbereich.ogc_fid;


--
-- TOC entry 2797 (class 1259 OID 7506998)
-- Dependencies: 3 2701
-- Name: ax_bauwerkoderanlagefuerindustrieundgewerbe_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_bauwerkoderanlagefuerindustrieundgewerbe_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_bauwerkoderanlagefuerindustrieundgewerbe_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3956 (class 0 OID 0)
-- Dependencies: 2797
-- Name: ax_bauwerkoderanlagefuerindustrieundgewerbe_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_bauwerkoderanlagefuerindustrieundgewerbe_ogc_fid_seq OWNED BY ax_bauwerkoderanlagefuerindustrieundgewerbe.ogc_fid;


--
-- TOC entry 2798 (class 1259 OID 7507000)
-- Dependencies: 2702 3
-- Name: ax_bauwerkoderanlagefuersportfreizeitunderholung_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_bauwerkoderanlagefuersportfreizeitunderholung_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_bauwerkoderanlagefuersportfreizeitunderholung_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3957 (class 0 OID 0)
-- Dependencies: 2798
-- Name: ax_bauwerkoderanlagefuersportfreizeitunderholung_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_bauwerkoderanlagefuersportfreizeitunderholung_ogc_fid_seq OWNED BY ax_bauwerkoderanlagefuersportfreizeitunderholung.ogc_fid;


--
-- TOC entry 2902 (class 1259 OID 15116065)
-- Dependencies: 2903 3
-- Name: ax_bergbaubetrieb_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_bergbaubetrieb_ogc_fid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_bergbaubetrieb_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3958 (class 0 OID 0)
-- Dependencies: 2902
-- Name: ax_bergbaubetrieb_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_bergbaubetrieb_ogc_fid_seq OWNED BY ax_bergbaubetrieb.ogc_fid;


--
-- TOC entry 2799 (class 1259 OID 7507002)
-- Dependencies: 3 2703
-- Name: ax_besondereflurstuecksgrenze_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_besondereflurstuecksgrenze_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_besondereflurstuecksgrenze_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3959 (class 0 OID 0)
-- Dependencies: 2799
-- Name: ax_besondereflurstuecksgrenze_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_besondereflurstuecksgrenze_ogc_fid_seq OWNED BY ax_besondereflurstuecksgrenze.ogc_fid;


--
-- TOC entry 2800 (class 1259 OID 7507004)
-- Dependencies: 3 2704
-- Name: ax_besonderegebaeudelinie_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_besonderegebaeudelinie_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_besonderegebaeudelinie_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3960 (class 0 OID 0)
-- Dependencies: 2800
-- Name: ax_besonderegebaeudelinie_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_besonderegebaeudelinie_ogc_fid_seq OWNED BY ax_besonderegebaeudelinie.ogc_fid;


--
-- TOC entry 2801 (class 1259 OID 7507006)
-- Dependencies: 2705 3
-- Name: ax_besondererbauwerkspunkt_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_besondererbauwerkspunkt_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_besondererbauwerkspunkt_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3961 (class 0 OID 0)
-- Dependencies: 2801
-- Name: ax_besondererbauwerkspunkt_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_besondererbauwerkspunkt_ogc_fid_seq OWNED BY ax_besondererbauwerkspunkt.ogc_fid;


--
-- TOC entry 2802 (class 1259 OID 7507008)
-- Dependencies: 2706 3
-- Name: ax_besonderergebaeudepunkt_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_besonderergebaeudepunkt_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_besonderergebaeudepunkt_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3962 (class 0 OID 0)
-- Dependencies: 2802
-- Name: ax_besonderergebaeudepunkt_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_besonderergebaeudepunkt_ogc_fid_seq OWNED BY ax_besonderergebaeudepunkt.ogc_fid;


--
-- TOC entry 2803 (class 1259 OID 7507010)
-- Dependencies: 3 2707
-- Name: ax_besonderertopographischerpunkt_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_besonderertopographischerpunkt_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_besonderertopographischerpunkt_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3963 (class 0 OID 0)
-- Dependencies: 2803
-- Name: ax_besonderertopographischerpunkt_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_besonderertopographischerpunkt_ogc_fid_seq OWNED BY ax_besonderertopographischerpunkt.ogc_fid;


--
-- TOC entry 2804 (class 1259 OID 7507012)
-- Dependencies: 2708 3
-- Name: ax_bodenschaetzung_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_bodenschaetzung_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_bodenschaetzung_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3964 (class 0 OID 0)
-- Dependencies: 2804
-- Name: ax_bodenschaetzung_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_bodenschaetzung_ogc_fid_seq OWNED BY ax_bodenschaetzung.ogc_fid;


--
-- TOC entry 2805 (class 1259 OID 7507014)
-- Dependencies: 3 2709
-- Name: ax_boeschungkliff_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_boeschungkliff_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_boeschungkliff_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3965 (class 0 OID 0)
-- Dependencies: 2805
-- Name: ax_boeschungkliff_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_boeschungkliff_ogc_fid_seq OWNED BY ax_boeschungkliff.ogc_fid;


--
-- TOC entry 2806 (class 1259 OID 7507016)
-- Dependencies: 2710 3
-- Name: ax_boeschungsflaeche_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_boeschungsflaeche_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_boeschungsflaeche_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3966 (class 0 OID 0)
-- Dependencies: 2806
-- Name: ax_boeschungsflaeche_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_boeschungsflaeche_ogc_fid_seq OWNED BY ax_boeschungsflaeche.ogc_fid;


--
-- TOC entry 2807 (class 1259 OID 7507018)
-- Dependencies: 3 2711
-- Name: ax_buchungsblatt_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_buchungsblatt_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_buchungsblatt_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3967 (class 0 OID 0)
-- Dependencies: 2807
-- Name: ax_buchungsblatt_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_buchungsblatt_ogc_fid_seq OWNED BY ax_buchungsblatt.ogc_fid;


--
-- TOC entry 2808 (class 1259 OID 7507020)
-- Dependencies: 2712 3
-- Name: ax_buchungsblattbezirk_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_buchungsblattbezirk_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_buchungsblattbezirk_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3968 (class 0 OID 0)
-- Dependencies: 2808
-- Name: ax_buchungsblattbezirk_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_buchungsblattbezirk_ogc_fid_seq OWNED BY ax_buchungsblattbezirk.ogc_fid;


--
-- TOC entry 2809 (class 1259 OID 7507022)
-- Dependencies: 3 2713
-- Name: ax_buchungsstelle_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_buchungsstelle_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_buchungsstelle_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3969 (class 0 OID 0)
-- Dependencies: 2809
-- Name: ax_buchungsstelle_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_buchungsstelle_ogc_fid_seq OWNED BY ax_buchungsstelle.ogc_fid;


--
-- TOC entry 2810 (class 1259 OID 7507024)
-- Dependencies: 3 2714
-- Name: ax_bundesland_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_bundesland_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_bundesland_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3970 (class 0 OID 0)
-- Dependencies: 2810
-- Name: ax_bundesland_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_bundesland_ogc_fid_seq OWNED BY ax_bundesland.ogc_fid;


--
-- TOC entry 2811 (class 1259 OID 7507026)
-- Dependencies: 2715 3
-- Name: ax_dammwalldeich_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_dammwalldeich_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_dammwalldeich_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3971 (class 0 OID 0)
-- Dependencies: 2811
-- Name: ax_dammwalldeich_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_dammwalldeich_ogc_fid_seq OWNED BY ax_dammwalldeich.ogc_fid;


--
-- TOC entry 2812 (class 1259 OID 7507028)
-- Dependencies: 3 2716
-- Name: ax_dienststelle_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_dienststelle_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_dienststelle_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3972 (class 0 OID 0)
-- Dependencies: 2812
-- Name: ax_dienststelle_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_dienststelle_ogc_fid_seq OWNED BY ax_dienststelle.ogc_fid;


--
-- TOC entry 2813 (class 1259 OID 7507030)
-- Dependencies: 3 2717
-- Name: ax_felsenfelsblockfelsnadel_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_felsenfelsblockfelsnadel_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_felsenfelsblockfelsnadel_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3973 (class 0 OID 0)
-- Dependencies: 2813
-- Name: ax_felsenfelsblockfelsnadel_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_felsenfelsblockfelsnadel_ogc_fid_seq OWNED BY ax_felsenfelsblockfelsnadel.ogc_fid;


--
-- TOC entry 2814 (class 1259 OID 7507032)
-- Dependencies: 3 2718
-- Name: ax_firstlinie_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_firstlinie_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_firstlinie_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3974 (class 0 OID 0)
-- Dependencies: 2814
-- Name: ax_firstlinie_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_firstlinie_ogc_fid_seq OWNED BY ax_firstlinie.ogc_fid;


--
-- TOC entry 2815 (class 1259 OID 7507034)
-- Dependencies: 3 2719
-- Name: ax_flaechebesondererfunktionalerpraegung_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_flaechebesondererfunktionalerpraegung_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_flaechebesondererfunktionalerpraegung_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3975 (class 0 OID 0)
-- Dependencies: 2815
-- Name: ax_flaechebesondererfunktionalerpraegung_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_flaechebesondererfunktionalerpraegung_ogc_fid_seq OWNED BY ax_flaechebesondererfunktionalerpraegung.ogc_fid;


--
-- TOC entry 2816 (class 1259 OID 7507036)
-- Dependencies: 3 2720
-- Name: ax_flaechegemischternutzung_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_flaechegemischternutzung_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_flaechegemischternutzung_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3976 (class 0 OID 0)
-- Dependencies: 2816
-- Name: ax_flaechegemischternutzung_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_flaechegemischternutzung_ogc_fid_seq OWNED BY ax_flaechegemischternutzung.ogc_fid;


--
-- TOC entry 2817 (class 1259 OID 7507038)
-- Dependencies: 2721 3
-- Name: ax_fliessgewaesser_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_fliessgewaesser_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_fliessgewaesser_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3977 (class 0 OID 0)
-- Dependencies: 2817
-- Name: ax_fliessgewaesser_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_fliessgewaesser_ogc_fid_seq OWNED BY ax_fliessgewaesser.ogc_fid;


--
-- TOC entry 2818 (class 1259 OID 7507040)
-- Dependencies: 3 2722
-- Name: ax_flugverkehr_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_flugverkehr_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_flugverkehr_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3978 (class 0 OID 0)
-- Dependencies: 2818
-- Name: ax_flugverkehr_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_flugverkehr_ogc_fid_seq OWNED BY ax_flugverkehr.ogc_fid;


--
-- TOC entry 2819 (class 1259 OID 7507042)
-- Dependencies: 3 2723
-- Name: ax_flugverkehrsanlage_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_flugverkehrsanlage_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_flugverkehrsanlage_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3979 (class 0 OID 0)
-- Dependencies: 2819
-- Name: ax_flugverkehrsanlage_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_flugverkehrsanlage_ogc_fid_seq OWNED BY ax_flugverkehrsanlage.ogc_fid;


--
-- TOC entry 2820 (class 1259 OID 7507044)
-- Dependencies: 2724 3
-- Name: ax_flurstueck_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_flurstueck_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_flurstueck_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3980 (class 0 OID 0)
-- Dependencies: 2820
-- Name: ax_flurstueck_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_flurstueck_ogc_fid_seq OWNED BY ax_flurstueck.ogc_fid;


--
-- TOC entry 2821 (class 1259 OID 7507046)
-- Dependencies: 2725 3
-- Name: ax_friedhof_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_friedhof_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_friedhof_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3981 (class 0 OID 0)
-- Dependencies: 2821
-- Name: ax_friedhof_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_friedhof_ogc_fid_seq OWNED BY ax_friedhof.ogc_fid;


--
-- TOC entry 2822 (class 1259 OID 7507048)
-- Dependencies: 2726 3
-- Name: ax_gebaeude_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_gebaeude_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_gebaeude_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3982 (class 0 OID 0)
-- Dependencies: 2822
-- Name: ax_gebaeude_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_gebaeude_ogc_fid_seq OWNED BY ax_gebaeude.ogc_fid;


--
-- TOC entry 2823 (class 1259 OID 7507050)
-- Dependencies: 3 2727
-- Name: ax_gehoelz_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_gehoelz_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_gehoelz_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3983 (class 0 OID 0)
-- Dependencies: 2823
-- Name: ax_gehoelz_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_gehoelz_ogc_fid_seq OWNED BY ax_gehoelz.ogc_fid;


--
-- TOC entry 2824 (class 1259 OID 7507052)
-- Dependencies: 3 2728
-- Name: ax_gemarkung_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_gemarkung_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_gemarkung_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3984 (class 0 OID 0)
-- Dependencies: 2824
-- Name: ax_gemarkung_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_gemarkung_ogc_fid_seq OWNED BY ax_gemarkung.ogc_fid;


--
-- TOC entry 2825 (class 1259 OID 7507054)
-- Dependencies: 3 2729
-- Name: ax_gemarkungsteilflur_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_gemarkungsteilflur_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_gemarkungsteilflur_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3985 (class 0 OID 0)
-- Dependencies: 2825
-- Name: ax_gemarkungsteilflur_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_gemarkungsteilflur_ogc_fid_seq OWNED BY ax_gemarkungsteilflur.ogc_fid;


--
-- TOC entry 2826 (class 1259 OID 7507056)
-- Dependencies: 3 2730
-- Name: ax_gemeinde_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_gemeinde_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_gemeinde_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3986 (class 0 OID 0)
-- Dependencies: 2826
-- Name: ax_gemeinde_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_gemeinde_ogc_fid_seq OWNED BY ax_gemeinde.ogc_fid;


--
-- TOC entry 2827 (class 1259 OID 7507058)
-- Dependencies: 3 2731
-- Name: ax_georeferenziertegebaeudeadresse_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_georeferenziertegebaeudeadresse_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_georeferenziertegebaeudeadresse_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3987 (class 0 OID 0)
-- Dependencies: 2827
-- Name: ax_georeferenziertegebaeudeadresse_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_georeferenziertegebaeudeadresse_ogc_fid_seq OWNED BY ax_georeferenziertegebaeudeadresse.ogc_fid;


--
-- TOC entry 2828 (class 1259 OID 7507060)
-- Dependencies: 2732 3
-- Name: ax_gewaessermerkmal_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_gewaessermerkmal_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_gewaessermerkmal_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3988 (class 0 OID 0)
-- Dependencies: 2828
-- Name: ax_gewaessermerkmal_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_gewaessermerkmal_ogc_fid_seq OWNED BY ax_gewaessermerkmal.ogc_fid;


--
-- TOC entry 2829 (class 1259 OID 7507062)
-- Dependencies: 3 2733
-- Name: ax_gleis_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_gleis_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_gleis_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3989 (class 0 OID 0)
-- Dependencies: 2829
-- Name: ax_gleis_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_gleis_ogc_fid_seq OWNED BY ax_gleis.ogc_fid;


--
-- TOC entry 2830 (class 1259 OID 7507064)
-- Dependencies: 2734 3
-- Name: ax_grenzpunkt_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_grenzpunkt_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_grenzpunkt_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3990 (class 0 OID 0)
-- Dependencies: 2830
-- Name: ax_grenzpunkt_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_grenzpunkt_ogc_fid_seq OWNED BY ax_grenzpunkt.ogc_fid;


--
-- TOC entry 2914 (class 1259 OID 15183967)
-- Dependencies: 2915 3
-- Name: ax_hafenbecken_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_hafenbecken_ogc_fid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_hafenbecken_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3991 (class 0 OID 0)
-- Dependencies: 2914
-- Name: ax_hafenbecken_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_hafenbecken_ogc_fid_seq OWNED BY ax_hafenbecken.ogc_fid;


--
-- TOC entry 2831 (class 1259 OID 7507066)
-- Dependencies: 2735 3
-- Name: ax_halde_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_halde_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_halde_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3992 (class 0 OID 0)
-- Dependencies: 2831
-- Name: ax_halde_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_halde_ogc_fid_seq OWNED BY ax_halde.ogc_fid;


--
-- TOC entry 2832 (class 1259 OID 7507068)
-- Dependencies: 2736 3
-- Name: ax_heide_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_heide_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_heide_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3993 (class 0 OID 0)
-- Dependencies: 2832
-- Name: ax_heide_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_heide_ogc_fid_seq OWNED BY ax_heide.ogc_fid;


--
-- TOC entry 2833 (class 1259 OID 7507070)
-- Dependencies: 2737 3
-- Name: ax_historischesbauwerkoderhistorischeeinrichtung_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_historischesbauwerkoderhistorischeeinrichtung_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_historischesbauwerkoderhistorischeeinrichtung_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3994 (class 0 OID 0)
-- Dependencies: 2833
-- Name: ax_historischesbauwerkoderhistorischeeinrichtung_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_historischesbauwerkoderhistorischeeinrichtung_ogc_fid_seq OWNED BY ax_historischesbauwerkoderhistorischeeinrichtung.ogc_fid;


--
-- TOC entry 2834 (class 1259 OID 7507072)
-- Dependencies: 3 2738
-- Name: ax_industrieundgewerbeflaeche_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_industrieundgewerbeflaeche_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_industrieundgewerbeflaeche_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3995 (class 0 OID 0)
-- Dependencies: 2834
-- Name: ax_industrieundgewerbeflaeche_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_industrieundgewerbeflaeche_ogc_fid_seq OWNED BY ax_industrieundgewerbeflaeche.ogc_fid;


--
-- TOC entry 2835 (class 1259 OID 7507074)
-- Dependencies: 3 2739
-- Name: ax_klassifizierungnachwasserrecht_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_klassifizierungnachwasserrecht_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_klassifizierungnachwasserrecht_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3996 (class 0 OID 0)
-- Dependencies: 2835
-- Name: ax_klassifizierungnachwasserrecht_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_klassifizierungnachwasserrecht_ogc_fid_seq OWNED BY ax_klassifizierungnachwasserrecht.ogc_fid;


--
-- TOC entry 2836 (class 1259 OID 7507076)
-- Dependencies: 3 2740
-- Name: ax_kleinraeumigerlandschaftsteil_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_kleinraeumigerlandschaftsteil_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_kleinraeumigerlandschaftsteil_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3997 (class 0 OID 0)
-- Dependencies: 2836
-- Name: ax_kleinraeumigerlandschaftsteil_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_kleinraeumigerlandschaftsteil_ogc_fid_seq OWNED BY ax_kleinraeumigerlandschaftsteil.ogc_fid;


--
-- TOC entry 2837 (class 1259 OID 7507078)
-- Dependencies: 2741 3
-- Name: ax_kommunalesgebiet_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_kommunalesgebiet_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_kommunalesgebiet_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3998 (class 0 OID 0)
-- Dependencies: 2837
-- Name: ax_kommunalesgebiet_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_kommunalesgebiet_ogc_fid_seq OWNED BY ax_kommunalesgebiet.ogc_fid;


--
-- TOC entry 2838 (class 1259 OID 7507080)
-- Dependencies: 2742 3
-- Name: ax_kreisregion_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_kreisregion_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_kreisregion_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 3999 (class 0 OID 0)
-- Dependencies: 2838
-- Name: ax_kreisregion_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_kreisregion_ogc_fid_seq OWNED BY ax_kreisregion.ogc_fid;


--
-- TOC entry 2839 (class 1259 OID 7507082)
-- Dependencies: 2743 3
-- Name: ax_lagebezeichnungkatalogeintrag_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_lagebezeichnungkatalogeintrag_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_lagebezeichnungkatalogeintrag_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4000 (class 0 OID 0)
-- Dependencies: 2839
-- Name: ax_lagebezeichnungkatalogeintrag_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_lagebezeichnungkatalogeintrag_ogc_fid_seq OWNED BY ax_lagebezeichnungkatalogeintrag.ogc_fid;


--
-- TOC entry 2840 (class 1259 OID 7507084)
-- Dependencies: 2744 3
-- Name: ax_lagebezeichnungmithausnummer_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_lagebezeichnungmithausnummer_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_lagebezeichnungmithausnummer_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4001 (class 0 OID 0)
-- Dependencies: 2840
-- Name: ax_lagebezeichnungmithausnummer_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_lagebezeichnungmithausnummer_ogc_fid_seq OWNED BY ax_lagebezeichnungmithausnummer.ogc_fid;


--
-- TOC entry 2841 (class 1259 OID 7507086)
-- Dependencies: 2745 3
-- Name: ax_lagebezeichnungmitpseudonummer_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_lagebezeichnungmitpseudonummer_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_lagebezeichnungmitpseudonummer_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4002 (class 0 OID 0)
-- Dependencies: 2841
-- Name: ax_lagebezeichnungmitpseudonummer_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_lagebezeichnungmitpseudonummer_ogc_fid_seq OWNED BY ax_lagebezeichnungmitpseudonummer.ogc_fid;


--
-- TOC entry 2842 (class 1259 OID 7507088)
-- Dependencies: 2746 3
-- Name: ax_lagebezeichnungohnehausnummer_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_lagebezeichnungohnehausnummer_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_lagebezeichnungohnehausnummer_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4003 (class 0 OID 0)
-- Dependencies: 2842
-- Name: ax_lagebezeichnungohnehausnummer_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_lagebezeichnungohnehausnummer_ogc_fid_seq OWNED BY ax_lagebezeichnungohnehausnummer.ogc_fid;


--
-- TOC entry 2843 (class 1259 OID 7507090)
-- Dependencies: 3 2747
-- Name: ax_landwirtschaft_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_landwirtschaft_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_landwirtschaft_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4004 (class 0 OID 0)
-- Dependencies: 2843
-- Name: ax_landwirtschaft_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_landwirtschaft_ogc_fid_seq OWNED BY ax_landwirtschaft.ogc_fid;


--
-- TOC entry 2844 (class 1259 OID 7507092)
-- Dependencies: 2748 3
-- Name: ax_leitung_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_leitung_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_leitung_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4005 (class 0 OID 0)
-- Dependencies: 2844
-- Name: ax_leitung_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_leitung_ogc_fid_seq OWNED BY ax_leitung.ogc_fid;


--
-- TOC entry 2918 (class 1259 OID 15184167)
-- Dependencies: 3 2919
-- Name: ax_meer_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_meer_ogc_fid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_meer_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4006 (class 0 OID 0)
-- Dependencies: 2918
-- Name: ax_meer_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_meer_ogc_fid_seq OWNED BY ax_meer.ogc_fid;


--
-- TOC entry 2911 (class 1259 OID 15183621)
-- Dependencies: 3 2912
-- Name: ax_moor_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_moor_ogc_fid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_moor_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4007 (class 0 OID 0)
-- Dependencies: 2911
-- Name: ax_moor_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_moor_ogc_fid_seq OWNED BY ax_moor.ogc_fid;


--
-- TOC entry 2845 (class 1259 OID 7507094)
-- Dependencies: 2749 3
-- Name: ax_musterlandesmusterundvergleichsstueck_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_musterlandesmusterundvergleichsstueck_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_musterlandesmusterundvergleichsstueck_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4008 (class 0 OID 0)
-- Dependencies: 2845
-- Name: ax_musterlandesmusterundvergleichsstueck_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_musterlandesmusterundvergleichsstueck_ogc_fid_seq OWNED BY ax_musterlandesmusterundvergleichsstueck.ogc_fid;


--
-- TOC entry 2846 (class 1259 OID 7507096)
-- Dependencies: 2750 3
-- Name: ax_namensnummer_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_namensnummer_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_namensnummer_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4009 (class 0 OID 0)
-- Dependencies: 2846
-- Name: ax_namensnummer_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_namensnummer_ogc_fid_seq OWNED BY ax_namensnummer.ogc_fid;


--
-- TOC entry 2847 (class 1259 OID 7507098)
-- Dependencies: 2751 3
-- Name: ax_naturumweltoderbodenschutzrecht_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_naturumweltoderbodenschutzrecht_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_naturumweltoderbodenschutzrecht_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4010 (class 0 OID 0)
-- Dependencies: 2847
-- Name: ax_naturumweltoderbodenschutzrecht_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_naturumweltoderbodenschutzrecht_ogc_fid_seq OWNED BY ax_naturumweltoderbodenschutzrecht.ogc_fid;


--
-- TOC entry 2848 (class 1259 OID 7507100)
-- Dependencies: 2752 3
-- Name: ax_person_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_person_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_person_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4011 (class 0 OID 0)
-- Dependencies: 2848
-- Name: ax_person_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_person_ogc_fid_seq OWNED BY ax_person.ogc_fid;


--
-- TOC entry 2849 (class 1259 OID 7507102)
-- Dependencies: 3 2753
-- Name: ax_platz_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_platz_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_platz_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4012 (class 0 OID 0)
-- Dependencies: 2849
-- Name: ax_platz_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_platz_ogc_fid_seq OWNED BY ax_platz.ogc_fid;


--
-- TOC entry 2850 (class 1259 OID 7507104)
-- Dependencies: 3 2754
-- Name: ax_punktortag_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_punktortag_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_punktortag_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4013 (class 0 OID 0)
-- Dependencies: 2850
-- Name: ax_punktortag_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_punktortag_ogc_fid_seq OWNED BY ax_punktortag.ogc_fid;


--
-- TOC entry 2851 (class 1259 OID 7507106)
-- Dependencies: 2755 3
-- Name: ax_punktortau_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_punktortau_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_punktortau_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4014 (class 0 OID 0)
-- Dependencies: 2851
-- Name: ax_punktortau_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_punktortau_ogc_fid_seq OWNED BY ax_punktortau.ogc_fid;


--
-- TOC entry 2852 (class 1259 OID 7507108)
-- Dependencies: 3 2756
-- Name: ax_punktortta_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_punktortta_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_punktortta_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4015 (class 0 OID 0)
-- Dependencies: 2852
-- Name: ax_punktortta_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_punktortta_ogc_fid_seq OWNED BY ax_punktortta.ogc_fid;


--
-- TOC entry 2853 (class 1259 OID 7507110)
-- Dependencies: 2757 3
-- Name: ax_regierungsbezirk_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_regierungsbezirk_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_regierungsbezirk_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4016 (class 0 OID 0)
-- Dependencies: 2853
-- Name: ax_regierungsbezirk_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_regierungsbezirk_ogc_fid_seq OWNED BY ax_regierungsbezirk.ogc_fid;


--
-- TOC entry 2908 (class 1259 OID 15182517)
-- Dependencies: 2909 3
-- Name: ax_schiffsverkehr_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_schiffsverkehr_ogc_fid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_schiffsverkehr_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4017 (class 0 OID 0)
-- Dependencies: 2908
-- Name: ax_schiffsverkehr_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_schiffsverkehr_ogc_fid_seq OWNED BY ax_schiffsverkehr.ogc_fid;


--
-- TOC entry 2854 (class 1259 OID 7507112)
-- Dependencies: 2758 3
-- Name: ax_schutzgebietnachwasserrecht_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_schutzgebietnachwasserrecht_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_schutzgebietnachwasserrecht_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4018 (class 0 OID 0)
-- Dependencies: 2854
-- Name: ax_schutzgebietnachwasserrecht_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_schutzgebietnachwasserrecht_ogc_fid_seq OWNED BY ax_schutzgebietnachwasserrecht.ogc_fid;


--
-- TOC entry 2855 (class 1259 OID 7507114)
-- Dependencies: 3 2759
-- Name: ax_schutzzone_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_schutzzone_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_schutzzone_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4019 (class 0 OID 0)
-- Dependencies: 2855
-- Name: ax_schutzzone_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_schutzzone_ogc_fid_seq OWNED BY ax_schutzzone.ogc_fid;


--
-- TOC entry 2856 (class 1259 OID 7507116)
-- Dependencies: 2760 3
-- Name: ax_sonstigervermessungspunkt_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_sonstigervermessungspunkt_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_sonstigervermessungspunkt_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4020 (class 0 OID 0)
-- Dependencies: 2856
-- Name: ax_sonstigervermessungspunkt_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_sonstigervermessungspunkt_ogc_fid_seq OWNED BY ax_sonstigervermessungspunkt.ogc_fid;


--
-- TOC entry 2857 (class 1259 OID 7507118)
-- Dependencies: 2761 3
-- Name: ax_sonstigesbauwerkodersonstigeeinrichtung_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_sonstigesbauwerkodersonstigeeinrichtung_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_sonstigesbauwerkodersonstigeeinrichtung_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4021 (class 0 OID 0)
-- Dependencies: 2857
-- Name: ax_sonstigesbauwerkodersonstigeeinrichtung_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_sonstigesbauwerkodersonstigeeinrichtung_ogc_fid_seq OWNED BY ax_sonstigesbauwerkodersonstigeeinrichtung.ogc_fid;


--
-- TOC entry 2858 (class 1259 OID 7507120)
-- Dependencies: 3 2762
-- Name: ax_sportfreizeitunderholungsflaeche_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_sportfreizeitunderholungsflaeche_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_sportfreizeitunderholungsflaeche_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4022 (class 0 OID 0)
-- Dependencies: 2858
-- Name: ax_sportfreizeitunderholungsflaeche_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_sportfreizeitunderholungsflaeche_ogc_fid_seq OWNED BY ax_sportfreizeitunderholungsflaeche.ogc_fid;


--
-- TOC entry 2859 (class 1259 OID 7507122)
-- Dependencies: 3 2763
-- Name: ax_stehendesgewaesser_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_stehendesgewaesser_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_stehendesgewaesser_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4023 (class 0 OID 0)
-- Dependencies: 2859
-- Name: ax_stehendesgewaesser_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_stehendesgewaesser_ogc_fid_seq OWNED BY ax_stehendesgewaesser.ogc_fid;


--
-- TOC entry 2860 (class 1259 OID 7507124)
-- Dependencies: 2764 3
-- Name: ax_strassenverkehr_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_strassenverkehr_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_strassenverkehr_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4024 (class 0 OID 0)
-- Dependencies: 2860
-- Name: ax_strassenverkehr_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_strassenverkehr_ogc_fid_seq OWNED BY ax_strassenverkehr.ogc_fid;


--
-- TOC entry 2861 (class 1259 OID 7507126)
-- Dependencies: 2765 3
-- Name: ax_strassenverkehrsanlage_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_strassenverkehrsanlage_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_strassenverkehrsanlage_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4025 (class 0 OID 0)
-- Dependencies: 2861
-- Name: ax_strassenverkehrsanlage_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_strassenverkehrsanlage_ogc_fid_seq OWNED BY ax_strassenverkehrsanlage.ogc_fid;


--
-- TOC entry 2862 (class 1259 OID 7507128)
-- Dependencies: 3 2766
-- Name: ax_sumpf_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_sumpf_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_sumpf_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4026 (class 0 OID 0)
-- Dependencies: 2862
-- Name: ax_sumpf_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_sumpf_ogc_fid_seq OWNED BY ax_sumpf.ogc_fid;


--
-- TOC entry 2863 (class 1259 OID 7507130)
-- Dependencies: 3 2767
-- Name: ax_tagebaugrubesteinbruch_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_tagebaugrubesteinbruch_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_tagebaugrubesteinbruch_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4027 (class 0 OID 0)
-- Dependencies: 2863
-- Name: ax_tagebaugrubesteinbruch_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_tagebaugrubesteinbruch_ogc_fid_seq OWNED BY ax_tagebaugrubesteinbruch.ogc_fid;


--
-- TOC entry 2900 (class 1259 OID 15115586)
-- Dependencies: 2901 3
-- Name: ax_tatsaechlichenutzung_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_tatsaechlichenutzung_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_tatsaechlichenutzung_id_seq OWNER TO postgres;

--
-- TOC entry 4028 (class 0 OID 0)
-- Dependencies: 2900
-- Name: ax_tatsaechlichenutzung_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_tatsaechlichenutzung_id_seq OWNED BY ax_tatsaechlichenutzung.id;


--
-- TOC entry 2864 (class 1259 OID 7507132)
-- Dependencies: 2768 3
-- Name: ax_transportanlage_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_transportanlage_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_transportanlage_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4029 (class 0 OID 0)
-- Dependencies: 2864
-- Name: ax_transportanlage_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_transportanlage_ogc_fid_seq OWNED BY ax_transportanlage.ogc_fid;


--
-- TOC entry 2865 (class 1259 OID 7507134)
-- Dependencies: 3 2769
-- Name: ax_turm_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_turm_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_turm_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4030 (class 0 OID 0)
-- Dependencies: 2865
-- Name: ax_turm_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_turm_ogc_fid_seq OWNED BY ax_turm.ogc_fid;


--
-- TOC entry 2866 (class 1259 OID 7507136)
-- Dependencies: 3 2770
-- Name: ax_unlandvegetationsloseflaeche_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_unlandvegetationsloseflaeche_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_unlandvegetationsloseflaeche_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4031 (class 0 OID 0)
-- Dependencies: 2866
-- Name: ax_unlandvegetationsloseflaeche_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_unlandvegetationsloseflaeche_ogc_fid_seq OWNED BY ax_unlandvegetationsloseflaeche.ogc_fid;


--
-- TOC entry 2867 (class 1259 OID 7507138)
-- Dependencies: 3 2771
-- Name: ax_untergeordnetesgewaesser_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_untergeordnetesgewaesser_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_untergeordnetesgewaesser_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4032 (class 0 OID 0)
-- Dependencies: 2867
-- Name: ax_untergeordnetesgewaesser_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_untergeordnetesgewaesser_ogc_fid_seq OWNED BY ax_untergeordnetesgewaesser.ogc_fid;


--
-- TOC entry 2868 (class 1259 OID 7507140)
-- Dependencies: 2772 3
-- Name: ax_vegetationsmerkmal_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_vegetationsmerkmal_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_vegetationsmerkmal_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4033 (class 0 OID 0)
-- Dependencies: 2868
-- Name: ax_vegetationsmerkmal_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_vegetationsmerkmal_ogc_fid_seq OWNED BY ax_vegetationsmerkmal.ogc_fid;


--
-- TOC entry 2869 (class 1259 OID 7507142)
-- Dependencies: 3 2773
-- Name: ax_vorratsbehaelterspeicherbauwerk_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_vorratsbehaelterspeicherbauwerk_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_vorratsbehaelterspeicherbauwerk_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4034 (class 0 OID 0)
-- Dependencies: 2869
-- Name: ax_vorratsbehaelterspeicherbauwerk_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_vorratsbehaelterspeicherbauwerk_ogc_fid_seq OWNED BY ax_vorratsbehaelterspeicherbauwerk.ogc_fid;


--
-- TOC entry 2870 (class 1259 OID 7507144)
-- Dependencies: 2774 3
-- Name: ax_wald_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_wald_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_wald_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4035 (class 0 OID 0)
-- Dependencies: 2870
-- Name: ax_wald_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_wald_ogc_fid_seq OWNED BY ax_wald.ogc_fid;


--
-- TOC entry 2871 (class 1259 OID 7507146)
-- Dependencies: 2775 3
-- Name: ax_weg_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_weg_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_weg_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4036 (class 0 OID 0)
-- Dependencies: 2871
-- Name: ax_weg_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_weg_ogc_fid_seq OWNED BY ax_weg.ogc_fid;


--
-- TOC entry 2872 (class 1259 OID 7507148)
-- Dependencies: 2776 3
-- Name: ax_wegpfadsteig_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_wegpfadsteig_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_wegpfadsteig_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4037 (class 0 OID 0)
-- Dependencies: 2872
-- Name: ax_wegpfadsteig_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_wegpfadsteig_ogc_fid_seq OWNED BY ax_wegpfadsteig.ogc_fid;


--
-- TOC entry 2873 (class 1259 OID 7507150)
-- Dependencies: 3 2777
-- Name: ax_wohnbauflaeche_ogc_fid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ax_wohnbauflaeche_ogc_fid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ax_wohnbauflaeche_ogc_fid_seq OWNER TO postgres;

--
-- TOC entry 4038 (class 0 OID 0)
-- Dependencies: 2873
-- Name: ax_wohnbauflaeche_ogc_fid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ax_wohnbauflaeche_ogc_fid_seq OWNED BY ax_wohnbauflaeche.ogc_fid;


--
-- TOC entry 2891 (class 1259 OID 14984756)
-- Dependencies: 2892 3
-- Name: ref_beziehungen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ref_beziehungen_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ref_beziehungen_id_seq OWNER TO postgres;

--
-- TOC entry 4039 (class 0 OID 0)
-- Dependencies: 2891
-- Name: ref_beziehungen_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ref_beziehungen_id_seq OWNED BY ref_beziehungen.id;


--
-- TOC entry 3214 (class 2604 OID 7507152)
-- Dependencies: 2785 2689
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ap_darstellung ALTER COLUMN ogc_fid SET DEFAULT nextval('ap_darstellung_ogc_fid_seq'::regclass);


--
-- TOC entry 3217 (class 2604 OID 7507153)
-- Dependencies: 2786 2690
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ap_lpo ALTER COLUMN ogc_fid SET DEFAULT nextval('ap_lpo_ogc_fid_seq'::regclass);


--
-- TOC entry 3220 (class 2604 OID 7507154)
-- Dependencies: 2787 2691
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ap_lto ALTER COLUMN ogc_fid SET DEFAULT nextval('ap_lto_ogc_fid_seq'::regclass);


--
-- TOC entry 3223 (class 2604 OID 7507155)
-- Dependencies: 2788 2692
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ap_ppo ALTER COLUMN ogc_fid SET DEFAULT nextval('ap_ppo_ogc_fid_seq'::regclass);


--
-- TOC entry 3226 (class 2604 OID 7507156)
-- Dependencies: 2789 2693
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ap_pto ALTER COLUMN ogc_fid SET DEFAULT nextval('ap_pto_ogc_fid_seq'::regclass);


--
-- TOC entry 3229 (class 2604 OID 7507157)
-- Dependencies: 2790 2694
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_anschrift ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_anschrift_ogc_fid_seq'::regclass);


--
-- TOC entry 3232 (class 2604 OID 7507158)
-- Dependencies: 2791 2695
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_aufnahmepunkt ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_aufnahmepunkt_ogc_fid_seq'::regclass);


--
-- TOC entry 3235 (class 2604 OID 7507159)
-- Dependencies: 2792 2696
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_bahnverkehr ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_bahnverkehr_ogc_fid_seq'::regclass);


--
-- TOC entry 3241 (class 2604 OID 7507160)
-- Dependencies: 2793 2697
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_bauraumoderbodenordnungsrecht ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_bauraumoderbodenordnungsrecht_ogc_fid_seq'::regclass);


--
-- TOC entry 3244 (class 2604 OID 7507161)
-- Dependencies: 2794 2698
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_bauteil ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_bauteil_ogc_fid_seq'::regclass);


--
-- TOC entry 3247 (class 2604 OID 7507162)
-- Dependencies: 2795 2699
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_bauwerkimgewaesserbereich ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_bauwerkimgewaesserbereich_ogc_fid_seq'::regclass);


--
-- TOC entry 3250 (class 2604 OID 7507163)
-- Dependencies: 2796 2700
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_bauwerkimverkehrsbereich ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_bauwerkimverkehrsbereich_ogc_fid_seq'::regclass);


--
-- TOC entry 3253 (class 2604 OID 7507164)
-- Dependencies: 2797 2701
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_bauwerkoderanlagefuerindustrieundgewerbe ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_bauwerkoderanlagefuerindustrieundgewerbe_ogc_fid_seq'::regclass);


--
-- TOC entry 3256 (class 2604 OID 7507165)
-- Dependencies: 2798 2702
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_bauwerkoderanlagefuersportfreizeitunderholung ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_bauwerkoderanlagefuersportfreizeitunderholung_ogc_fid_seq'::regclass);


--
-- TOC entry 3539 (class 2604 OID 15116070)
-- Dependencies: 2902 2903 2903
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_bergbaubetrieb ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_bergbaubetrieb_ogc_fid_seq'::regclass);


--
-- TOC entry 3259 (class 2604 OID 7507166)
-- Dependencies: 2799 2703
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_besondereflurstuecksgrenze ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_besondereflurstuecksgrenze_ogc_fid_seq'::regclass);


--
-- TOC entry 3262 (class 2604 OID 7507167)
-- Dependencies: 2800 2704
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_besonderegebaeudelinie ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_besonderegebaeudelinie_ogc_fid_seq'::regclass);


--
-- TOC entry 3265 (class 2604 OID 7507168)
-- Dependencies: 2801 2705
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_besondererbauwerkspunkt ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_besondererbauwerkspunkt_ogc_fid_seq'::regclass);


--
-- TOC entry 3268 (class 2604 OID 7507169)
-- Dependencies: 2802 2706
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_besonderergebaeudepunkt ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_besonderergebaeudepunkt_ogc_fid_seq'::regclass);


--
-- TOC entry 3271 (class 2604 OID 7507170)
-- Dependencies: 2803 2707
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_besonderertopographischerpunkt ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_besonderertopographischerpunkt_ogc_fid_seq'::regclass);


--
-- TOC entry 3274 (class 2604 OID 7507171)
-- Dependencies: 2804 2708
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_bodenschaetzung ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_bodenschaetzung_ogc_fid_seq'::regclass);


--
-- TOC entry 3277 (class 2604 OID 7507172)
-- Dependencies: 2805 2709
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_boeschungkliff ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_boeschungkliff_ogc_fid_seq'::regclass);


--
-- TOC entry 3280 (class 2604 OID 7507173)
-- Dependencies: 2806 2710
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_boeschungsflaeche ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_boeschungsflaeche_ogc_fid_seq'::regclass);


--
-- TOC entry 3283 (class 2604 OID 7507174)
-- Dependencies: 2807 2711
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_buchungsblatt ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_buchungsblatt_ogc_fid_seq'::regclass);


--
-- TOC entry 3286 (class 2604 OID 7507175)
-- Dependencies: 2808 2712
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_buchungsblattbezirk ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_buchungsblattbezirk_ogc_fid_seq'::regclass);


--
-- TOC entry 3289 (class 2604 OID 7507176)
-- Dependencies: 2809 2713
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_buchungsstelle ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_buchungsstelle_ogc_fid_seq'::regclass);


--
-- TOC entry 3292 (class 2604 OID 7507177)
-- Dependencies: 2810 2714
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_bundesland ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_bundesland_ogc_fid_seq'::regclass);


--
-- TOC entry 3295 (class 2604 OID 7507178)
-- Dependencies: 2811 2715
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_dammwalldeich ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_dammwalldeich_ogc_fid_seq'::regclass);


--
-- TOC entry 3298 (class 2604 OID 7507179)
-- Dependencies: 2812 2716
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_dienststelle ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_dienststelle_ogc_fid_seq'::regclass);


--
-- TOC entry 3301 (class 2604 OID 7507180)
-- Dependencies: 2813 2717
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_felsenfelsblockfelsnadel ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_felsenfelsblockfelsnadel_ogc_fid_seq'::regclass);


--
-- TOC entry 3304 (class 2604 OID 7507181)
-- Dependencies: 2814 2718
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_firstlinie ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_firstlinie_ogc_fid_seq'::regclass);


--
-- TOC entry 3307 (class 2604 OID 7507182)
-- Dependencies: 2815 2719
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_flaechebesondererfunktionalerpraegung ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_flaechebesondererfunktionalerpraegung_ogc_fid_seq'::regclass);


--
-- TOC entry 3313 (class 2604 OID 7507183)
-- Dependencies: 2816 2720
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_flaechegemischternutzung ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_flaechegemischternutzung_ogc_fid_seq'::regclass);


--
-- TOC entry 3319 (class 2604 OID 7507184)
-- Dependencies: 2817 2721
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_fliessgewaesser ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_fliessgewaesser_ogc_fid_seq'::regclass);


--
-- TOC entry 3324 (class 2604 OID 7507185)
-- Dependencies: 2818 2722
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_flugverkehr ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_flugverkehr_ogc_fid_seq'::regclass);


--
-- TOC entry 3331 (class 2604 OID 7507186)
-- Dependencies: 2819 2723
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_flugverkehrsanlage ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_flugverkehrsanlage_ogc_fid_seq'::regclass);


--
-- TOC entry 3334 (class 2604 OID 7507187)
-- Dependencies: 2820 2724
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_flurstueck ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_flurstueck_ogc_fid_seq'::regclass);


--
-- TOC entry 3337 (class 2604 OID 7507188)
-- Dependencies: 2821 2725
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_friedhof ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_friedhof_ogc_fid_seq'::regclass);


--
-- TOC entry 3342 (class 2604 OID 7507189)
-- Dependencies: 2822 2726
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_gebaeude ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_gebaeude_ogc_fid_seq'::regclass);


--
-- TOC entry 3345 (class 2604 OID 7507190)
-- Dependencies: 2823 2727
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_gehoelz ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_gehoelz_ogc_fid_seq'::regclass);


--
-- TOC entry 3350 (class 2604 OID 7507191)
-- Dependencies: 2824 2728
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_gemarkung ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_gemarkung_ogc_fid_seq'::regclass);


--
-- TOC entry 3353 (class 2604 OID 7507192)
-- Dependencies: 2825 2729
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_gemarkungsteilflur ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_gemarkungsteilflur_ogc_fid_seq'::regclass);


--
-- TOC entry 3356 (class 2604 OID 7507193)
-- Dependencies: 2826 2730
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_gemeinde ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_gemeinde_ogc_fid_seq'::regclass);


--
-- TOC entry 3359 (class 2604 OID 7507194)
-- Dependencies: 2827 2731
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_georeferenziertegebaeudeadresse ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_georeferenziertegebaeudeadresse_ogc_fid_seq'::regclass);


--
-- TOC entry 3362 (class 2604 OID 7507195)
-- Dependencies: 2828 2732
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_gewaessermerkmal ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_gewaessermerkmal_ogc_fid_seq'::regclass);


--
-- TOC entry 3365 (class 2604 OID 7507196)
-- Dependencies: 2829 2733
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_gleis ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_gleis_ogc_fid_seq'::regclass);


--
-- TOC entry 3368 (class 2604 OID 7507197)
-- Dependencies: 2830 2734
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_grenzpunkt ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_grenzpunkt_ogc_fid_seq'::regclass);


--
-- TOC entry 3551 (class 2604 OID 15183972)
-- Dependencies: 2914 2915 2915
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_hafenbecken ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_hafenbecken_ogc_fid_seq'::regclass);


--
-- TOC entry 3371 (class 2604 OID 7507198)
-- Dependencies: 2831 2735
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_halde ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_halde_ogc_fid_seq'::regclass);


--
-- TOC entry 3376 (class 2604 OID 7507199)
-- Dependencies: 2832 2736
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_heide ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_heide_ogc_fid_seq'::regclass);


--
-- TOC entry 3379 (class 2604 OID 7507200)
-- Dependencies: 2833 2737
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_historischesbauwerkoderhistorischeeinrichtung ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_historischesbauwerkoderhistorischeeinrichtung_ogc_fid_seq'::regclass);


--
-- TOC entry 3382 (class 2604 OID 7507201)
-- Dependencies: 2834 2738
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_industrieundgewerbeflaeche ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_industrieundgewerbeflaeche_ogc_fid_seq'::regclass);


--
-- TOC entry 3390 (class 2604 OID 7507202)
-- Dependencies: 2835 2739
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_klassifizierungnachwasserrecht ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_klassifizierungnachwasserrecht_ogc_fid_seq'::regclass);


--
-- TOC entry 3393 (class 2604 OID 7507203)
-- Dependencies: 2836 2740
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_kleinraeumigerlandschaftsteil ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_kleinraeumigerlandschaftsteil_ogc_fid_seq'::regclass);


--
-- TOC entry 3396 (class 2604 OID 7507204)
-- Dependencies: 2837 2741
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_kommunalesgebiet ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_kommunalesgebiet_ogc_fid_seq'::regclass);


--
-- TOC entry 3399 (class 2604 OID 7507205)
-- Dependencies: 2838 2742
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_kreisregion ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_kreisregion_ogc_fid_seq'::regclass);


--
-- TOC entry 3402 (class 2604 OID 7507206)
-- Dependencies: 2839 2743
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_lagebezeichnungkatalogeintrag ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_lagebezeichnungkatalogeintrag_ogc_fid_seq'::regclass);


--
-- TOC entry 3405 (class 2604 OID 7507207)
-- Dependencies: 2840 2744
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_lagebezeichnungmithausnummer ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_lagebezeichnungmithausnummer_ogc_fid_seq'::regclass);


--
-- TOC entry 3408 (class 2604 OID 7507208)
-- Dependencies: 2841 2745
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_lagebezeichnungmitpseudonummer ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_lagebezeichnungmitpseudonummer_ogc_fid_seq'::regclass);


--
-- TOC entry 3411 (class 2604 OID 7507209)
-- Dependencies: 2842 2746
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_lagebezeichnungohnehausnummer ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_lagebezeichnungohnehausnummer_ogc_fid_seq'::regclass);


--
-- TOC entry 3414 (class 2604 OID 7507210)
-- Dependencies: 2843 2747
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_landwirtschaft ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_landwirtschaft_ogc_fid_seq'::regclass);


--
-- TOC entry 3418 (class 2604 OID 7507211)
-- Dependencies: 2844 2748
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_leitung ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_leitung_ogc_fid_seq'::regclass);


--
-- TOC entry 3556 (class 2604 OID 15184172)
-- Dependencies: 2919 2918 2919
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_meer ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_meer_ogc_fid_seq'::regclass);


--
-- TOC entry 3548 (class 2604 OID 15183626)
-- Dependencies: 2912 2911 2912
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_moor ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_moor_ogc_fid_seq'::regclass);


--
-- TOC entry 3421 (class 2604 OID 7507212)
-- Dependencies: 2845 2749
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_musterlandesmusterundvergleichsstueck ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_musterlandesmusterundvergleichsstueck_ogc_fid_seq'::regclass);


--
-- TOC entry 3424 (class 2604 OID 7507213)
-- Dependencies: 2846 2750
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_namensnummer ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_namensnummer_ogc_fid_seq'::regclass);


--
-- TOC entry 3427 (class 2604 OID 7507214)
-- Dependencies: 2847 2751
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_naturumweltoderbodenschutzrecht ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_naturumweltoderbodenschutzrecht_ogc_fid_seq'::regclass);


--
-- TOC entry 3430 (class 2604 OID 7507215)
-- Dependencies: 2848 2752
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_person ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_person_ogc_fid_seq'::regclass);


--
-- TOC entry 3433 (class 2604 OID 7507216)
-- Dependencies: 2849 2753
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_platz ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_platz_ogc_fid_seq'::regclass);


--
-- TOC entry 3437 (class 2604 OID 7507217)
-- Dependencies: 2850 2754
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_punktortag ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_punktortag_ogc_fid_seq'::regclass);


--
-- TOC entry 3440 (class 2604 OID 7507218)
-- Dependencies: 2851 2755
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_punktortau ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_punktortau_ogc_fid_seq'::regclass);


--
-- TOC entry 3443 (class 2604 OID 7507219)
-- Dependencies: 2852 2756
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_punktortta ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_punktortta_ogc_fid_seq'::regclass);


--
-- TOC entry 3446 (class 2604 OID 7507220)
-- Dependencies: 2853 2757
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_regierungsbezirk ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_regierungsbezirk_ogc_fid_seq'::regclass);


--
-- TOC entry 3543 (class 2604 OID 15182522)
-- Dependencies: 2909 2908 2909
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_schiffsverkehr ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_schiffsverkehr_ogc_fid_seq'::regclass);


--
-- TOC entry 3449 (class 2604 OID 7507221)
-- Dependencies: 2854 2758
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_schutzgebietnachwasserrecht ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_schutzgebietnachwasserrecht_ogc_fid_seq'::regclass);


--
-- TOC entry 3452 (class 2604 OID 7507222)
-- Dependencies: 2855 2759
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_schutzzone ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_schutzzone_ogc_fid_seq'::regclass);


--
-- TOC entry 3455 (class 2604 OID 7507223)
-- Dependencies: 2856 2760
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_sonstigervermessungspunkt ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_sonstigervermessungspunkt_ogc_fid_seq'::regclass);


--
-- TOC entry 3458 (class 2604 OID 7507224)
-- Dependencies: 2857 2761
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_sonstigesbauwerkodersonstigeeinrichtung ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_sonstigesbauwerkodersonstigeeinrichtung_ogc_fid_seq'::regclass);


--
-- TOC entry 3461 (class 2604 OID 7507225)
-- Dependencies: 2858 2762
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_sportfreizeitunderholungsflaeche ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_sportfreizeitunderholungsflaeche_ogc_fid_seq'::regclass);


--
-- TOC entry 3466 (class 2604 OID 7507226)
-- Dependencies: 2859 2763
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_stehendesgewaesser ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_stehendesgewaesser_ogc_fid_seq'::regclass);


--
-- TOC entry 3471 (class 2604 OID 7507227)
-- Dependencies: 2860 2764
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_strassenverkehr ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_strassenverkehr_ogc_fid_seq'::regclass);


--
-- TOC entry 3476 (class 2604 OID 7507228)
-- Dependencies: 2861 2765
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_strassenverkehrsanlage ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_strassenverkehrsanlage_ogc_fid_seq'::regclass);


--
-- TOC entry 3479 (class 2604 OID 7507229)
-- Dependencies: 2862 2766
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_sumpf ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_sumpf_ogc_fid_seq'::regclass);


--
-- TOC entry 3482 (class 2604 OID 7507230)
-- Dependencies: 2863 2767
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_tagebaugrubesteinbruch ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_tagebaugrubesteinbruch_ogc_fid_seq'::regclass);


--
-- TOC entry 3524 (class 2604 OID 15115591)
-- Dependencies: 2901 2900 2901
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_tatsaechlichenutzung ALTER COLUMN id SET DEFAULT nextval('ax_tatsaechlichenutzung_id_seq'::regclass);


--
-- TOC entry 3487 (class 2604 OID 7507231)
-- Dependencies: 2864 2768
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_transportanlage ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_transportanlage_ogc_fid_seq'::regclass);


--
-- TOC entry 3490 (class 2604 OID 7507232)
-- Dependencies: 2865 2769
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_turm ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_turm_ogc_fid_seq'::regclass);


--
-- TOC entry 3493 (class 2604 OID 7507233)
-- Dependencies: 2866 2770
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_unlandvegetationsloseflaeche ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_unlandvegetationsloseflaeche_ogc_fid_seq'::regclass);


--
-- TOC entry 3498 (class 2604 OID 7507234)
-- Dependencies: 2867 2771
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_untergeordnetesgewaesser ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_untergeordnetesgewaesser_ogc_fid_seq'::regclass);


--
-- TOC entry 3501 (class 2604 OID 7507235)
-- Dependencies: 2868 2772
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_vegetationsmerkmal ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_vegetationsmerkmal_ogc_fid_seq'::regclass);


--
-- TOC entry 3504 (class 2604 OID 7507236)
-- Dependencies: 2869 2773
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_vorratsbehaelterspeicherbauwerk ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_vorratsbehaelterspeicherbauwerk_ogc_fid_seq'::regclass);


--
-- TOC entry 3507 (class 2604 OID 7507237)
-- Dependencies: 2870 2774
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_wald ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_wald_ogc_fid_seq'::regclass);


--
-- TOC entry 3511 (class 2604 OID 7507238)
-- Dependencies: 2871 2775
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_weg ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_weg_ogc_fid_seq'::regclass);


--
-- TOC entry 3515 (class 2604 OID 7507239)
-- Dependencies: 2872 2776
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_wegpfadsteig ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_wegpfadsteig_ogc_fid_seq'::regclass);


--
-- TOC entry 3518 (class 2604 OID 7507240)
-- Dependencies: 2873 2777
-- Name: ogc_fid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ax_wohnbauflaeche ALTER COLUMN ogc_fid SET DEFAULT nextval('ax_wohnbauflaeche_ogc_fid_seq'::regclass);


--
-- TOC entry 3523 (class 2604 OID 14984761)
-- Dependencies: 2892 2891 2892
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ref_beziehungen ALTER COLUMN id SET DEFAULT nextval('ref_beziehungen_id_seq'::regclass);


--
-- TOC entry 3563 (class 2606 OID 7507242)
-- Dependencies: 2689 2689
-- Name: ap_darstellung_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ap_darstellung
    ADD CONSTRAINT ap_darstellung_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3566 (class 2606 OID 7507244)
-- Dependencies: 2690 2690
-- Name: ap_lpo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ap_lpo
    ADD CONSTRAINT ap_lpo_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3571 (class 2606 OID 7507246)
-- Dependencies: 2691 2691
-- Name: ap_lto_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ap_lto
    ADD CONSTRAINT ap_lto_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3576 (class 2606 OID 7507248)
-- Dependencies: 2692 2692
-- Name: ap_ppo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ap_ppo
    ADD CONSTRAINT ap_ppo_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3581 (class 2606 OID 7507250)
-- Dependencies: 2693 2693
-- Name: ap_pto_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ap_pto
    ADD CONSTRAINT ap_pto_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3586 (class 2606 OID 7507252)
-- Dependencies: 2694 2694
-- Name: ax_anschrift_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_anschrift
    ADD CONSTRAINT ax_anschrift_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3589 (class 2606 OID 7507254)
-- Dependencies: 2695 2695
-- Name: ax_aufnahmepunkt_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_aufnahmepunkt
    ADD CONSTRAINT ax_aufnahmepunkt_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3593 (class 2606 OID 7507256)
-- Dependencies: 2696 2696
-- Name: ax_bahnverkehr_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_bahnverkehr
    ADD CONSTRAINT ax_bahnverkehr_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3596 (class 2606 OID 7507258)
-- Dependencies: 2697 2697
-- Name: ax_bauraumoderbodenordnungsrecht_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_bauraumoderbodenordnungsrecht
    ADD CONSTRAINT ax_bauraumoderbodenordnungsrecht_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3599 (class 2606 OID 7507260)
-- Dependencies: 2698 2698
-- Name: ax_bauteil_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_bauteil
    ADD CONSTRAINT ax_bauteil_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3602 (class 2606 OID 7507262)
-- Dependencies: 2699 2699
-- Name: ax_bauwerkimgewaesserbereich_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_bauwerkimgewaesserbereich
    ADD CONSTRAINT ax_bauwerkimgewaesserbereich_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3605 (class 2606 OID 7507264)
-- Dependencies: 2700 2700
-- Name: ax_bauwerkimverkehrsbereich_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_bauwerkimverkehrsbereich
    ADD CONSTRAINT ax_bauwerkimverkehrsbereich_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3608 (class 2606 OID 7507266)
-- Dependencies: 2701 2701
-- Name: ax_bauwerkoderanlagefuerindustrieundgewerbe_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_bauwerkoderanlagefuerindustrieundgewerbe
    ADD CONSTRAINT ax_bauwerkoderanlagefuerindustrieundgewerbe_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3611 (class 2606 OID 7507268)
-- Dependencies: 2702 2702
-- Name: ax_bauwerkoderanlagefuersportfreizeitunderholung_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_bauwerkoderanlagefuersportfreizeitunderholung
    ADD CONSTRAINT ax_bauwerkoderanlagefuersportfreizeitunderholung_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3911 (class 2606 OID 15116077)
-- Dependencies: 2903 2903
-- Name: ax_bergbaubetrieb_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_bergbaubetrieb
    ADD CONSTRAINT ax_bergbaubetrieb_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3614 (class 2606 OID 7507270)
-- Dependencies: 2703 2703
-- Name: ax_besondereflurstuecksgrenze_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_besondereflurstuecksgrenze
    ADD CONSTRAINT ax_besondereflurstuecksgrenze_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3617 (class 2606 OID 7507272)
-- Dependencies: 2704 2704
-- Name: ax_besonderegebaeudelinie_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_besonderegebaeudelinie
    ADD CONSTRAINT ax_besonderegebaeudelinie_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3620 (class 2606 OID 7507274)
-- Dependencies: 2705 2705
-- Name: ax_besondererbauwerkspunkt_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_besondererbauwerkspunkt
    ADD CONSTRAINT ax_besondererbauwerkspunkt_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3623 (class 2606 OID 7507276)
-- Dependencies: 2706 2706
-- Name: ax_besonderergebaeudepunkt_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_besonderergebaeudepunkt
    ADD CONSTRAINT ax_besonderergebaeudepunkt_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3626 (class 2606 OID 7507278)
-- Dependencies: 2707 2707
-- Name: ax_besonderertopographischerpunkt_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_besonderertopographischerpunkt
    ADD CONSTRAINT ax_besonderertopographischerpunkt_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3629 (class 2606 OID 7507280)
-- Dependencies: 2708 2708
-- Name: ax_bodenschaetzung_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_bodenschaetzung
    ADD CONSTRAINT ax_bodenschaetzung_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3632 (class 2606 OID 7507282)
-- Dependencies: 2709 2709
-- Name: ax_boeschungkliff_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_boeschungkliff
    ADD CONSTRAINT ax_boeschungkliff_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3635 (class 2606 OID 7507284)
-- Dependencies: 2710 2710
-- Name: ax_boeschungsflaeche_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_boeschungsflaeche
    ADD CONSTRAINT ax_boeschungsflaeche_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3638 (class 2606 OID 7507286)
-- Dependencies: 2711 2711
-- Name: ax_buchungsblatt_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_buchungsblatt
    ADD CONSTRAINT ax_buchungsblatt_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3642 (class 2606 OID 7507288)
-- Dependencies: 2712 2712
-- Name: ax_buchungsblattbezirk_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_buchungsblattbezirk
    ADD CONSTRAINT ax_buchungsblattbezirk_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3647 (class 2606 OID 7507290)
-- Dependencies: 2713 2713
-- Name: ax_buchungsstelle_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_buchungsstelle
    ADD CONSTRAINT ax_buchungsstelle_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3653 (class 2606 OID 7507292)
-- Dependencies: 2714 2714
-- Name: ax_bundesland_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_bundesland
    ADD CONSTRAINT ax_bundesland_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3656 (class 2606 OID 7507294)
-- Dependencies: 2715 2715
-- Name: ax_dammwalldeich_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_dammwalldeich
    ADD CONSTRAINT ax_dammwalldeich_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3659 (class 2606 OID 7507296)
-- Dependencies: 2716 2716
-- Name: ax_dienststelle_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_dienststelle
    ADD CONSTRAINT ax_dienststelle_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3663 (class 2606 OID 7507298)
-- Dependencies: 2717 2717
-- Name: ax_felsenfelsblockfelsnadel_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_felsenfelsblockfelsnadel
    ADD CONSTRAINT ax_felsenfelsblockfelsnadel_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3666 (class 2606 OID 7507300)
-- Dependencies: 2718 2718
-- Name: ax_firstlinie_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_firstlinie
    ADD CONSTRAINT ax_firstlinie_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3669 (class 2606 OID 7507302)
-- Dependencies: 2719 2719
-- Name: ax_flaechebesondererfunktionalerpraegung_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_flaechebesondererfunktionalerpraegung
    ADD CONSTRAINT ax_flaechebesondererfunktionalerpraegung_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3672 (class 2606 OID 7507304)
-- Dependencies: 2720 2720
-- Name: ax_flaechegemischternutzung_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_flaechegemischternutzung
    ADD CONSTRAINT ax_flaechegemischternutzung_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3675 (class 2606 OID 7507306)
-- Dependencies: 2721 2721
-- Name: ax_fliessgewaesser_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_fliessgewaesser
    ADD CONSTRAINT ax_fliessgewaesser_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3678 (class 2606 OID 7507308)
-- Dependencies: 2722 2722
-- Name: ax_flugverkehr_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_flugverkehr
    ADD CONSTRAINT ax_flugverkehr_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3681 (class 2606 OID 7507310)
-- Dependencies: 2723 2723
-- Name: ax_flugverkehrsanlage_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_flugverkehrsanlage
    ADD CONSTRAINT ax_flugverkehrsanlage_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3684 (class 2606 OID 7507312)
-- Dependencies: 2724 2724
-- Name: ax_flurstueck_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_flurstueck
    ADD CONSTRAINT ax_flurstueck_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3693 (class 2606 OID 7507314)
-- Dependencies: 2725 2725
-- Name: ax_friedhof_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_friedhof
    ADD CONSTRAINT ax_friedhof_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3696 (class 2606 OID 7507316)
-- Dependencies: 2726 2726
-- Name: ax_gebaeude_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_gebaeude
    ADD CONSTRAINT ax_gebaeude_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3701 (class 2606 OID 7507318)
-- Dependencies: 2727 2727
-- Name: ax_gehoelz_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_gehoelz
    ADD CONSTRAINT ax_gehoelz_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3704 (class 2606 OID 7507320)
-- Dependencies: 2728 2728
-- Name: ax_gemarkung_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_gemarkung
    ADD CONSTRAINT ax_gemarkung_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3708 (class 2606 OID 7507322)
-- Dependencies: 2729 2729
-- Name: ax_gemarkungsteilflur_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_gemarkungsteilflur
    ADD CONSTRAINT ax_gemarkungsteilflur_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3711 (class 2606 OID 7507324)
-- Dependencies: 2730 2730
-- Name: ax_gemeinde_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_gemeinde
    ADD CONSTRAINT ax_gemeinde_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3715 (class 2606 OID 7507326)
-- Dependencies: 2731 2731
-- Name: ax_georeferenziertegebaeudeadresse_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_georeferenziertegebaeudeadresse
    ADD CONSTRAINT ax_georeferenziertegebaeudeadresse_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3718 (class 2606 OID 7507328)
-- Dependencies: 2732 2732
-- Name: ax_gewaessermerkmal_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_gewaessermerkmal
    ADD CONSTRAINT ax_gewaessermerkmal_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3721 (class 2606 OID 7507330)
-- Dependencies: 2733 2733
-- Name: ax_gleis_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_gleis
    ADD CONSTRAINT ax_gleis_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3724 (class 2606 OID 7507332)
-- Dependencies: 2734 2734
-- Name: ax_grenzpunkt_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_grenzpunkt
    ADD CONSTRAINT ax_grenzpunkt_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3932 (class 2606 OID 15183981)
-- Dependencies: 2915 2915
-- Name: ax_hafenbecken_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_hafenbecken
    ADD CONSTRAINT ax_hafenbecken_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3728 (class 2606 OID 7507334)
-- Dependencies: 2735 2735
-- Name: ax_halde_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_halde
    ADD CONSTRAINT ax_halde_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3731 (class 2606 OID 7507336)
-- Dependencies: 2736 2736
-- Name: ax_heide_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_heide
    ADD CONSTRAINT ax_heide_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3734 (class 2606 OID 7507338)
-- Dependencies: 2737 2737
-- Name: ax_historischesbauwerkoderhistorischeeinrichtung_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_historischesbauwerkoderhistorischeeinrichtung
    ADD CONSTRAINT ax_historischesbauwerkoderhistorischeeinrichtung_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3737 (class 2606 OID 7507340)
-- Dependencies: 2738 2738
-- Name: ax_industrieundgewerbeflaeche_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_industrieundgewerbeflaeche
    ADD CONSTRAINT ax_industrieundgewerbeflaeche_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3740 (class 2606 OID 7507342)
-- Dependencies: 2739 2739
-- Name: ax_klassifizierungnachwasserrecht_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_klassifizierungnachwasserrecht
    ADD CONSTRAINT ax_klassifizierungnachwasserrecht_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3743 (class 2606 OID 7507344)
-- Dependencies: 2740 2740
-- Name: ax_kleinraeumigerlandschaftsteil_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_kleinraeumigerlandschaftsteil
    ADD CONSTRAINT ax_kleinraeumigerlandschaftsteil_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3746 (class 2606 OID 7507346)
-- Dependencies: 2741 2741
-- Name: ax_kommunalesgebiet_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_kommunalesgebiet
    ADD CONSTRAINT ax_kommunalesgebiet_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3749 (class 2606 OID 7507348)
-- Dependencies: 2742 2742
-- Name: ax_kreisregion_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_kreisregion
    ADD CONSTRAINT ax_kreisregion_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3752 (class 2606 OID 7507350)
-- Dependencies: 2743 2743
-- Name: ax_lagebezeichnungkatalogeintrag_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_lagebezeichnungkatalogeintrag
    ADD CONSTRAINT ax_lagebezeichnungkatalogeintrag_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3756 (class 2606 OID 7507352)
-- Dependencies: 2744 2744
-- Name: ax_lagebezeichnungmithausnummer_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_lagebezeichnungmithausnummer
    ADD CONSTRAINT ax_lagebezeichnungmithausnummer_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3760 (class 2606 OID 7507354)
-- Dependencies: 2745 2745
-- Name: ax_lagebezeichnungmitpseudonummer_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_lagebezeichnungmitpseudonummer
    ADD CONSTRAINT ax_lagebezeichnungmitpseudonummer_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3763 (class 2606 OID 7507356)
-- Dependencies: 2746 2746
-- Name: ax_lagebezeichnungohnehausnummer_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_lagebezeichnungohnehausnummer
    ADD CONSTRAINT ax_lagebezeichnungohnehausnummer_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3767 (class 2606 OID 7507358)
-- Dependencies: 2747 2747
-- Name: ax_landwirtschaft_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_landwirtschaft
    ADD CONSTRAINT ax_landwirtschaft_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3770 (class 2606 OID 7507360)
-- Dependencies: 2748 2748
-- Name: ax_leitung_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_leitung
    ADD CONSTRAINT ax_leitung_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3939 (class 2606 OID 15184181)
-- Dependencies: 2919 2919
-- Name: ax_meer_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_meer
    ADD CONSTRAINT ax_meer_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3927 (class 2606 OID 15183633)
-- Dependencies: 2912 2912
-- Name: ax_moor_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_moor
    ADD CONSTRAINT ax_moor_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3773 (class 2606 OID 7507362)
-- Dependencies: 2749 2749
-- Name: ax_musterlandesmusterundvergleichsstueck_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_musterlandesmusterundvergleichsstueck
    ADD CONSTRAINT ax_musterlandesmusterundvergleichsstueck_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3776 (class 2606 OID 7507364)
-- Dependencies: 2750 2750
-- Name: ax_namensnummer_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_namensnummer
    ADD CONSTRAINT ax_namensnummer_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3782 (class 2606 OID 7507366)
-- Dependencies: 2751 2751
-- Name: ax_naturumweltoderbodenschutzrecht_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_naturumweltoderbodenschutzrecht
    ADD CONSTRAINT ax_naturumweltoderbodenschutzrecht_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3785 (class 2606 OID 7507368)
-- Dependencies: 2752 2752
-- Name: ax_person_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_person
    ADD CONSTRAINT ax_person_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3790 (class 2606 OID 7507370)
-- Dependencies: 2753 2753
-- Name: ax_platz_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_platz
    ADD CONSTRAINT ax_platz_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3793 (class 2606 OID 7507372)
-- Dependencies: 2754 2754
-- Name: ax_punktortag_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_punktortag
    ADD CONSTRAINT ax_punktortag_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3798 (class 2606 OID 7507374)
-- Dependencies: 2755 2755
-- Name: ax_punktortau_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_punktortau
    ADD CONSTRAINT ax_punktortau_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3803 (class 2606 OID 7507376)
-- Dependencies: 2756 2756
-- Name: ax_punktortta_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_punktortta
    ADD CONSTRAINT ax_punktortta_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3808 (class 2606 OID 7507378)
-- Dependencies: 2757 2757
-- Name: ax_regierungsbezirk_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_regierungsbezirk
    ADD CONSTRAINT ax_regierungsbezirk_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3922 (class 2606 OID 15182531)
-- Dependencies: 2909 2909
-- Name: ax_schiffsverkehr_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_schiffsverkehr
    ADD CONSTRAINT ax_schiffsverkehr_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3811 (class 2606 OID 7507380)
-- Dependencies: 2758 2758
-- Name: ax_schutzgebietnachwasserrecht_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_schutzgebietnachwasserrecht
    ADD CONSTRAINT ax_schutzgebietnachwasserrecht_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3814 (class 2606 OID 7507382)
-- Dependencies: 2759 2759
-- Name: ax_schutzzone_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_schutzzone
    ADD CONSTRAINT ax_schutzzone_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3817 (class 2606 OID 7507384)
-- Dependencies: 2760 2760
-- Name: ax_sonstigervermessungspunkt_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_sonstigervermessungspunkt
    ADD CONSTRAINT ax_sonstigervermessungspunkt_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3821 (class 2606 OID 7507386)
-- Dependencies: 2761 2761
-- Name: ax_sonstigesbauwerkodersonstigeeinrichtung_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_sonstigesbauwerkodersonstigeeinrichtung
    ADD CONSTRAINT ax_sonstigesbauwerkodersonstigeeinrichtung_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3826 (class 2606 OID 7507388)
-- Dependencies: 2762 2762
-- Name: ax_sportfreizeitunderholungsflaeche_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_sportfreizeitunderholungsflaeche
    ADD CONSTRAINT ax_sportfreizeitunderholungsflaeche_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3829 (class 2606 OID 7507390)
-- Dependencies: 2763 2763
-- Name: ax_stehendesgewaesser_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_stehendesgewaesser
    ADD CONSTRAINT ax_stehendesgewaesser_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3832 (class 2606 OID 7507392)
-- Dependencies: 2764 2764
-- Name: ax_strassenverkehr_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_strassenverkehr
    ADD CONSTRAINT ax_strassenverkehr_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3835 (class 2606 OID 7507394)
-- Dependencies: 2765 2765
-- Name: ax_strassenverkehrsanlage_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_strassenverkehrsanlage
    ADD CONSTRAINT ax_strassenverkehrsanlage_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3838 (class 2606 OID 7507396)
-- Dependencies: 2766 2766
-- Name: ax_sumpf_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_sumpf
    ADD CONSTRAINT ax_sumpf_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3841 (class 2606 OID 7507398)
-- Dependencies: 2767 2767
-- Name: ax_tagebaugrubesteinbruch_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_tagebaugrubesteinbruch
    ADD CONSTRAINT ax_tagebaugrubesteinbruch_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3844 (class 2606 OID 7507400)
-- Dependencies: 2768 2768
-- Name: ax_transportanlage_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_transportanlage
    ADD CONSTRAINT ax_transportanlage_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3847 (class 2606 OID 7507402)
-- Dependencies: 2769 2769
-- Name: ax_turm_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_turm
    ADD CONSTRAINT ax_turm_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3850 (class 2606 OID 7507404)
-- Dependencies: 2770 2770
-- Name: ax_unlandvegetationsloseflaeche_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_unlandvegetationsloseflaeche
    ADD CONSTRAINT ax_unlandvegetationsloseflaeche_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3853 (class 2606 OID 7507406)
-- Dependencies: 2771 2771
-- Name: ax_untergeordnetesgewaesser_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_untergeordnetesgewaesser
    ADD CONSTRAINT ax_untergeordnetesgewaesser_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3856 (class 2606 OID 7507408)
-- Dependencies: 2772 2772
-- Name: ax_vegetationsmerkmal_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_vegetationsmerkmal
    ADD CONSTRAINT ax_vegetationsmerkmal_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3859 (class 2606 OID 7507410)
-- Dependencies: 2773 2773
-- Name: ax_vorratsbehaelterspeicherbauwerk_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_vorratsbehaelterspeicherbauwerk
    ADD CONSTRAINT ax_vorratsbehaelterspeicherbauwerk_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3862 (class 2606 OID 7507412)
-- Dependencies: 2774 2774
-- Name: ax_wald_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_wald
    ADD CONSTRAINT ax_wald_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3865 (class 2606 OID 7507414)
-- Dependencies: 2775 2775
-- Name: ax_weg_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_weg
    ADD CONSTRAINT ax_weg_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3868 (class 2606 OID 7507416)
-- Dependencies: 2776 2776
-- Name: ax_wegpfadsteig_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_wegpfadsteig
    ADD CONSTRAINT ax_wegpfadsteig_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3871 (class 2606 OID 7507418)
-- Dependencies: 2777 2777
-- Name: ax_wohnbauflaeche_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_wohnbauflaeche
    ADD CONSTRAINT ax_wohnbauflaeche_pk PRIMARY KEY (ogc_fid);


--
-- TOC entry 3873 (class 2606 OID 7507420)
-- Dependencies: 2778 2778 2778 2778 2778
-- Name: geometry_columns_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY geometry_columns
    ADD CONSTRAINT geometry_columns_pk PRIMARY KEY (f_table_catalog, f_table_schema, f_table_name, f_geometry_column);


--
-- TOC entry 3908 (class 2606 OID 15115596)
-- Dependencies: 2901 2901
-- Name: pid_ax_tatsaechlichenutzung; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ax_tatsaechlichenutzung
    ADD CONSTRAINT pid_ax_tatsaechlichenutzung PRIMARY KEY (id);


--
-- TOC entry 3891 (class 2606 OID 14984766)
-- Dependencies: 2892 2892
-- Name: pid_ref_beziehungen; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ref_beziehungen
    ADD CONSTRAINT pid_ref_beziehungen PRIMARY KEY (id);


--
-- TOC entry 3885 (class 2606 OID 14668070)
-- Dependencies: 2890 2890
-- Name: pid_v_anrede; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_anrede
    ADD CONSTRAINT pid_v_anrede PRIMARY KEY (id);


--
-- TOC entry 3883 (class 2606 OID 14668032)
-- Dependencies: 2889 2889
-- Name: pid_v_artderrechtsgemeinschaft; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_artderrechtsgemeinschaft
    ADD CONSTRAINT pid_v_artderrechtsgemeinschaft PRIMARY KEY (id);


--
-- TOC entry 3879 (class 2606 OID 14606094)
-- Dependencies: 2887 2887
-- Name: pid_v_blattart; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_blattart
    ADD CONSTRAINT pid_v_blattart PRIMARY KEY (id);


--
-- TOC entry 3877 (class 2606 OID 14605367)
-- Dependencies: 2886 2886
-- Name: pid_v_buchungsart; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_buchungsart
    ADD CONSTRAINT pid_v_buchungsart PRIMARY KEY (id);


--
-- TOC entry 3881 (class 2606 OID 14668021)
-- Dependencies: 2888 2888
-- Name: pid_v_eigentuemerart; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_eigentuemerart
    ADD CONSTRAINT pid_v_eigentuemerart PRIMARY KEY (id);


--
-- TOC entry 3913 (class 2606 OID 15116087)
-- Dependencies: 2904 2904
-- Name: pid_v_nutzungen_abbaugut; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_abbaugut
    ADD CONSTRAINT pid_v_nutzungen_abbaugut PRIMARY KEY (id);


--
-- TOC entry 3917 (class 2606 OID 15182376)
-- Dependencies: 2906 2906
-- Name: pid_v_nutzungen_art; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_art
    ADD CONSTRAINT pid_v_nutzungen_art PRIMARY KEY (id);


--
-- TOC entry 3895 (class 2606 OID 15114619)
-- Dependencies: 2894 2894
-- Name: pid_v_nutzungen_artderbebauung; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_artderbebauung
    ADD CONSTRAINT pid_v_nutzungen_artderbebauung PRIMARY KEY (id);


--
-- TOC entry 3915 (class 2606 OID 15181672)
-- Dependencies: 2905 2905
-- Name: pid_v_nutzungen_bahnkategorie; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_bahnkategorie
    ADD CONSTRAINT pid_v_nutzungen_bahnkategorie PRIMARY KEY (id);


--
-- TOC entry 3901 (class 2606 OID 15114969)
-- Dependencies: 2897 2897
-- Name: pid_v_nutzungen_foerdergut; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_foerdergut
    ADD CONSTRAINT pid_v_nutzungen_foerdergut PRIMARY KEY (id);


--
-- TOC entry 3899 (class 2606 OID 15247205)
-- Dependencies: 2896 2896 2896
-- Name: pid_v_nutzungen_funktion; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_funktion
    ADD CONSTRAINT pid_v_nutzungen_funktion PRIMARY KEY (idobjektartengruppe, id);


--
-- TOC entry 3934 (class 2606 OID 15184089)
-- Dependencies: 2916 2916
-- Name: pid_v_nutzungen_hydrologischesmerkmal; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_hydrologischesmerkmal
    ADD CONSTRAINT pid_v_nutzungen_hydrologischesmerkmal PRIMARY KEY (id);


--
-- TOC entry 3903 (class 2606 OID 15115057)
-- Dependencies: 2898 2898
-- Name: pid_v_nutzungen_lagergut; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_lagergut
    ADD CONSTRAINT pid_v_nutzungen_lagergut PRIMARY KEY (id);


--
-- TOC entry 3919 (class 2606 OID 15182396)
-- Dependencies: 2907 2907
-- Name: pid_v_nutzungen_nutzung; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_nutzung
    ADD CONSTRAINT pid_v_nutzungen_nutzung PRIMARY KEY (id);


--
-- TOC entry 3929 (class 2606 OID 15183677)
-- Dependencies: 2913 2913
-- Name: pid_v_nutzungen_oberflaechenmaterial; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_oberflaechenmaterial
    ADD CONSTRAINT pid_v_nutzungen_oberflaechenmaterial PRIMARY KEY (id);


--
-- TOC entry 3893 (class 2606 OID 15114248)
-- Dependencies: 2893 2893
-- Name: pid_v_nutzungen_objektgruppen; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_objektartengruppen
    ADD CONSTRAINT pid_v_nutzungen_objektgruppen PRIMARY KEY (id);


--
-- TOC entry 3905 (class 2606 OID 15115139)
-- Dependencies: 2899 2899
-- Name: pid_v_nutzungen_primaerenergie; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_primaerenergie
    ADD CONSTRAINT pid_v_nutzungen_primaerenergie PRIMARY KEY (id);


--
-- TOC entry 3936 (class 2606 OID 15184166)
-- Dependencies: 2917 2917
-- Name: pid_v_nutzungen_tidemerkmal; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_tidemerkmal
    ADD CONSTRAINT pid_v_nutzungen_tidemerkmal PRIMARY KEY (id);


--
-- TOC entry 3924 (class 2606 OID 15183049)
-- Dependencies: 2910 2910 2910
-- Name: pid_v_nutzungen_vegetationsmerkmal; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_vegetationsmerkmal
    ADD CONSTRAINT pid_v_nutzungen_vegetationsmerkmal PRIMARY KEY (idobjektartengruppe, id);


--
-- TOC entry 3897 (class 2606 OID 15114674)
-- Dependencies: 2895 2895
-- Name: pid_v_nutzungen_zustand; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY v_nutzungen_zustand
    ADD CONSTRAINT pid_v_nutzungen_zustand PRIMARY KEY (id);


--
-- TOC entry 3875 (class 2606 OID 8598516)
-- Dependencies: 2877 2877
-- Name: spatial_ref_sys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY spatial_ref_sys
    ADD CONSTRAINT spatial_ref_sys_pkey PRIMARY KEY (srid);


--
-- TOC entry 3561 (class 1259 OID 7507423)
-- Dependencies: 2689 2329
-- Name: ap_darstellung_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ap_darstellung_geom_idx ON ap_darstellung USING gist (wkb_geometry);


--
-- TOC entry 3564 (class 1259 OID 7507424)
-- Dependencies: 2690 2329
-- Name: ap_lpo_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ap_lpo_geom_idx ON ap_lpo USING gist (wkb_geometry);


--
-- TOC entry 3569 (class 1259 OID 7507425)
-- Dependencies: 2691 2329
-- Name: ap_lto_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ap_lto_geom_idx ON ap_lto USING gist (wkb_geometry);


--
-- TOC entry 3574 (class 1259 OID 7507426)
-- Dependencies: 2692 2329
-- Name: ap_ppo_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ap_ppo_geom_idx ON ap_ppo USING gist (wkb_geometry);


--
-- TOC entry 3579 (class 1259 OID 7507427)
-- Dependencies: 2693 2329
-- Name: ap_pto_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ap_pto_geom_idx ON ap_pto USING gist (wkb_geometry);


--
-- TOC entry 3584 (class 1259 OID 7507428)
-- Dependencies: 2694 2329
-- Name: ax_anschrift_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_anschrift_geom_idx ON ax_anschrift USING gist (wkb_geometry);


--
-- TOC entry 3587 (class 1259 OID 7507429)
-- Dependencies: 2695 2329
-- Name: ax_aufnahmepunkt_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_aufnahmepunkt_geom_idx ON ax_aufnahmepunkt USING gist (wkb_geometry);


--
-- TOC entry 3591 (class 1259 OID 7507430)
-- Dependencies: 2329 2696
-- Name: ax_bahnverkehr_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_bahnverkehr_geom_idx ON ax_bahnverkehr USING gist (wkb_geometry);


--
-- TOC entry 3594 (class 1259 OID 7507431)
-- Dependencies: 2697 2329
-- Name: ax_bauraumoderbodenordnungsrecht_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_bauraumoderbodenordnungsrecht_geom_idx ON ax_bauraumoderbodenordnungsrecht USING gist (wkb_geometry);


--
-- TOC entry 3597 (class 1259 OID 7507432)
-- Dependencies: 2698 2329
-- Name: ax_bauteil_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_bauteil_geom_idx ON ax_bauteil USING gist (wkb_geometry);


--
-- TOC entry 3600 (class 1259 OID 7507433)
-- Dependencies: 2699 2329
-- Name: ax_bauwerkimgewaesserbereich_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_bauwerkimgewaesserbereich_geom_idx ON ax_bauwerkimgewaesserbereich USING gist (wkb_geometry);


--
-- TOC entry 3603 (class 1259 OID 7507434)
-- Dependencies: 2700 2329
-- Name: ax_bauwerkimverkehrsbereich_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_bauwerkimverkehrsbereich_geom_idx ON ax_bauwerkimverkehrsbereich USING gist (wkb_geometry);


--
-- TOC entry 3606 (class 1259 OID 7507435)
-- Dependencies: 2701 2329
-- Name: ax_bauwerkoderanlagefuerindustrieundgewerbe_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_bauwerkoderanlagefuerindustrieundgewerbe_geom_idx ON ax_bauwerkoderanlagefuerindustrieundgewerbe USING gist (wkb_geometry);


--
-- TOC entry 3609 (class 1259 OID 7507436)
-- Dependencies: 2702 2329
-- Name: ax_bauwerkoderanlagefuersportfreizeitunderholung_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_bauwerkoderanlagefuersportfreizeitunderholung_geom_idx ON ax_bauwerkoderanlagefuersportfreizeitunderholung USING gist (wkb_geometry);


--
-- TOC entry 3909 (class 1259 OID 15116078)
-- Dependencies: 2903 2329
-- Name: ax_bergbaubetrieb_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_bergbaubetrieb_geom_idx ON ax_bergbaubetrieb USING gist (wkb_geometry);


--
-- TOC entry 3612 (class 1259 OID 7507437)
-- Dependencies: 2703 2329
-- Name: ax_besondereflurstuecksgrenze_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_besondereflurstuecksgrenze_geom_idx ON ax_besondereflurstuecksgrenze USING gist (wkb_geometry);


--
-- TOC entry 3615 (class 1259 OID 7507438)
-- Dependencies: 2329 2704
-- Name: ax_besonderegebaeudelinie_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_besonderegebaeudelinie_geom_idx ON ax_besonderegebaeudelinie USING gist (wkb_geometry);


--
-- TOC entry 3618 (class 1259 OID 7507439)
-- Dependencies: 2705 2329
-- Name: ax_besondererbauwerkspunkt_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_besondererbauwerkspunkt_geom_idx ON ax_besondererbauwerkspunkt USING gist (wkb_geometry);


--
-- TOC entry 3621 (class 1259 OID 7507440)
-- Dependencies: 2706 2329
-- Name: ax_besonderergebaeudepunkt_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_besonderergebaeudepunkt_geom_idx ON ax_besonderergebaeudepunkt USING gist (wkb_geometry);


--
-- TOC entry 3624 (class 1259 OID 7507441)
-- Dependencies: 2329 2707
-- Name: ax_besonderertopographischerpunkt_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_besonderertopographischerpunkt_geom_idx ON ax_besonderertopographischerpunkt USING gist (wkb_geometry);


--
-- TOC entry 3627 (class 1259 OID 7507442)
-- Dependencies: 2708 2329
-- Name: ax_bodenschaetzung_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_bodenschaetzung_geom_idx ON ax_bodenschaetzung USING gist (wkb_geometry);


--
-- TOC entry 3630 (class 1259 OID 7507443)
-- Dependencies: 2709 2329
-- Name: ax_boeschungkliff_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_boeschungkliff_geom_idx ON ax_boeschungkliff USING gist (wkb_geometry);


--
-- TOC entry 3633 (class 1259 OID 7507444)
-- Dependencies: 2710 2329
-- Name: ax_boeschungsflaeche_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_boeschungsflaeche_geom_idx ON ax_boeschungsflaeche USING gist (wkb_geometry);


--
-- TOC entry 3636 (class 1259 OID 7507445)
-- Dependencies: 2711 2329
-- Name: ax_buchungsblatt_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_buchungsblatt_geom_idx ON ax_buchungsblatt USING gist (wkb_geometry);


--
-- TOC entry 3640 (class 1259 OID 7507446)
-- Dependencies: 2712 2329
-- Name: ax_buchungsblattbezirk_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_buchungsblattbezirk_geom_idx ON ax_buchungsblattbezirk USING gist (wkb_geometry);


--
-- TOC entry 3645 (class 1259 OID 7507447)
-- Dependencies: 2713 2329
-- Name: ax_buchungsstelle_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_buchungsstelle_geom_idx ON ax_buchungsstelle USING gist (wkb_geometry);


--
-- TOC entry 3651 (class 1259 OID 7507448)
-- Dependencies: 2714 2329
-- Name: ax_bundesland_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_bundesland_geom_idx ON ax_bundesland USING gist (wkb_geometry);


--
-- TOC entry 3654 (class 1259 OID 7507449)
-- Dependencies: 2329 2715
-- Name: ax_dammwalldeich_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_dammwalldeich_geom_idx ON ax_dammwalldeich USING gist (wkb_geometry);


--
-- TOC entry 3657 (class 1259 OID 7507450)
-- Dependencies: 2329 2716
-- Name: ax_dienststelle_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_dienststelle_geom_idx ON ax_dienststelle USING gist (wkb_geometry);


--
-- TOC entry 3661 (class 1259 OID 7507451)
-- Dependencies: 2717 2329
-- Name: ax_felsenfelsblockfelsnadel_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_felsenfelsblockfelsnadel_geom_idx ON ax_felsenfelsblockfelsnadel USING gist (wkb_geometry);


--
-- TOC entry 3664 (class 1259 OID 7507452)
-- Dependencies: 2718 2329
-- Name: ax_firstlinie_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_firstlinie_geom_idx ON ax_firstlinie USING gist (wkb_geometry);


--
-- TOC entry 3667 (class 1259 OID 7507453)
-- Dependencies: 2329 2719
-- Name: ax_flaechebesondererfunktionalerpraegung_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_flaechebesondererfunktionalerpraegung_geom_idx ON ax_flaechebesondererfunktionalerpraegung USING gist (wkb_geometry);


--
-- TOC entry 3670 (class 1259 OID 7507454)
-- Dependencies: 2720 2329
-- Name: ax_flaechegemischternutzung_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_flaechegemischternutzung_geom_idx ON ax_flaechegemischternutzung USING gist (wkb_geometry);


--
-- TOC entry 3673 (class 1259 OID 7507455)
-- Dependencies: 2721 2329
-- Name: ax_fliessgewaesser_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_fliessgewaesser_geom_idx ON ax_fliessgewaesser USING gist (wkb_geometry);


--
-- TOC entry 3676 (class 1259 OID 7507456)
-- Dependencies: 2722 2329
-- Name: ax_flugverkehr_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_flugverkehr_geom_idx ON ax_flugverkehr USING gist (wkb_geometry);


--
-- TOC entry 3679 (class 1259 OID 7507457)
-- Dependencies: 2723 2329
-- Name: ax_flugverkehrsanlage_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_flugverkehrsanlage_geom_idx ON ax_flugverkehrsanlage USING gist (wkb_geometry);


--
-- TOC entry 3682 (class 1259 OID 7507458)
-- Dependencies: 2724 2329
-- Name: ax_flurstueck_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_flurstueck_geom_idx ON ax_flurstueck USING gist (wkb_geometry);


--
-- TOC entry 3691 (class 1259 OID 7507459)
-- Dependencies: 2725 2329
-- Name: ax_friedhof_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_friedhof_geom_idx ON ax_friedhof USING gist (wkb_geometry);


--
-- TOC entry 3694 (class 1259 OID 7507460)
-- Dependencies: 2726 2329
-- Name: ax_gebaeude_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_gebaeude_geom_idx ON ax_gebaeude USING gist (wkb_geometry);


--
-- TOC entry 3699 (class 1259 OID 7507461)
-- Dependencies: 2329 2727
-- Name: ax_gehoelz_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_gehoelz_geom_idx ON ax_gehoelz USING gist (wkb_geometry);


--
-- TOC entry 3702 (class 1259 OID 7507462)
-- Dependencies: 2728 2329
-- Name: ax_gemarkung_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_gemarkung_geom_idx ON ax_gemarkung USING gist (wkb_geometry);


--
-- TOC entry 3706 (class 1259 OID 7507463)
-- Dependencies: 2729 2329
-- Name: ax_gemarkungsteilflur_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_gemarkungsteilflur_geom_idx ON ax_gemarkungsteilflur USING gist (wkb_geometry);


--
-- TOC entry 3709 (class 1259 OID 7507464)
-- Dependencies: 2329 2730
-- Name: ax_gemeinde_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_gemeinde_geom_idx ON ax_gemeinde USING gist (wkb_geometry);


--
-- TOC entry 3713 (class 1259 OID 7507465)
-- Dependencies: 2731 2329
-- Name: ax_georeferenziertegebaeudeadresse_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_georeferenziertegebaeudeadresse_geom_idx ON ax_georeferenziertegebaeudeadresse USING gist (wkb_geometry);


--
-- TOC entry 3716 (class 1259 OID 7507466)
-- Dependencies: 2732 2329
-- Name: ax_gewaessermerkmal_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_gewaessermerkmal_geom_idx ON ax_gewaessermerkmal USING gist (wkb_geometry);


--
-- TOC entry 3719 (class 1259 OID 7507467)
-- Dependencies: 2733 2329
-- Name: ax_gleis_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_gleis_geom_idx ON ax_gleis USING gist (wkb_geometry);


--
-- TOC entry 3722 (class 1259 OID 7507468)
-- Dependencies: 2734 2329
-- Name: ax_grenzpunkt_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_grenzpunkt_geom_idx ON ax_grenzpunkt USING gist (wkb_geometry);


--
-- TOC entry 3930 (class 1259 OID 15183982)
-- Dependencies: 2329 2915
-- Name: ax_hafenbecken_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_hafenbecken_geom_idx ON ax_hafenbecken USING gist (wkb_geometry);


--
-- TOC entry 3726 (class 1259 OID 7507469)
-- Dependencies: 2735 2329
-- Name: ax_halde_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_halde_geom_idx ON ax_halde USING gist (wkb_geometry);


--
-- TOC entry 3729 (class 1259 OID 7507470)
-- Dependencies: 2736 2329
-- Name: ax_heide_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_heide_geom_idx ON ax_heide USING gist (wkb_geometry);


--
-- TOC entry 3732 (class 1259 OID 7507471)
-- Dependencies: 2737 2329
-- Name: ax_historischesbauwerkoderhistorischeeinrichtung_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_historischesbauwerkoderhistorischeeinrichtung_geom_idx ON ax_historischesbauwerkoderhistorischeeinrichtung USING gist (wkb_geometry);


--
-- TOC entry 3735 (class 1259 OID 7507472)
-- Dependencies: 2738 2329
-- Name: ax_industrieundgewerbeflaeche_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_industrieundgewerbeflaeche_geom_idx ON ax_industrieundgewerbeflaeche USING gist (wkb_geometry);


--
-- TOC entry 3738 (class 1259 OID 7507473)
-- Dependencies: 2329 2739
-- Name: ax_klassifizierungnachwasserrecht_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_klassifizierungnachwasserrecht_geom_idx ON ax_klassifizierungnachwasserrecht USING gist (wkb_geometry);


--
-- TOC entry 3741 (class 1259 OID 7507474)
-- Dependencies: 2740 2329
-- Name: ax_kleinraeumigerlandschaftsteil_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_kleinraeumigerlandschaftsteil_geom_idx ON ax_kleinraeumigerlandschaftsteil USING gist (wkb_geometry);


--
-- TOC entry 3744 (class 1259 OID 7507475)
-- Dependencies: 2741 2329
-- Name: ax_kommunalesgebiet_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_kommunalesgebiet_geom_idx ON ax_kommunalesgebiet USING gist (wkb_geometry);


--
-- TOC entry 3747 (class 1259 OID 7507476)
-- Dependencies: 2329 2742
-- Name: ax_kreisregion_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_kreisregion_geom_idx ON ax_kreisregion USING gist (wkb_geometry);


--
-- TOC entry 3750 (class 1259 OID 7507477)
-- Dependencies: 2743 2329
-- Name: ax_lagebezeichnungkatalogeintrag_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_lagebezeichnungkatalogeintrag_geom_idx ON ax_lagebezeichnungkatalogeintrag USING gist (wkb_geometry);


--
-- TOC entry 3754 (class 1259 OID 7507478)
-- Dependencies: 2744 2329
-- Name: ax_lagebezeichnungmithausnummer_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_lagebezeichnungmithausnummer_geom_idx ON ax_lagebezeichnungmithausnummer USING gist (wkb_geometry);


--
-- TOC entry 3758 (class 1259 OID 7507479)
-- Dependencies: 2745 2329
-- Name: ax_lagebezeichnungmitpseudonummer_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_lagebezeichnungmitpseudonummer_geom_idx ON ax_lagebezeichnungmitpseudonummer USING gist (wkb_geometry);


--
-- TOC entry 3761 (class 1259 OID 7507480)
-- Dependencies: 2746 2329
-- Name: ax_lagebezeichnungohnehausnummer_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_lagebezeichnungohnehausnummer_geom_idx ON ax_lagebezeichnungohnehausnummer USING gist (wkb_geometry);


--
-- TOC entry 3765 (class 1259 OID 7507481)
-- Dependencies: 2747 2329
-- Name: ax_landwirtschaft_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_landwirtschaft_geom_idx ON ax_landwirtschaft USING gist (wkb_geometry);


--
-- TOC entry 3768 (class 1259 OID 7507482)
-- Dependencies: 2748 2329
-- Name: ax_leitung_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_leitung_geom_idx ON ax_leitung USING gist (wkb_geometry);


--
-- TOC entry 3937 (class 1259 OID 15184182)
-- Dependencies: 2919 2329
-- Name: ax_meer_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_meer_geom_idx ON ax_meer USING gist (wkb_geometry);


--
-- TOC entry 3925 (class 1259 OID 15183634)
-- Dependencies: 2912 2329
-- Name: ax_moor_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_moor_geom_idx ON ax_moor USING gist (wkb_geometry);


--
-- TOC entry 3771 (class 1259 OID 7507483)
-- Dependencies: 2749 2329
-- Name: ax_musterlandesmusterundvergleichsstueck_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_musterlandesmusterundvergleichsstueck_geom_idx ON ax_musterlandesmusterundvergleichsstueck USING gist (wkb_geometry);


--
-- TOC entry 3774 (class 1259 OID 7507484)
-- Dependencies: 2750 2329
-- Name: ax_namensnummer_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_namensnummer_geom_idx ON ax_namensnummer USING gist (wkb_geometry);


--
-- TOC entry 3780 (class 1259 OID 7507485)
-- Dependencies: 2751 2329
-- Name: ax_naturumweltoderbodenschutzrecht_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_naturumweltoderbodenschutzrecht_geom_idx ON ax_naturumweltoderbodenschutzrecht USING gist (wkb_geometry);


--
-- TOC entry 3783 (class 1259 OID 7507486)
-- Dependencies: 2752 2329
-- Name: ax_person_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_person_geom_idx ON ax_person USING gist (wkb_geometry);


--
-- TOC entry 3788 (class 1259 OID 7507487)
-- Dependencies: 2753 2329
-- Name: ax_platz_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_platz_geom_idx ON ax_platz USING gist (wkb_geometry);


--
-- TOC entry 3791 (class 1259 OID 7507488)
-- Dependencies: 2329 2754
-- Name: ax_punktortag_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_punktortag_geom_idx ON ax_punktortag USING gist (wkb_geometry);


--
-- TOC entry 3796 (class 1259 OID 7507489)
-- Dependencies: 2755 2329
-- Name: ax_punktortau_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_punktortau_geom_idx ON ax_punktortau USING gist (wkb_geometry);


--
-- TOC entry 3801 (class 1259 OID 7507490)
-- Dependencies: 2756 2329
-- Name: ax_punktortta_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_punktortta_geom_idx ON ax_punktortta USING gist (wkb_geometry);


--
-- TOC entry 3806 (class 1259 OID 7507491)
-- Dependencies: 2757 2329
-- Name: ax_regierungsbezirk_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_regierungsbezirk_geom_idx ON ax_regierungsbezirk USING gist (wkb_geometry);


--
-- TOC entry 3920 (class 1259 OID 15182532)
-- Dependencies: 2909 2329
-- Name: ax_schiffsverkehr_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_schiffsverkehr_geom_idx ON ax_schiffsverkehr USING gist (wkb_geometry);


--
-- TOC entry 3809 (class 1259 OID 7507492)
-- Dependencies: 2758 2329
-- Name: ax_schutzgebietnachwasserrecht_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_schutzgebietnachwasserrecht_geom_idx ON ax_schutzgebietnachwasserrecht USING gist (wkb_geometry);


--
-- TOC entry 3812 (class 1259 OID 7507493)
-- Dependencies: 2759 2329
-- Name: ax_schutzzone_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_schutzzone_geom_idx ON ax_schutzzone USING gist (wkb_geometry);


--
-- TOC entry 3815 (class 1259 OID 7507494)
-- Dependencies: 2760 2329
-- Name: ax_sonstigervermessungspunkt_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_sonstigervermessungspunkt_geom_idx ON ax_sonstigervermessungspunkt USING gist (wkb_geometry);


--
-- TOC entry 3819 (class 1259 OID 7507495)
-- Dependencies: 2761 2329
-- Name: ax_sonstigesbauwerkodersonstigeeinrichtung_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_sonstigesbauwerkodersonstigeeinrichtung_geom_idx ON ax_sonstigesbauwerkodersonstigeeinrichtung USING gist (wkb_geometry);


--
-- TOC entry 3824 (class 1259 OID 7507496)
-- Dependencies: 2329 2762
-- Name: ax_sportfreizeitunderholungsflaeche_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_sportfreizeitunderholungsflaeche_geom_idx ON ax_sportfreizeitunderholungsflaeche USING gist (wkb_geometry);


--
-- TOC entry 3827 (class 1259 OID 7507497)
-- Dependencies: 2329 2763
-- Name: ax_stehendesgewaesser_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_stehendesgewaesser_geom_idx ON ax_stehendesgewaesser USING gist (wkb_geometry);


--
-- TOC entry 3830 (class 1259 OID 7507498)
-- Dependencies: 2329 2764
-- Name: ax_strassenverkehr_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_strassenverkehr_geom_idx ON ax_strassenverkehr USING gist (wkb_geometry);


--
-- TOC entry 3833 (class 1259 OID 7507499)
-- Dependencies: 2329 2765
-- Name: ax_strassenverkehrsanlage_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_strassenverkehrsanlage_geom_idx ON ax_strassenverkehrsanlage USING gist (wkb_geometry);


--
-- TOC entry 3836 (class 1259 OID 7507500)
-- Dependencies: 2766 2329
-- Name: ax_sumpf_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_sumpf_geom_idx ON ax_sumpf USING gist (wkb_geometry);


--
-- TOC entry 3839 (class 1259 OID 7507501)
-- Dependencies: 2767 2329
-- Name: ax_tagebaugrubesteinbruch_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_tagebaugrubesteinbruch_geom_idx ON ax_tagebaugrubesteinbruch USING gist (wkb_geometry);


--
-- TOC entry 3842 (class 1259 OID 7507502)
-- Dependencies: 2768 2329
-- Name: ax_transportanlage_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_transportanlage_geom_idx ON ax_transportanlage USING gist (wkb_geometry);


--
-- TOC entry 3845 (class 1259 OID 7507503)
-- Dependencies: 2329 2769
-- Name: ax_turm_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_turm_geom_idx ON ax_turm USING gist (wkb_geometry);


--
-- TOC entry 3848 (class 1259 OID 7507504)
-- Dependencies: 2770 2329
-- Name: ax_unlandvegetationsloseflaeche_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_unlandvegetationsloseflaeche_geom_idx ON ax_unlandvegetationsloseflaeche USING gist (wkb_geometry);


--
-- TOC entry 3851 (class 1259 OID 7507505)
-- Dependencies: 2329 2771
-- Name: ax_untergeordnetesgewaesser_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_untergeordnetesgewaesser_geom_idx ON ax_untergeordnetesgewaesser USING gist (wkb_geometry);


--
-- TOC entry 3854 (class 1259 OID 7507506)
-- Dependencies: 2772 2329
-- Name: ax_vegetationsmerkmal_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_vegetationsmerkmal_geom_idx ON ax_vegetationsmerkmal USING gist (wkb_geometry);


--
-- TOC entry 3857 (class 1259 OID 7507507)
-- Dependencies: 2773 2329
-- Name: ax_vorratsbehaelterspeicherbauwerk_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_vorratsbehaelterspeicherbauwerk_geom_idx ON ax_vorratsbehaelterspeicherbauwerk USING gist (wkb_geometry);


--
-- TOC entry 3860 (class 1259 OID 7507508)
-- Dependencies: 2774 2329
-- Name: ax_wald_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_wald_geom_idx ON ax_wald USING gist (wkb_geometry);


--
-- TOC entry 3863 (class 1259 OID 7507509)
-- Dependencies: 2775 2329
-- Name: ax_weg_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_weg_geom_idx ON ax_weg USING gist (wkb_geometry);


--
-- TOC entry 3866 (class 1259 OID 7507510)
-- Dependencies: 2776 2329
-- Name: ax_wegpfadsteig_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_wegpfadsteig_geom_idx ON ax_wegpfadsteig USING gist (wkb_geometry);


--
-- TOC entry 3869 (class 1259 OID 7507511)
-- Dependencies: 2777 2329
-- Name: ax_wohnbauflaeche_geom_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX ax_wohnbauflaeche_geom_idx ON ax_wohnbauflaeche USING gist (wkb_geometry);


--
-- TOC entry 3906 (class 1259 OID 15251655)
-- Dependencies: 2329 2901
-- Name: gid_tatsaechlichenutzung; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX gid_tatsaechlichenutzung ON ax_tatsaechlichenutzung USING gist (wkb_geometry);


--
-- TOC entry 3567 (class 1259 OID 7507512)
-- Dependencies: 2690
-- Name: id_ap_lpo_dientzurdarstellungvon; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ap_lpo_dientzurdarstellungvon ON ap_lpo USING btree (dientzurdarstellungvon);


--
-- TOC entry 3568 (class 1259 OID 7507513)
-- Dependencies: 2690
-- Name: id_ap_lpo_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ap_lpo_gml_id ON ap_lpo USING btree (gml_id);


--
-- TOC entry 3572 (class 1259 OID 7507514)
-- Dependencies: 2691
-- Name: id_ap_lto_dientzurdarstellungvon; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ap_lto_dientzurdarstellungvon ON ap_lto USING btree (dientzurdarstellungvon);


--
-- TOC entry 3573 (class 1259 OID 7507515)
-- Dependencies: 2691
-- Name: id_ap_lto_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ap_lto_gml_id ON ap_lto USING btree (gml_id);


--
-- TOC entry 3577 (class 1259 OID 7507516)
-- Dependencies: 2692
-- Name: id_ap_ppo_dientzurdarstellungvon; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ap_ppo_dientzurdarstellungvon ON ap_ppo USING btree (dientzurdarstellungvon);


--
-- TOC entry 3578 (class 1259 OID 7507517)
-- Dependencies: 2692
-- Name: id_ap_ppo_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ap_ppo_gml_id ON ap_ppo USING btree (gml_id);


--
-- TOC entry 3582 (class 1259 OID 7507518)
-- Dependencies: 2693
-- Name: id_ap_pto_dientzurdarstellungvon; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ap_pto_dientzurdarstellungvon ON ap_pto USING btree (dientzurdarstellungvon);


--
-- TOC entry 3583 (class 1259 OID 7507519)
-- Dependencies: 2693
-- Name: id_ap_pto_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ap_pto_gml_id ON ap_pto USING btree (gml_id);


--
-- TOC entry 3590 (class 1259 OID 7768235)
-- Dependencies: 2695
-- Name: id_ax_aufnahmepunkt_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_aufnahmepunkt_gml_id ON ax_aufnahmepunkt USING btree (gml_id);


--
-- TOC entry 3639 (class 1259 OID 14602619)
-- Dependencies: 2711
-- Name: id_ax_buchungsblatt_bezirk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_buchungsblatt_bezirk ON ax_buchungsblatt USING btree (bezirk);


--
-- TOC entry 3643 (class 1259 OID 14602620)
-- Dependencies: 2712
-- Name: id_ax_buchungsblattbezirk_bezirk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_buchungsblattbezirk_bezirk ON ax_buchungsblattbezirk USING btree (bezirk);


--
-- TOC entry 3644 (class 1259 OID 14602621)
-- Dependencies: 2712
-- Name: id_ax_buchungsblattbezirk_stelle; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_buchungsblattbezirk_stelle ON ax_buchungsblattbezirk USING btree (stelle);


--
-- TOC entry 3648 (class 1259 OID 14472730)
-- Dependencies: 2713
-- Name: id_ax_buchungsstelle_an; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_buchungsstelle_an ON ax_buchungsstelle USING btree (an);


--
-- TOC entry 3649 (class 1259 OID 7507520)
-- Dependencies: 2713
-- Name: id_ax_buchungsstelle_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_buchungsstelle_gml_id ON ax_buchungsstelle USING btree (gml_id);


--
-- TOC entry 3650 (class 1259 OID 7507521)
-- Dependencies: 2713
-- Name: id_ax_buchungsstelle_istbestandteilvon; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_buchungsstelle_istbestandteilvon ON ax_buchungsstelle USING btree (istbestandteilvon);


--
-- TOC entry 3660 (class 1259 OID 14602622)
-- Dependencies: 2716
-- Name: id_ax_dienststelle_stelle; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_dienststelle_stelle ON ax_dienststelle USING btree (stelle);


--
-- TOC entry 3685 (class 1259 OID 14473253)
-- Dependencies: 2724
-- Name: id_ax_flurstueck_alkflstkennz; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_flurstueck_alkflstkennz ON ax_flurstueck USING btree (alkflstkennz);


--
-- TOC entry 3686 (class 1259 OID 14473019)
-- Dependencies: 2724
-- Name: id_ax_flurstueck_flurstueckskennzeichen; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_flurstueck_flurstueckskennzeichen ON ax_flurstueck USING btree (flurstueckskennzeichen);


--
-- TOC entry 3687 (class 1259 OID 7507522)
-- Dependencies: 2724
-- Name: id_ax_flurstueck_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_flurstueck_gml_id ON ax_flurstueck USING btree (gml_id);


--
-- TOC entry 3688 (class 1259 OID 7507523)
-- Dependencies: 2724
-- Name: id_ax_flurstueck_istgebucht; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_flurstueck_istgebucht ON ax_flurstueck USING btree (istgebucht);


--
-- TOC entry 3689 (class 1259 OID 7507524)
-- Dependencies: 2724
-- Name: id_ax_flurstueck_weistauf; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_flurstueck_weistauf ON ax_flurstueck USING btree (weistauf);


--
-- TOC entry 3690 (class 1259 OID 7507525)
-- Dependencies: 2724
-- Name: id_ax_flurstueck_zeigtauf; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_flurstueck_zeigtauf ON ax_flurstueck USING btree (zeigtauf);


--
-- TOC entry 3697 (class 1259 OID 7507526)
-- Dependencies: 2726
-- Name: id_ax_gebaeude_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_gebaeude_gml_id ON ax_gebaeude USING btree (gml_id);


--
-- TOC entry 3698 (class 1259 OID 7507527)
-- Dependencies: 2726
-- Name: id_ax_gebaeude_hat; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_gebaeude_hat ON ax_gebaeude USING btree (hat);


--
-- TOC entry 3705 (class 1259 OID 14733199)
-- Dependencies: 2728
-- Name: id_ax_gemarkung_gemarkungsnummer; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_gemarkung_gemarkungsnummer ON ax_gemarkung USING btree (gemarkungsnummer);


--
-- TOC entry 3712 (class 1259 OID 14731973)
-- Dependencies: 2730
-- Name: id_ax_gemeinde_gemeinde; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_gemeinde_gemeinde ON ax_gemeinde USING btree (gemeinde);


--
-- TOC entry 3725 (class 1259 OID 7768207)
-- Dependencies: 2734
-- Name: id_ax_grenzpunkt_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_grenzpunkt_gml_id ON ax_grenzpunkt USING btree (gml_id);


--
-- TOC entry 3753 (class 1259 OID 14733604)
-- Dependencies: 2743
-- Name: id_ax_lagebezeichnungkatalogeintrag_lage; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_lagebezeichnungkatalogeintrag_lage ON ax_lagebezeichnungkatalogeintrag USING btree (lage);


--
-- TOC entry 3757 (class 1259 OID 14733282)
-- Dependencies: 2744
-- Name: id_ax_lagebezeichnungmithausnummer_gehoertzu; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_lagebezeichnungmithausnummer_gehoertzu ON ax_lagebezeichnungmithausnummer USING btree (gehoertzu);


--
-- TOC entry 3764 (class 1259 OID 14733281)
-- Dependencies: 2746
-- Name: id_ax_lagebezeichnungohnehausnummer_gehoertzu; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_lagebezeichnungohnehausnummer_gehoertzu ON ax_lagebezeichnungohnehausnummer USING btree (gehoertzu);


--
-- TOC entry 3777 (class 1259 OID 7507528)
-- Dependencies: 2750
-- Name: id_ax_namensnummer_benennt; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_namensnummer_benennt ON ax_namensnummer USING btree (benennt);


--
-- TOC entry 3778 (class 1259 OID 7507529)
-- Dependencies: 2750
-- Name: id_ax_namensnummer_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_namensnummer_gml_id ON ax_namensnummer USING btree (gml_id);


--
-- TOC entry 3779 (class 1259 OID 7507530)
-- Dependencies: 2750
-- Name: id_ax_namensnummer_istbestandteilvon; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_namensnummer_istbestandteilvon ON ax_namensnummer USING btree (istbestandteilvon);


--
-- TOC entry 3786 (class 1259 OID 7507531)
-- Dependencies: 2752
-- Name: id_ax_person_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_person_gml_id ON ax_person USING btree (gml_id);


--
-- TOC entry 3787 (class 1259 OID 7507532)
-- Dependencies: 2752
-- Name: id_ax_person_hat; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_person_hat ON ax_person USING btree (hat);


--
-- TOC entry 3794 (class 1259 OID 7830691)
-- Dependencies: 2754
-- Name: id_ax_punktortag_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_punktortag_gml_id ON ax_punktortag USING btree (gml_id);


--
-- TOC entry 3795 (class 1259 OID 7830688)
-- Dependencies: 2754
-- Name: id_ax_punktortag_istteilvon; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_punktortag_istteilvon ON ax_punktortag USING btree (istteilvon);


--
-- TOC entry 3799 (class 1259 OID 7830692)
-- Dependencies: 2755
-- Name: id_ax_punktortau_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_punktortau_gml_id ON ax_punktortau USING btree (gml_id);


--
-- TOC entry 3800 (class 1259 OID 7830689)
-- Dependencies: 2755
-- Name: id_ax_punktortau_istteilvon; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_punktortau_istteilvon ON ax_punktortau USING btree (istteilvon);


--
-- TOC entry 3804 (class 1259 OID 7830693)
-- Dependencies: 2756
-- Name: id_ax_punktortta_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_punktortta_gml_id ON ax_punktortta USING btree (gml_id);


--
-- TOC entry 3805 (class 1259 OID 7830690)
-- Dependencies: 2756
-- Name: id_ax_punktortta_istteilvon; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_punktortta_istteilvon ON ax_punktortta USING btree (istteilvon);


--
-- TOC entry 3818 (class 1259 OID 7768236)
-- Dependencies: 2760
-- Name: id_ax_sonstigervermessungspunkt_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_sonstigervermessungspunkt_gml_id ON ax_sonstigervermessungspunkt USING btree (gml_id);


--
-- TOC entry 3822 (class 1259 OID 7507533)
-- Dependencies: 2761
-- Name: id_ax_sonstigesbauwerkodersonstigeeinrichtung_gehoertzu; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_sonstigesbauwerkodersonstigeeinrichtung_gehoertzu ON ax_sonstigesbauwerkodersonstigeeinrichtung USING btree (gehoertzu);


--
-- TOC entry 3823 (class 1259 OID 7507534)
-- Dependencies: 2761
-- Name: id_ax_sonstigesbauwerkodersonstigeeinrichtung_gehoertzubauwerk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ax_sonstigesbauwerkodersonstigeeinrichtung_gehoertzubauwerk ON ax_sonstigesbauwerkodersonstigeeinrichtung USING btree (gehoertzubauwerk);


--
-- TOC entry 3886 (class 1259 OID 14984772)
-- Dependencies: 2892
-- Name: id_ref_beziehungen_ref_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ref_beziehungen_ref_gml_id ON ref_beziehungen USING btree (ref_gml_id);


--
-- TOC entry 3887 (class 1259 OID 14984773)
-- Dependencies: 2892
-- Name: id_ref_beziehungen_referenz; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ref_beziehungen_referenz ON ref_beziehungen USING btree (referenz);


--
-- TOC entry 3888 (class 1259 OID 14984771)
-- Dependencies: 2892
-- Name: id_ref_beziehungen_tab_gml_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ref_beziehungen_tab_gml_id ON ref_beziehungen USING btree (tab_gml_id);


--
-- TOC entry 3889 (class 1259 OID 14984770)
-- Dependencies: 2892
-- Name: id_ref_beziehungen_tabelle; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX id_ref_beziehungen_tabelle ON ref_beziehungen USING btree (tabelle);


--
-- TOC entry 3943 (class 0 OID 0)
-- Dependencies: 3
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2009-05-13 08:16:11

--
-- PostgreSQL database dump complete
--

