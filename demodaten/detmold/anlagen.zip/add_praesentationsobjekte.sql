--F�r Neue Flurstuecksnummer ohne Repr�sentationsobjekt  Repr�sentationsobjekt erzeugen
insert into ap_pto (wkb_geometry, gml_id, art, dientzurdarstellungvon, skalierung, horizontaleausrichtung, vertikaleausrichtung)
 select PointOnSurface(wkb_geometry) as wkb_geometry, 'myfl'||trim(leading 'DENW' from gml_id) as gmlid, 'ZAE_NEN' as art, gml_id as dientzurdarstellungvon, 1 as skalierung, 'zentrisch' as horizontaleausrichtung, 'Basis' as vertikaleausrichtung
  from ax_flurstueck
  where gml_id not in (select dientzurdarstellungvon as id from ap_pto where art = 'ZAE_NEN');