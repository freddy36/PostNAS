CREATE INDEX id_ax_flurstueck_gml_id
  ON ax_flurstueck
  USING btree
  (gml_id);

CREATE INDEX id_ax_buchungsstelle_gml_id
  ON ax_buchungsstelle
  USING btree
  (gml_id);

CREATE INDEX id_ax_namensnummer_gml_id
  ON ax_namensnummer
  USING btree
  (gml_id);

CREATE INDEX id_ax_person_gml_id
  ON ax_person
  USING btree
  (gml_id);

CREATE INDEX id_ax_gebaeude_gml_id
  ON ax_gebaeude
  USING btree
  (gml_id);
  
CREATE INDEX id_ap_pto_dientzurdarstellungvon
  ON ap_pto
  USING btree
  (dientzurdarstellungvon);
  
CREATE INDEX id_ap_ppo_dientzurdarstellungvon
  ON ap_ppo
  USING btree
  (dientzurdarstellungvon);
  
CREATE INDEX id_ap_lto_dientzurdarstellungvon
  ON ap_lto
  USING btree
  (dientzurdarstellungvon);
  
CREATE INDEX id_ap_lpo_dientzurdarstellungvon
  ON ap_lpo
  USING btree
  (dientzurdarstellungvon);

CREATE INDEX id_ax_flurstueck_flurstueckskennzeichen
  ON ax_flurstueck
  USING btree
  (flurstueckskennzeichen);

CREATE INDEX id_ax_flurstueck_alkflstkennz
  ON ax_flurstueck
  USING btree
  (alkflstkennz);
  
CREATE INDEX id_ax_flurstueck_istgebucht
  ON ax_flurstueck
  USING btree
  (istgebucht);

CREATE INDEX id_ax_flurstueck_zeigtauf
  ON ax_flurstueck
  USING btree
  (zeigtauf);

CREATE INDEX id_ax_flurstueck_weistauf
  ON ax_flurstueck
  USING btree
  (weistauf);

CREATE INDEX id_ax_namensnummer_istbestandteilvon
  ON ax_namensnummer
  USING btree
  (istbestandteilvon);

CREATE INDEX id_ax_buchungsstelle_istbestandteilvon
  ON ax_buchungsstelle
  USING btree
  (istbestandteilvon);

CREATE INDEX id_ax_buchungsstelle_an
  ON ax_buchungsstelle
  USING btree
  (an);

CREATE INDEX id_ax_buchungsblatt_bezirk
  ON ax_buchungsblatt
  USING btree
  (bezirk);
  
CREATE INDEX id_ax_namensnummer_benennt
  ON ax_namensnummer
  USING btree
  (benennt);

CREATE INDEX id_ax_person_hat
  ON ax_person
  USING btree
  (hat);

CREATE INDEX id_ax_gebaeude_hat
  ON ax_gebaeude
  USING btree
  (hat);

CREATE INDEX id_ax_sonstigesbauwerkodersonstigeeinrichtung_gehoertzubauwerk
  ON ax_sonstigesbauwerkodersonstigeeinrichtung
  USING btree
  (gehoertzubauwerk);

CREATE INDEX id_ax_sonstigesbauwerkodersonstigeeinrichtung_gehoertzu
  ON ax_sonstigesbauwerkodersonstigeeinrichtung
  USING btree
  (gehoertzu);

--CREATE INDEX id_ax_gebaeude_gehoert
--  ON ax_gebaeude
--  USING btree
--  (gehoert);

--CREATE INDEX id_ax_gebaeude_gehoertzu
--  ON ax_gebaeude
--  USING btree
--  (gehoertzu);

--CREATE INDEX id_ax_gebaeude_haengtzusammenmit
--  ON ax_gebaeude
--  USING btree
--  (haengtzusammenmit);

CREATE INDEX id_ax_grenzpunkt_gml_id
  ON ax_grenzpunkt
  USING btree
  (gml_id);

CREATE INDEX id_ax_aufnahmepunkt_gml_id
  ON ax_aufnahmepunkt
  USING btree
  (gml_id);

CREATE INDEX id_ax_sonstigervermessungspunkt_gml_id
  ON ax_sonstigervermessungspunkt
  USING btree
  (gml_id);

CREATE INDEX id_ax_punktortag_istteilvon
  ON ax_punktortag
  USING btree
  (istteilvon);

CREATE INDEX id_ax_punktortau_istteilvon
  ON ax_punktortau
  USING btree
  (istteilvon);

CREATE INDEX id_ax_punktortta_istteilvon
  ON ax_punktortta
  USING btree
  (istteilvon);

CREATE INDEX id_ax_punktortag_gml_id
  ON ax_punktortag
  USING btree
  (gml_id);

CREATE INDEX id_ax_punktortau_gml_id
  ON ax_punktortau
  USING btree
  (gml_id);

CREATE INDEX id_ax_punktortta_gml_id
  ON ax_punktortta
  USING btree
  (gml_id);

CREATE INDEX id_ax_buchungsblatt_bezirk
  ON ax_buchungsblatt
  USING btree
  (bezirk);

CREATE INDEX id_ax_buchungsblattbezirk_bezirk
  ON ax_buchungsblattbezirk
  USING btree
  (bezirk);

CREATE INDEX id_ax_buchungsblattbezirk_stelle
  ON ax_buchungsblattbezirk
  USING btree
  (stelle);

CREATE INDEX id_ax_dienststelle_stelle
  ON ax_dienststelle
  USING btree
  (stelle);

CREATE INDEX id_ax_gemeinde_gemeinde
  ON ax_gemeinde
  USING btree
  (gemeinde);

CREATE INDEX id_ax_gemarkung_gemarkungsnummer
  ON ax_gemarkung
  USING btree
  (gemarkungsnummer);

CREATE INDEX id_ax_lagebezeichnungohnehausnummer_gehoertzu
  ON ax_lagebezeichnungohnehausnummer
  USING btree
  (gehoertzu);

CREATE INDEX id_ax_lagebezeichnungmithausnummer_gehoertzu
  ON ax_lagebezeichnungmithausnummer
  USING btree
  (gehoertzu);

CREATE INDEX id_ax_lagebezeichnungkatalog_lage
  ON ax_lagebezeichnungkatalog
  USING btree
  (lage);
  

