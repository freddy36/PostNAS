#!/bin/bash
cd ../layer/
for layer in *.map; do
 echo $layer
 sed -i 's/"host=localhost dbname=alkis user=admin"/"host=localhost dbname=alkis_lverm_geo_rlp_6 user=postgres"/g' $layer
done