############ 
# Für Linux zu konfigurieren, wenn die onlinesource auf 
# wms_onlineresource "http://localhost/cgi-bin/alkis.xml" #linux
# gestellt ist
############
Die Datei 'alkis.xml' muss in das gleiche Verzeichnis wie der UMN MapServer kopiert werden. 

eventuelles Verzeichnis (ansonsten suchen):
/usr/lib/cgi-bin/

Anschliessend ist dei Datei ausführbar und zugänglich zu machen. 

