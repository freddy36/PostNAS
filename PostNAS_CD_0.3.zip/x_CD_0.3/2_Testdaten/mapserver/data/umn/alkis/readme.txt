 
Der zuvor installierte UMN MapServer sollte mindestens die Version 5.0 haben.