<?php
/*	alkis_www_conf.php
	ALKIS-Buchauskunft, Kommunales Rechenzentrum Minden-Ravensberg/Lippe (Lemgo).
	Zentrale Einstellungen - Internet-Version
	2010-02-25
*/
$dbhost = 'localhost';
$dbport = '5432'; // PG 8.3 UTF
$dbuser = 'xxxx'; // nur f. WWW, fuer poduktive DBs anderen User verwenden
$dbpass = 'xxxx';
// Link f�r Hilfe
$hilfeurl = 'http://map.krz.de/mapwww/?Themen:ALKIS';
?>