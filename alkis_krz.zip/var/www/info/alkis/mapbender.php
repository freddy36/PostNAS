<?php
header("Location: http://map.krz.de/mapwww/frames/login.php?name=xxxxxx&password=xxxxx&mb_user_myGui=ALKIS_Demo&mb_myPOI2SCALE=353072,5530881,1000");
exit();
?>